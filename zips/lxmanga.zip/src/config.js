let BASE_URL = "https://lxmanga.space/";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}
if (!BASE_URL.endsWith('/')) {
    BASE_URL += '/';
}