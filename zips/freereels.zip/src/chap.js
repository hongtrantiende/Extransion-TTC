load("crypto.js");
load("config.js");
load("shared.js");

function execute(input) {
    var payload = parseEpisodeInput(input);
    var series = fetchSeriesInfo(payload.seriesId);
    return Response.success(buildChapTracks(series, payload));
}
