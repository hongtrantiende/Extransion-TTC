load("crypto.js");
load("config.js");
load("shared.js");

function execute(input) {
    return Response.success(buildNativeTrackResponse(parseTrackPayload(input)));
}

