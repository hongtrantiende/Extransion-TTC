var BASE_URL = "https://free-reels.com";
var API_BASE = "https://apiv2.free-reels.com/frv2-api";
var APP_SECRET = "8IAcbWyCsVhYv82S2eofRqK1DF3nNDAv";
var APP_NAME = "com.freereels.app";
var APP_VERSION = "2.2.81";
var USER_AGENT = "okhttp/4.12.0";
var PAGE_SIZE = 24;
var FREEREELS_AUTO_GUEST_STATE = true;

// Có thể dán state thủ công vào đây. Nếu để trống, ext tự tạo guest state bằng /anonymous/login.
// Format tối thiểu:
// {
//   "oauthToken": "...", "oauthSecret": "...",
//   "deviceId": "...", "sessionId": "...", "gaid": "...",
//   "device": { "language": "vi", "country": "VN", "locale": "vi-VN" }
// }
var FREEREELS_STATE_JSON = "";
