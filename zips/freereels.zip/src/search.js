load("crypto.js");
load("config.js");
load("shared.js");

function execute(key, page) {
    key = trimText(key);
    if (!key) return Response.success([]);
    var result = searchDrama(key, page || "");
    var items = [];
    for (var i = 0; i < result.list.length; i++) {
        var card = buildSeriesCard(extractSeriesFromItem(result.list[i]));
        if (card) items.push(card);
    }
    return Response.success(items, result.next);
}

