load("crypto.js");
load("config.js");
load("shared.js");

function execute(input) {
    var series = fetchSeriesInfo(parseSeriesInput(input));
    return Response.success(buildToc(series));
}
