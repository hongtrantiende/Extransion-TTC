var STATE_KEY = "freereels.state.v2";
var STATE_REQUIRED = "FreeReels thiếu state mới và auto guest state đang tắt.";
var TRACK_EXTRAS_LIMIT = 24000;
var TRACK_EXTRAS_INDEX_KEY = "freereels.track.index.v1";
var TRACK_EXTRAS_MAX_ITEMS = 12;

function trimText(value) {
    if (value == null) return "";
    return String(value).replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "");
}

function isArray(value) {
    return Object.prototype.toString.call(value) === "[object Array]";
}

function safeJsonParse(text) {
    try {
        return JSON.parse(String(text || ""));
    } catch (e) {
        return null;
    }
}

function decodeURIComponentSafe(text) {
    try {
        return decodeURIComponent(String(text || "").replace(/\+/g, " "));
    } catch (e) {
        return String(text || "");
    }
}

function getStoredValue(key) {
    try {
        if (typeof localStorage !== "undefined" && localStorage && localStorage.getItem) return localStorage.getItem(key) || "";
    } catch (e) {}
    return "";
}

function setStoredValue(key, value) {
    try {
        if (typeof localStorage !== "undefined" && localStorage && localStorage.setItem) {
            localStorage.setItem(key, value);
            return true;
        }
    } catch (e) {}
    return false;
}

function removeStoredValue(key) {
    try {
        if (typeof localStorage !== "undefined" && localStorage && localStorage.removeItem) localStorage.removeItem(key);
    } catch (e) {}
}

function buildQuery(params) {
    var parts = [];
    for (var key in params) {
        if (!params.hasOwnProperty(key)) continue;
        if (params[key] == null || params[key] === "") continue;
        parts.push(encodeURIComponent(key) + "=" + encodeURIComponent(String(params[key])));
    }
    return parts.join("&");
}

function getUrlOrigin(url) {
    var match = String(url || "").match(/^(https?:\/\/[^\/?#]+)/i);
    return match && match[1] ? match[1] : "";
}

function normalizeUrl(url) {
    url = trimText(url);
    if (!url) return "";
    if (url.indexOf("//") === 0) return "https:" + url;
    if (url.indexOf("/") === 0) return BASE_URL + url;
    if (!/^[a-zA-Z]+:\/\//.test(url)) return BASE_URL + "/" + url.replace(/^\/+/, "");
    return url;
}

function resolveUrl(base, url) {
    url = trimText(url);
    if (!url) return "";
    if (/^[a-zA-Z]+:\/\//.test(url)) return url;
    if (url.indexOf("//") === 0) return "https:" + url;
    base = trimText(base);
    if (!base) return normalizeUrl(url);
    if (url.charAt(0) === "/") return getUrlOrigin(base) + url;
    return base.replace(/[?#].*$/, "").replace(/\/[^\/]*$/, "/") + url;
}

function htmlEscape(text) {
    return String(text == null ? "" : text)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

function textToHtml(text) {
    return htmlEscape(trimText(text)).replace(/\r\n|\r|\n/g, "<br>");
}

function joinParts(parts, sep) {
    var out = [];
    for (var i = 0; i < parts.length; i++) {
        var value = trimText(parts[i]);
        if (value) out.push(value);
    }
    return out.join(sep || " · ");
}

function firstValue(obj, keys) {
    if (!obj) return "";
    for (var i = 0; i < keys.length; i++) {
        var key = keys[i];
        if (obj[key] != null && obj[key] !== "") return obj[key];
    }
    return "";
}

function loadFreereelsState(required) {
    var raw = trimText(typeof FREEREELS_STATE_JSON !== "undefined" ? FREEREELS_STATE_JSON : "");
    if (!raw) raw = trimText(getStoredValue(STATE_KEY));
    var state = safeJsonParse(raw);
    if (!state && raw && raw.indexOf("oauth") >= 0) {
        state = parseLooseState(raw);
        if (state && state.oauthToken && state.oauthSecret) setStoredValue(STATE_KEY, JSON.stringify(state));
    }
    if (!state) state = {};
    state.device = state.device || {};
    state.oauthToken = trimText(state.oauthToken || state.oauth_token || state.token || "");
    state.oauthSecret = trimText(state.oauthSecret || state.oauth_secret || state.secret || "");
    state.deviceId = trimText(state.deviceId || state.device_id || state.device.deviceId || state.device.device_id || "");
    state.sessionId = trimText(state.sessionId || state.session_id || state.device.sessionId || state.device.session_id || "");
    state.gaid = trimText(state.gaid || state.gaid_id || state.device.gaid || "");
    if (!state.sessionId) state.sessionId = "fr-vn-" + md5Hex(state.deviceId || "session").slice(0, 24);
    applyVietnameseDeviceDefaults(state);
    if (required && (!state.oauthToken || !state.oauthSecret || !state.deviceId)) {
        if (typeof FREEREELS_AUTO_GUEST_STATE !== "undefined" && FREEREELS_AUTO_GUEST_STATE) {
            state = createGuestState();
        } else {
            throw new Error(STATE_REQUIRED);
        }
    }
    return state;
}

function parseLooseState(raw) {
    var state = {};
    var pairs = String(raw || "").split(/[\n\r,;]+/);
    for (var i = 0; i < pairs.length; i++) {
        var part = pairs[i];
        var m = part.match(/^\s*([A-Za-z0-9_-]+)\s*[:=]\s*(.*?)\s*$/);
        if (m) state[m[1]] = m[2];
    }
    return state;
}

function applyVietnameseDeviceDefaults(state) {
    var d = state.device || {};
    d.model = trimText(d.model || state.model || "SM-A536E");
    d.manufacturer = trimText(d.manufacturer || state.manufacturer || "samsung");
    d.brand = trimText(d.brand || state.brand || "samsung");
    d.product = trimText(d.product || state.product || "a53x");
    d.fingerprint = trimText(d.fingerprint || state.fingerprint || "samsung/a53xxx/a53x:13/TP1A.220624.014/A536EXXU7CWK6:user/release-keys");
    d.sdk = trimText(d.sdk || d.version || state.deviceVersion || "33");
    d.language = trimText(d.language || state.language || "vi");
    d.country = trimText(d.country || state.country || "VN");
    d.locale = trimText(d.locale || d.deviceLanguage || "vi-VN");
    d.timezone = trimText(d.timezone || state.timezone || "+7");
    d.timezoneOffset = trimText(d.timezoneOffset || state.timezoneOffset || "420");
    d.mccCountry = trimText(d.mccCountry || state.mccCountry || "452");
    d.network = trimText(d.network || state.network || "wifi");
    d.screenWidth = trimText(d.screenWidth || state.screenWidth || "393");
    d.screenHeight = trimText(d.screenHeight || state.screenHeight || "873");
    d.memory = trimText(d.memory || state.memory || "6.00");
    d.performance = trimText(d.performance || state.performance || "high");
    state.device = d;
}

function md5Hex(text) {
    return CryptoJS.MD5(String(text || "")).toString(CryptoJS.enc.Hex);
}

function randomHex(length) {
    var out = "";
    var chars = "0123456789abcdef";
    for (var i = 0; i < length; i++) out += chars.charAt(Math.floor(Math.random() * chars.length));
    return out;
}

function makeUuid() {
    return randomHex(8) + "-" + randomHex(4) + "-4" + randomHex(3) + "-" +
        "89ab".charAt(Math.floor(Math.random() * 4)) + randomHex(3) + "-" + randomHex(12);
}

function createBaseGuestState() {
    var state = {
        deviceId: makeUuid(),
        sessionId: makeUuid(),
        gaid: makeUuid(),
        createdAt: new Date().getTime(),
        source: "auto-guest"
    };
    applyVietnameseDeviceDefaults(state);
    return state;
}

function createGuestState() {
    var state = createBaseGuestState();
    var login = anonymousLogin(state);
    state.oauthToken = trimText(firstValue(login, ["auth_key", "authKey", "oauthToken", "oauth_token", "key"]));
    state.oauthSecret = trimText(firstValue(login, ["auth_secret", "authSecret", "oauthSecret", "oauth_secret", "secret"]));
    state.userId = trimText(firstValue(login, ["user_id", "userId", "id"]));
    state.userType = login.user_type || login.userType || "";
    if (!state.oauthToken || !state.oauthSecret) {
        throw new Error("FreeReels /anonymous/login không trả auth_key/auth_secret. Cần kiểm tra flow state mới.");
    }
    setStoredValue(STATE_KEY, JSON.stringify(state));
    console.log(String("FreeReels guest state created: " + state.deviceId));
    return state;
}

function anonymousLogin(state) {
    var d = state.device || {};
    var body = {
        device_id: state.deviceId,
        device_name: buildDeviceName(d),
        sign: md5Hex(APP_SECRET + state.deviceId)
    };
    var response = fetch(API_BASE + "/anonymous/login", {
        method: "POST",
        headers: buildApiHeaders(state, {}, true),
        body: JSON.stringify(body)
    });
    var text = "";
    try {
        text = String(response.text() || "");
    } catch (e) {}
    var json = safeJsonParse(text);
    if (!response || !response.ok) throwApiError("/anonymous/login", response ? response.status : 0, json, text);
    if (!json) throw new Error("FreeReels /anonymous/login không trả JSON: HTTP " + (response ? response.status : 0));
    return unwrapApiResponse("/anonymous/login", json);
}

function buildDeviceName(d) {
    d = d || {};
    return trimText(trimText(d.brand || d.manufacturer || "samsung") + " " + trimText(d.model || "SM-A536E"));
}

function buildAuthHeader(state) {
    var ts = new Date().getTime();
    var signature = md5Hex(APP_SECRET + "&" + state.oauthSecret);
    return "oauth_signature=" + signature + ",oauth_token=" + state.oauthToken + ",ts=" + ts;
}

function getApiLanguage(d) {
    d = d || {};
    var locale = trimText(d.locale || d.deviceLanguage || "");
    if (locale) return locale;
    var language = trimText(d.language || "vi");
    var country = trimText(d.country || "VN");
    if (language.indexOf("-") >= 0) return language;
    return language + "-" + country;
}

function buildApiHeaders(state, extra, noAuth) {
    var d = state.device || {};
    var apiLanguage = getApiLanguage(d);
    var country = trimText(d.country || "VN");
    var headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "User-Agent": USER_AGENT,
        "app-name": APP_NAME,
        "app-version": APP_VERSION,
        "device": "android",
        "device-version": d.sdk || "33",
        "device-id": state.deviceId,
        "session-id": state.sessionId,
        "gaid": state.gaid || "00000000-0000-0000-0000-000000000000",
        "language": apiLanguage,
        "country": country,
        "app-language": apiLanguage,
        "prefer_country": country,
        "locale": apiLanguage,
        "device-language": apiLanguage,
        "device-country": country,
        "timezone": d.timezone || "+7",
        "X-Timezone": d.timezone || "+7",
        "X-Timezone-offset": d.timezoneOffset || "420",
        "mcc-country": d.mccCountry || "452",
        "network-type": d.network || "wifi",
        "screen-width": d.screenWidth || "393",
        "screen-height": d.screenHeight || "873",
        "device-memory": d.memory || "6.00",
        "x-performance-level": d.performance || "high",
        "x-device-model": d.model || "SM-A536E",
        "x-device-manufacturer": d.manufacturer || "samsung",
        "x-device-brand": d.brand || "samsung",
        "x-device-product": d.product || "a53x",
        "x-device-fingerprint": d.fingerprint || "samsung/a53xxx/a53x:13/TP1A.220624.014/A536EXXU7CWK6:user/release-keys",
        "is-mainland": "false",
        "adb-enabled": "false",
        "Accept-Language": apiLanguage,
        "OpCountryCode": country,
        "X-AppEngine-Country": country
    };
    if (!noAuth && state.oauthToken && state.oauthSecret) headers["Authorization"] = buildAuthHeader(state);
    if (state.firebaseId) headers["firebase-id"] = state.firebaseId;
    if (state.appsflyerId) {
        headers["X-Appsflyer_Id"] = state.appsflyerId;
        headers["appsflyer-id"] = state.appsflyerId;
    }
    if (state.abExps) headers["Ab-Exps"] = state.abExps;
    extra = extra || {};
    for (var key in extra) if (extra.hasOwnProperty(key)) headers[key] = extra[key];
    return headers;
}

function apiRequest(path, method, body, params) {
    var state = loadFreereelsState(true);
    try {
        return apiRequestWithState(state, path, method, body, params);
    } catch (e) {
        var message = String(e && e.message ? e.message : e);
        if ((typeof FREEREELS_AUTO_GUEST_STATE !== "undefined" && FREEREELS_AUTO_GUEST_STATE) &&
            /state bị từ chối|HTTP 401|HTTP 403|auth|oauth|token|risk|device/i.test(message)) {
            setStoredValue(STATE_KEY, "");
            state = createGuestState();
            return apiRequestWithState(state, path, method, body, params);
        }
        throw e;
    }
}

function apiRequestWithState(state, path, method, body, params) {
    var query = buildQuery(params || {});
    var url = API_BASE + path + (query ? "?" + query : "");
    var options = { method: method || "GET", headers: buildApiHeaders(state) };
    if (options.method === "POST") options.body = JSON.stringify(body || {});
    var response = fetch(url, options);
    var text = "";
    try {
        text = String(response.text() || "");
    } catch (e) {}
    var json = safeJsonParse(text);
    if (!response || !response.ok) throwApiError(path, response ? response.status : 0, json, text);
    if (!json) throw new Error("FreeReels không trả JSON ở " + path + ": HTTP " + (response ? response.status : 0));
    return unwrapApiResponse(path, json);
}

function throwApiError(path, status, json, text) {
    var msg = "";
    if (json) msg = trimText(json.message || json.msg || json.error || json.err_msg || "");
    if (!msg) msg = trimText(String(text || "").slice(0, 180));
    if (status === 401 || status === 403 || /token|oauth|auth|login|risk|device|ban|forbidden|unauthor/i.test(msg)) {
        throw new Error("FreeReels state bị từ chối ở " + path + " (HTTP " + status + "). Cần xin/lấy state mới.");
    }
    throw new Error("FreeReels lỗi " + path + " HTTP " + status + (msg ? ": " + msg : ""));
}

function unwrapApiResponse(path, json) {
    var code = json.code;
    if (code == null) code = json.status_code;
    if (code == null) code = json.errno;
    if (code != null && String(code) !== "0" && String(code) !== "200" && String(code).toLowerCase() !== "success") {
        var msg = trimText(json.message || json.msg || json.error || "");
        if (/token|oauth|auth|login|risk|device|ban|forbidden|unauthor/i.test(msg + " " + code)) {
            throw new Error("FreeReels state bị từ chối (" + code + "). Cần xin/lấy state mới.");
        }
        throw new Error("FreeReels lỗi " + path + ": " + code + (msg ? " - " + msg : ""));
    }
    if (json.data != null) return json.data;
    if (json.result != null) return json.result;
    return json;
}

function fetchHotList() {
    var result = normalizeListResponse(apiRequest("/search/hot-list", "POST", {}));
    if (!result.list.length) return fetchForYou("");
    return result;
}

function fetchForYou(next) {
    return normalizeListResponse(apiRequest("/foryou/feed", "GET", null, { next: next || "" }));
}

function fetchTabIndex(tabKey, positionIndex) {
    var data = apiRequest("/homepage/v2/tab/index", "GET", null, {
        tab_key: tabKey,
        position_index: positionIndex || 10000,
        rec_trigger: 0
    });
    return normalizeListResponse(flattenHomeModules(data));
}

function fetchComingSoon(next) {
    return normalizeListResponse(flattenHomeModules(apiRequest("/coming-soon/list", "GET", null, { next: next || "" })));
}

function searchDrama(keyword, next) {
    return normalizeListResponse(apiRequest("/search/drama", "POST", {
        keyword: trimText(keyword),
        next: next || "",
        timestamp: String(new Date().getTime())
    }));
}

function fetchSeriesInfo(seriesId) {
    var data = apiRequest("/drama/info_v2", "GET", null, {
        series_id: seriesId,
        scene: "search",
        clip_content: "",
        campaign: ""
    });
    var series = data && data.info ? data.info : data;
    if (!series || !getSeriesId(series)) throw new Error("FreeReels không trả detail cho series " + seriesId);
    return series;
}

function unlockEpisode(seriesId, episodeId, lang) {
    return apiRequest("/drama/unlock_episode", "POST", {
        series_id: seriesId,
        episode_id: episodeId,
        lang: lang || "vi"
    });
}

function normalizeListResponse(data) {
    data = data || {};
    var list = [];
    if (isArray(data)) list = data;
    else if (isArray(data.items)) list = data.items;
    else if (isArray(data.list)) list = data.list;
    else if (isArray(data.series)) list = data.series;
    else if (isArray(data.results)) list = data.results;
    var pageInfo = data.page_info || data.pageInfo || {};
    var next = trimText(pageInfo.next || pageInfo.cursor || data.next || "");
    if (!next && pageInfo.has_more === false) next = null;
    return { list: list, next: next };
}

function flattenHomeModules(data) {
    data = data || {};
    var source = isArray(data) ? data : (isArray(data.items) ? data.items : (isArray(data.list) ? data.list : []));
    var items = [];
    for (var i = 0; i < source.length; i++) appendHomeItem(items, source[i]);
    return {
        items: items,
        next: data.next || (data.page_info && data.page_info.next) || "",
        page_info: data.page_info || data.pageInfo || {}
    };
}

function appendHomeItem(out, item) {
    if (!item) return;
    if (isArray(item.items)) {
        for (var i = 0; i < item.items.length; i++) appendHomeItem(out, item.items[i]);
        return;
    }
    out.push(item);
}

function buildModeInput(mode, data) {
    return "freereels:" + mode + ":" + encodeURIComponent(JSON.stringify(data || {}));
}

function parseModeInput(input) {
    input = trimText(input);
    var match = input.match(/^freereels:([^:]+):([\s\S]*)$/);
    if (!match) return { mode: input || "hot", data: {} };
    return { mode: match[1], data: safeJsonParse(decodeURIComponentSafe(match[2])) || {} };
}

function fetchListByMode(input, page) {
    var parsed = parseModeInput(input);
    var result;
    if (parsed.mode === "foryou") result = fetchForYou(page || "");
    else if (parsed.mode === "search") result = searchDrama(parsed.data.keyword || "", page || "");
    else if (parsed.mode === "tab") result = fetchTabIndex(parsed.data.tabKey || "", parsed.data.positionIndex || 10000);
    else if (parsed.mode === "coming") result = fetchComingSoon(page || "");
    else result = fetchHotList();
    var items = [];
    for (var i = 0; i < result.list.length; i++) {
        var card = buildSeriesCard(extractSeriesFromItem(result.list[i]));
        if (card) items.push(card);
    }
    return { items: items, next: result.next };
}

function extractSeriesFromItem(item) {
    if (!item) return null;
    return item.series || item.info || item.drama || item.data || item;
}

function getSeriesId(series) {
    return trimText(firstValue(series, ["id", "series_id", "seriesId", "series_key", "key"]));
}

function getSeriesTitle(series) {
    return trimText(firstValue(series, ["title", "name", "series_name", "seriesName"])) || "FreeReels";
}

function buildSeriesLink(seriesOrId) {
    var id = typeof seriesOrId === "string" ? seriesOrId : getSeriesId(seriesOrId);
    return BASE_URL + "/detail/" + encodeURIComponent(id);
}

function buildSeriesCard(series) {
    if (!series) return null;
    var id = getSeriesId(series);
    if (!id) return null;
    var link = buildSeriesLink(id);
    return {
        bookId: link,
        name: getSeriesTitle(series),
        link: link,
        url: link,
        path: link,
        input: link,
        cover: normalizeUrl(firstValue(series, ["cover", "poster", "image", "thumbnail", "thumb"])),
        description: buildSeriesDescription(series),
        host: BASE_URL,
        format: "series",
        type: "video",
        tag: buildSeriesTag(series)
    };
}

function buildSeriesDescription(series) {
    return joinParts([
        firstValue(series, ["desc", "description", "summary", "intro"]),
        series.episode_count ? String(series.episode_count) + " tập" : "",
        firstValue(series, ["hot_score", "view_count", "viewCount"])
    ], " · ");
}

function buildSeriesTag(series) {
    if (series.free === true) return "Free";
    if (series.episode_count) return String(series.episode_count) + " tập";
    return "";
}

function parseSeriesInput(input) {
    input = trimText(input);
    var json = safeJsonParse(input);
    if (json) return parseSeriesInput(json.url || json.link || json.bookId || json.id || "");
    var custom = input.match(/^freereels:series:([^?#]+)/);
    if (custom) return decodeURIComponentSafe(custom[1]);
    var query = getQueryParam(input, "series_id") || getQueryParam(input, "id");
    if (query) return query;
    var path = input.match(/\/(?:detail|drama|series)\/([^\/?#]+)/i);
    if (path) return decodeURIComponentSafe(path[1]);
    if (/^[A-Za-z0-9_-]+$/.test(input)) return input;
    throw new Error("Không nhận ra link FreeReels: " + input);
}

function getQueryParam(url, name) {
    var re = new RegExp("[?&]" + name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "=([^&#]*)", "i");
    var match = String(url || "").match(re);
    return match ? decodeURIComponentSafe(match[1]) : "";
}

function buildDetailResponse(series) {
    var id = getSeriesId(series);
    var seriesUrl = buildSeriesLink(id);
    return {
        bookId: seriesUrl,
        name: getSeriesTitle(series),
        cover: normalizeUrl(firstValue(series, ["cover", "poster", "image", "thumbnail", "thumb"])),
        author: "FreeReels",
        description: textToHtml(firstValue(series, ["desc", "description", "summary", "intro"])),
        detail: joinParts([series.episode_count ? String(series.episode_count) + " tập" : "", firstValue(series, ["pay_mode", "resource_type"])]),
        host: BASE_URL,
        path: seriesUrl,
        ongoing: false,
        format: "series",
        type: "video",
        genres: extractTags(series),
        suggests: [{
            title: "Gợi ý FreeReels",
            input: buildModeInput("foryou", { seriesId: id }),
            script: "suggest.js"
        }],
        comments: []
    };
}

function extractTags(series) {
    var tags = [];
    var sources = [series.content_tags, series.content_detail_tags, series.biz_tags, series.operation_tags, series.tags];
    for (var i = 0; i < sources.length; i++) {
        var arr = sources[i];
        if (!isArray(arr)) continue;
        for (var j = 0; j < arr.length; j++) {
            var tag = typeof arr[j] === "string" ? arr[j] : firstValue(arr[j], ["name", "title", "label"]);
            tag = trimText(tag);
            if (tag) tags.push({
                title: tag,
                input: buildModeInput("search", { keyword: tag, title: tag }),
                script: "gen.js"
            });
        }
    }
    return tags;
}

function buildSuggests(series) {
    var out = [];
    var lists = [series.franchise, series.recommend, series.related, series.similar];
    for (var i = 0; i < lists.length; i++) {
        var arr = lists[i];
        if (!isArray(arr)) continue;
        for (var j = 0; j < arr.length; j++) {
            var card = buildSeriesCard(arr[j]);
            if (card) out.push(card);
        }
    }
    return out;
}

function getEpisodeList(series) {
    var list = [];
    if (isArray(series.episode_list)) list = series.episode_list;
    else if (isArray(series.episodes)) list = series.episodes;
    else if (series.episode_info) list = [series.episode_info];
    else if (series.episode) list = [series.episode];
    return list;
}

function buildToc(series) {
    var episodes = getEpisodeList(series);
    var seriesId = getSeriesId(series);
    var seriesTitle = getSeriesTitle(series);
    var items = [];
    if (episodes.length > 1) items.push({ name: "Danh sách tập", url: "", type: "section", host: BASE_URL });
    for (var i = 0; i < episodes.length; i++) {
        var ep = episodes[i];
        items.push({
            name: getEpisodeTitle(ep, i + 1, episodes.length, seriesTitle),
            url: buildEpisodeUrl(seriesId, ep, i + 1, seriesTitle),
            host: BASE_URL,
            description: episodeLocked(ep) ? "Có thể cần tài khoản đã unlock" : ""
        });
    }
    return items;
}

function getEpisodeId(ep) {
    return trimText(firstValue(ep, ["id", "episode_id", "episodeId", "episode_key", "key"]));
}

function getEpisodeTitle(ep, index, total, seriesTitle) {
    var name = trimText(firstValue(ep, ["name", "title", "episode_name"]));
    var n = Number(firstValue(ep, ["index", "episode_no", "episodeNo", "sort"]) || index || 1);
    if (seriesTitle && name === seriesTitle) name = "";
    if (!name) name = total <= 1 ? "Phát phim" : "Tập " + n;
    else if (/^\d+$/.test(name)) name = "Tập " + name;
    return name;
}

function episodeLocked(ep) {
    if (!ep) return false;
    if (ep.unlock === false || ep.user_unlocked === false) return true;
    if (ep.free === true || ep.unlock === true || ep.user_unlocked === true) return false;
    return false;
}

function buildEpisodeUrl(seriesId, ep, index, seriesTitle) {
    var episodeId = getEpisodeId(ep);
    var episodeIndex = Number(firstValue(ep, ["index", "episode_no", "episodeNo", "sort"]) || index || 1);
    return BASE_URL + "/episode/" + encodeURIComponent(seriesId) + "/" + encodeURIComponent(episodeId) +
        "?index=" + encodeURIComponent(String(episodeIndex)) +
        "&title=" + encodeURIComponent(getEpisodeTitle(ep, index || 1, 2, seriesTitle));
}

function parseEpisodeInput(input) {
    input = trimText(input);
    var customIndex = input.indexOf("freereels:episode:");
    if (customIndex >= 0) {
        return safeJsonParse(decodeURIComponentSafe(input.slice(customIndex + "freereels:episode:".length))) || {};
    }
    var path = input.match(/\/episode\/([^\/?#]+)\/([^\/?#]+)/i);
    if (path) {
        return {
            seriesId: decodeURIComponentSafe(path[1]),
            episodeId: decodeURIComponentSafe(path[2]),
            index: Number(getQueryParam(input, "index") || 1),
            title: getQueryParam(input, "title") || ""
        };
    }
    var seriesId = parseSeriesInput(input);
    return {
        seriesId: seriesId,
        episodeId: getQueryParam(input, "episode_id") || getQueryParam(input, "episode"),
        index: Number(getQueryParam(input, "index") || 1)
    };
}

function pickEpisode(series, payload) {
    var episodes = getEpisodeList(series);
    var episodeId = trimText(payload.episodeId || "");
    for (var i = 0; i < episodes.length; i++) {
        if (episodeId && getEpisodeId(episodes[i]) === episodeId) return episodes[i];
    }
    var index = Number(payload.index || 1);
    for (i = 0; i < episodes.length; i++) {
        var n = Number(firstValue(episodes[i], ["index", "episode_no", "episodeNo", "sort"]) || (i + 1));
        if (n === index) return episodes[i];
    }
    return episodes[0] || null;
}

function buildChapTracks(series, payload) {
    var ep = pickEpisode(series, payload);
    if (!ep) throw new Error("Không tìm thấy tập FreeReels");
    var episodeId = getEpisodeId(ep);
    if (episodeId) {
        try {
            var unlocked = unlockEpisode(getSeriesId(series), episodeId, "vi-VN");
            if (unlocked && getEpisodeId(unlocked)) ep = mergeEpisode(ep, unlocked);
        } catch (e) {}
    }
    var sources = collectVideoSources(ep);
    if (!sources.length && episodeLocked(ep)) throw new Error("Tập FreeReels đang khóa hoặc state chưa có quyền. Cần state/tài khoản đã unlock.");
    if (!sources.length) throw new Error("Tập FreeReels chưa có link phát trong response. Cần state mới hoặc API đã đổi.");
    var tracks = [];
    var title = getEpisodeTitle(ep, payload.index || 1, 2);
    var subtitles = buildSubtitleTracks(ep.subtitle_list || ep.subtitleList || [], getOriginalAudioLanguage(ep));
    for (var i = 0; i < sources.length; i++) appendSourceTracks(tracks, sources[i], ep, title, subtitles);
    return tracks;
}

function mergeEpisode(base, extra) {
    var out = {};
    var key;
    for (key in base) if (base.hasOwnProperty(key)) out[key] = base[key];
    for (key in extra) if (extra.hasOwnProperty(key) && extra[key] != null && extra[key] !== "") out[key] = extra[key];
    return out;
}

function collectVideoSources(ep) {
    var out = [];
    addVideoSource(out, firstValue(ep, ["m3u8_url", "m3u8Url"]), "HLS", "");
    addVideoSource(out, firstValue(ep, ["video_url", "videoUrl", "url", "play_url", "playUrl"]), "Video", "");
    addVideoSource(out, firstValue(ep, ["external_audio_h264_m3u8", "externalAudioH264M3U8"]), "H264", "h264");
    addVideoSource(out, firstValue(ep, ["external_audio_h265_m3u8", "externalAudioH265M3U8"]), "H265", "h265");
    return out;
}

function addVideoSource(out, url, label, codec) {
    url = normalizeUrl(url);
    if (!url) return;
    for (var i = 0; i < out.length; i++) if (out[i].url === url) return;
    out.push({ url: url, label: label, codec: codec || "" });
}

function appendSourceTracks(tracks, source, ep, title, subtitles) {
    var manifest = /\.m3u8(?:[?#]|$)/i.test(source.url) ? fetchHlsManifestInfo(source.url) : null;
    var audioChoices = manifest && manifest.audios && manifest.audios.length ? manifest.audios : [];
    if (manifest && manifest.variants && manifest.variants.length) {
        for (var i = 0; i < manifest.variants.length; i++) {
            var variant = manifest.variants[i];
            tracks.push({
                name: buildTrackName(source.label, variant.label),
                url: buildTrackPayload(variant.url, ep, title, audioChoices, subtitles, source, variant),
                host: getUrlOrigin(variant.url) || BASE_URL
            });
        }
        return;
    }
    tracks.push({
        name: source.label || (/\.m3u8(?:[?#]|$)/i.test(source.url) ? "HLS" : "Video"),
        url: buildTrackPayload(source.url, ep, title, audioChoices, subtitles, source, null),
        host: getUrlOrigin(source.url) || BASE_URL
    });
}

function buildTrackName(codecLabel, qualityLabel) {
    codecLabel = trimText(codecLabel);
    qualityLabel = trimText(qualityLabel);
    if (codecLabel && qualityLabel) return codecLabel + " " + qualityLabel;
    return codecLabel || qualityLabel || "HLS";
}

function buildTrackPayload(url, ep, title, audioChoices, subtitles, source, variant) {
    var audioLanguages = getEpisodeAudioLanguages(ep);
    var preferredAudioTrack = getPreferredAudioLanguage(ep);
    var originalAudioLanguage = getOriginalAudioLanguage(ep);
    var extrasKey = saveTrackExtras(audioChoices || [], audioLanguages, preferredAudioTrack, subtitles || buildSubtitleTracks(ep.subtitle_list || ep.subtitleList || [], originalAudioLanguage), originalAudioLanguage);
    return "freereels:track:" + encodeURIComponent(JSON.stringify({
        url: url,
        title: title,
        mimeType: /\.m3u8(?:[?#]|$)/i.test(url) ? "application/vnd.apple.mpegurl" : "",
        codec: source && source.codec ? source.codec : "",
        quality: variant && variant.label ? variant.label : "",
        resolution: variant && variant.resolution ? variant.resolution : "",
        extrasKey: extrasKey
    }));
}

function parseTrackPayload(input) {
    input = trimText(input);
    if (input.indexOf("freereels:track:") === 0) return safeJsonParse(decodeURIComponentSafe(input.slice("freereels:track:".length))) || {};
    if (/^https?:\/\//i.test(input)) return { url: input };
    return safeJsonParse(input) || {};
}

function fetchHlsManifestInfo(url) {
    var response = fetch(url, {
        method: "GET",
        headers: buildMediaHeaders()
    });
    if (!response || !response.ok) return null;
    var text = "";
    try {
        text = String(response.text() || "");
    } catch (e) {}
    if (!text) return null;
    return parseHlsManifest(url, text);
}

function parseHlsManifest(url, text) {
    var lines = String(text || "").split(/\r?\n/);
    var variants = [];
    var audios = [];
    for (var i = 0; i < lines.length; i++) {
        var line = trimText(lines[i]);
        if (line.indexOf("#EXT-X-MEDIA:") === 0 && /TYPE=AUDIO/i.test(line)) {
            var media = parseHlsAttributes(line.slice(line.indexOf(":") + 1));
            var audioUrl = resolveUrl(url, media.URI || media.uri || "");
            if (audioUrl) audios.push({
                data: audioUrl,
                url: audioUrl,
                type: "application/vnd.apple.mpegurl",
                label: trimText(media.NAME || media.name || media.LANGUAGE || media.language || "Audio"),
                language: trimText(media.LANGUAGE || media.language || media.NAME || media.name || "")
            });
        } else if (line.indexOf("#EXT-X-STREAM-INF:") === 0) {
            var attrs = parseHlsAttributes(line.slice(line.indexOf(":") + 1));
            var next = "";
            while (++i < lines.length) {
                next = trimText(lines[i]);
                if (next && next.charAt(0) !== "#") break;
            }
            var variantUrl = resolveUrl(url, next);
            if (variantUrl) variants.push({
                url: variantUrl,
                resolution: trimText(attrs.RESOLUTION || attrs.resolution || ""),
                bandwidth: Number(attrs.BANDWIDTH || attrs.bandwidth || 0),
                codecs: trimText(attrs.CODECS || attrs.codecs || ""),
                label: hlsVariantLabel(attrs)
            });
        }
    }
    return { variants: variants, audios: orderAudioChoices(audios), text: text };
}

function parseHlsAttributes(text) {
    var attrs = {};
    var re = /([A-Z0-9-]+)=("(?:[^"\\]|\\.)*"|[^,]*)/ig;
    var match;
    while ((match = re.exec(text || "")) != null) {
        var value = match[2] || "";
        if (value.charAt(0) === "\"" && value.charAt(value.length - 1) === "\"") value = value.slice(1, -1);
        attrs[match[1]] = value;
    }
    return attrs;
}

function hlsVariantLabel(attrs) {
    var resolution = trimText(attrs.RESOLUTION || attrs.resolution || "");
    if (resolution) {
        var match = resolution.match(/(\d+)x(\d+)/);
        if (match) return Math.min(Number(match[1]), Number(match[2])) + "p";
        return resolution;
    }
    var bw = Number(attrs.BANDWIDTH || attrs.bandwidth || 0);
    return bw ? Math.round(bw / 1000) + "k" : "";
}

function buildMediaHeaders() {
    return {
        "Accept": "*/*",
        "Referer": BASE_URL + "/",
        "User-Agent": USER_AGENT
    };
}

function getEpisodeAudioLanguages(ep) {
    return isArray(ep.audio) ? ep.audio : [];
}

function getOriginalAudioLanguage(ep) {
    return trimText(ep.original_audio_language || ep.originalAudioLanguage || "");
}

function getPreferredAudioLanguage(ep) {
    var list = getEpisodeAudioLanguages(ep);
    for (var i = 0; i < list.length; i++) if (/^vi(?:-|$)/i.test(String(list[i] || ""))) return String(list[i]);
    return getOriginalAudioLanguage(ep);
}

function orderAudioChoices(audios, originalAudioLanguage) {
    if (!audios || !audios.length) return [];
    var out = [];
    appendMatchingAudio(out, audios, /^vi(?:-|$)|vietnam/i);
    appendMatchingAudio(out, audios, /^zh(?:-|$)|chinese|trung/i);
    appendOriginalLanguage(out, audios, originalAudioLanguage);
    for (var i = 0; i < audios.length; i++) if (out.indexOf(audios[i]) < 0) out.push(audios[i]);
    return out;
}

function appendMatchingAudio(out, audios, re) {
    for (var i = 0; i < audios.length; i++) {
        var a = audios[i] || {};
        if (re.test(String(a.language || a.label || "")) && out.indexOf(a) < 0) out.push(a);
    }
}

function buildSubtitleTracks(subs, originalAudioLanguage) {
    if (!isArray(subs) || !subs.length) return [];
    var out = [];
    for (var i = 0; i < subs.length; i++) {
        var s = subs[i] || {};
        var url = normalizeUrl(firstValue(s, ["vtt", "subtitle", "url", "path", "subtitle_url", "subtitleUrl", "file"]));
        if (!url) continue;
        out.push({
            data: url,
            url: url,
            headers: buildMediaHeaders(),
            type: /\.vtt(?:[?#]|$)/i.test(url) ? "text/vtt" : "application/x-subrip",
            label: trimText(firstValue(s, ["display_name", "displayName", "name", "title", "language", "lang"])) || "Subtitle",
            language: trimText(firstValue(s, ["language", "lang"])) || ""
        });
    }
    return orderSubtitleTracks(out, originalAudioLanguage);
}

function orderSubtitleTracks(subtitles, originalAudioLanguage) {
    var out = [];
    appendMatchingSubtitle(out, subtitles, /^vi(?:-|$)|vietnam/i);
    appendMatchingSubtitle(out, subtitles, /^zh(?:-|$)|chinese|trung/i);
    appendOriginalLanguage(out, subtitles, originalAudioLanguage);
    for (var i = 0; i < subtitles.length; i++) if (out.indexOf(subtitles[i]) < 0) out.push(subtitles[i]);
    return out;
}

function appendMatchingSubtitle(out, subtitles, re) {
    for (var i = 0; i < subtitles.length; i++) {
        var s = subtitles[i] || {};
        if (re.test(String(s.language || s.label || "")) && out.indexOf(s) < 0) out.push(s);
    }
}

function appendOriginalLanguage(out, items, originalAudioLanguage) {
    originalAudioLanguage = normalizeLanguageCode(originalAudioLanguage);
    if (!originalAudioLanguage) return;
    var primary = originalAudioLanguage.split("-")[0];
    var name = languageName(primary);
    for (var i = 0; i < items.length; i++) {
        var item = items[i] || {};
        var hay = normalizeLanguageCode(item.language || "") + " " + String(item.label || "").toLowerCase();
        if (hay.indexOf(originalAudioLanguage) >= 0 || languageTextMatches(hay, primary, name)) {
            if (out.indexOf(item) < 0) out.push(item);
        }
    }
}

function normalizeLanguageCode(value) {
    return trimText(value).toLowerCase().replace(/_/g, "-");
}

function languageTextMatches(text, primary, name) {
    if (!primary) return false;
    var re = new RegExp("(^|[^a-z])" + primary.replace(/[^a-z0-9-]/g, "") + "($|[^a-z])", "i");
    if (re.test(text)) return true;
    return name ? text.indexOf(name) >= 0 : false;
}

function languageName(primary) {
    var names = {
        en: "english",
        zh: "chinese",
        ja: "japanese",
        ko: "korean",
        es: "spanish",
        pt: "portuguese",
        fr: "french",
        id: "indonesian",
        ru: "russian",
        de: "german",
        vi: "vietnamese",
        it: "italian",
        tr: "turkish",
        ms: "malay",
        th: "thai",
        tl: "filipino",
        hi: "hindi",
        ar: "arabic",
        yue: "cantonese"
    };
    return names[primary] || "";
}

function compactPriorityTracks(items, originalAudioLanguage) {
    if (!isArray(items) || !items.length) return [];
    var out = [];
    appendMatchingSubtitle(out, items, /^vi(?:-|$)|vietnam/i);
    appendMatchingSubtitle(out, items, /^zh(?:-|$)|chinese|trung/i);
    appendOriginalLanguage(out, items, originalAudioLanguage);
    if (!out.length) out.push(items[0]);
    return out;
}

function saveTrackExtras(audioChoices, audioLanguages, preferredAudioTrack, subtitles, originalAudioLanguage) {
    var extras = {
        audioChoices: orderAudioChoices(audioChoices || [], originalAudioLanguage),
        audioLanguages: audioLanguages || [],
        preferredAudioTrack: preferredAudioTrack || "",
        originalAudioLanguage: originalAudioLanguage || "",
        subtitles: orderSubtitleTracks(subtitles || [], originalAudioLanguage)
    };
    var json = JSON.stringify(extras);
    if (json.length > TRACK_EXTRAS_LIMIT) {
        extras.audioChoices = compactPriorityTracks(extras.audioChoices, originalAudioLanguage);
        extras.subtitles = compactPriorityTracks(extras.subtitles, originalAudioLanguage);
        json = JSON.stringify(extras);
    }
    var key = "freereels.track." + md5Hex(json);
    if (!setStoredValue(key, json)) {
        cleanupTrackExtras(0);
        setStoredValue(key, json);
    }
    rememberTrackExtrasKey(key);
    return key;
}

function rememberTrackExtrasKey(key) {
    var list = safeJsonParse(getStoredValue(TRACK_EXTRAS_INDEX_KEY));
    if (!isArray(list)) list = [];
    var out = [key];
    for (var i = 0; i < list.length; i++) {
        if (list[i] !== key && out.length < TRACK_EXTRAS_MAX_ITEMS) out.push(list[i]);
    }
    for (i = 0; i < list.length; i++) {
        if (out.indexOf(list[i]) < 0) removeStoredValue(list[i]);
    }
    setStoredValue(TRACK_EXTRAS_INDEX_KEY, JSON.stringify(out));
}

function cleanupTrackExtras(keepCount) {
    var list = safeJsonParse(getStoredValue(TRACK_EXTRAS_INDEX_KEY));
    if (!isArray(list)) return;
    keepCount = Number(keepCount || 0);
    for (var i = keepCount; i < list.length; i++) removeStoredValue(list[i]);
    setStoredValue(TRACK_EXTRAS_INDEX_KEY, JSON.stringify(list.slice(0, keepCount)));
}

function applyTrackExtras(payload) {
    payload = payload || {};
    var key = trimText(payload.extrasKey || "");
    if (!key) return payload;
    var extras = null;
    try {
        extras = safeJsonParse(getStoredValue(key));
    } catch (e) {}
    if (!extras) return payload;
    if (!payload.audioChoices) payload.audioChoices = extras.audioChoices || [];
    if (!payload.audioLanguages) payload.audioLanguages = extras.audioLanguages || [];
    if (!payload.preferredAudioTrack) payload.preferredAudioTrack = extras.preferredAudioTrack || "";
    if (!payload.originalAudioLanguage) payload.originalAudioLanguage = extras.originalAudioLanguage || "";
    if (!payload.subtitles) payload.subtitles = extras.subtitles || [];
    return payload;
}

function buildNativeTrackResponse(payload) {
    payload = applyTrackExtras(payload || {});
    var url = normalizeUrl(payload.url || "");
    if (!url) throw new Error("Không có URL phát FreeReels");
    var headers = buildMediaHeaders();
    var response = {
        data: url,
        type: "native",
        headers: headers,
        host: getUrlOrigin(url) || BASE_URL,
        timeSkip: []
    };
    if (payload.mimeType) response.mimeType = payload.mimeType;
    else if (/\.m3u8(?:[?#]|$)/i.test(url)) response.mimeType = "application/vnd.apple.mpegurl";
    if (payload.preferredAudioTrack) response.preferredAudioTrack = payload.preferredAudioTrack;
    appendAudioTracks(response, payload, headers);
    appendSubtitleTracks(response, payload, headers);
    return response;
}

function appendAudioTracks(response, payload, headers) {
    var choices = payload.audioChoices || [];
    var audios = [];
    if (isArray(choices)) {
        for (var i = 0; i < choices.length; i++) {
            var item = choices[i] || {};
            var audioUrl = normalizeUrl(item.data || item.url || "");
            if (!audioUrl) continue;
            audios.push({
                data: audioUrl,
                url: audioUrl,
                headers: headers,
                type: trimText(item.type || "application/vnd.apple.mpegurl"),
                label: trimText(item.label || item.language || "Audio"),
                language: trimText(item.language || "")
            });
        }
    }
    if (!audios.length) {
        var audio = normalizeUrl(payload.audioUrl || "");
        if (audio) audios.push({ data: audio, url: audio, headers: headers, type: "application/vnd.apple.mpegurl", label: "Audio", language: "" });
    }
    if (audios.length) {
        response.audio = audios[0].data;
        response.audios = audios;
        addSingleAudioFallback(response);
    }
}

function addSingleAudioFallback(response) {
    var base;
    if (!response || !response.audios || response.audios.length !== 1) return;
    base = response.audios[0] || {};
    response.audios.push({
        data: base.data || "",
        url: base.url || base.data || "",
        headers: base.headers || {},
        type: base.type || "application/vnd.apple.mpegurl",
        label: trimText(base.label || "Audio") + " · dự phòng",
        language: trimText(base.language || "")
    });
    if (!response.audio && response.audios[0]) response.audio = response.audios[0].data;
}

function appendSubtitleTracks(response, payload, headers) {
    var subs = payload.subtitles || [];
    if (!isArray(subs) || !subs.length) return;
    var out = [];
    for (var i = 0; i < subs.length; i++) {
        var s = subs[i] || {};
        var url = normalizeUrl(firstValue(s, ["data", "vtt", "subtitle", "url", "path", "subtitle_url", "subtitleUrl", "file"]));
        if (!url) continue;
        out.push({
            data: url,
            url: url,
            headers: headers,
            type: /\.vtt(?:[?#]|$)/i.test(url) ? "text/vtt" : "application/x-subrip",
            label: trimText(firstValue(s, ["label", "display_name", "displayName", "language", "lang", "name", "title"])) || "Subtitle",
            language: trimText(firstValue(s, ["language", "lang"])) || ""
        });
    }
    out = orderSubtitleTracks(out, payload.originalAudioLanguage || "");
    if (out.length) {
        response.subtitles = out;
        response.subtitleTracks = out;
    }
}

function commonHomeList() {
    return [
        { title: "Cho bạn - Tuyển chọn", input: buildModeInput("foryou", { title: "Cho bạn - Tuyển chọn" }), script: "gen.js" },
        { title: "Cho bạn - Top", input: buildModeInput("hot", { title: "Cho bạn - Top" }), script: "gen.js" },
    ];
}

function commonGenreList() {
    return [
        { title: "Phim ngắn - Mới nhất", input: buildModeInput("tab", { title: "Phim ngắn - Mới nhất", tabKey: "505", positionIndex: 10000 }), script: "gen.js" },
        { title: "Phim ngắn - Sắp ra mắt", input: buildModeInput("tab", { title: "Phim ngắn - Sắp ra mắt", tabKey: "622", positionIndex: 10000 }), script: "gen.js" },
        { title: "Phim ngắn - Nữ giới", input: buildModeInput("tab", { title: "Phim ngắn - Nữ giới", tabKey: "504", positionIndex: 10000 }), script: "gen.js" },
        { title: "Phim ngắn - Nam giới", input: buildModeInput("tab", { title: "Phim ngắn - Nam giới", tabKey: "506", positionIndex: 10000 }), script: "gen.js" },
        { title: "Hoạt hình", input: buildModeInput("tab", { title: "Hoạt hình", tabKey: "547", positionIndex: 10001 }), script: "gen.js" }
    ];
}
