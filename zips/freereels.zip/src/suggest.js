load("crypto.js");
load("config.js");
load("shared.js");

function execute(input, page) {
    var result = fetchListByMode(buildModeInput("hot", {}), page || "");
    return Response.success(result.items, result.next);
}

