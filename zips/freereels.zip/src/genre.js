load("crypto.js");
load("config.js");
load("shared.js");

function execute() {
    return Response.success(commonGenreList());
}

