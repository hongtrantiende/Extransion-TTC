function execute(keyword, page) {
    var url = "https://welove-gourmet.com/search?query=" + encodeURIComponent(keyword);
    if (page > 1) {
        url = url + "&pi=" + page;
    }
    var response = fetch(url, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }
    });
    if (!response.ok) {
        return Response.error("Lỗi kết nối");
    }
    var doc = Html.parse(response.text());
    var items = doc.select(".searchlist ul li");
    var list = [];
    for (var i = 0; i < items.size(); i++) {
        var item = items.get(i);
        var a = item.select("a").first();
        var href = a.attr("href");
        var cover = item.select(".cover .imgbox img").first().attr("data-src");
        if (!cover) {
            cover = item.select(".cover .imgbox img").first().attr("src");
        }
        if (cover && cover.indexOf("//") === 0) {
            cover = "https:" + cover;
        }
        var name = item.select(".infos h2.name").text().trim();
        
        var tagsDivs = item.select(".infos .tags");
        var author = "快看小說";
        if (tagsDivs.size() > 1) {
            author = tagsDivs.get(1).select("span").text().trim();
        }
        
        var desc = item.select(".infos .desc").text().trim();
        
        list.push({
            name: name,
            link: "https://welove-gourmet.com" + href,
            cover: cover,
            description: desc,
            author: author,
            host: "https://welove-gourmet.com"
        });
    }
    return Response.success(list);
}
