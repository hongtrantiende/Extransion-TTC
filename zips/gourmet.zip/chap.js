function execute(url) {
    var response = fetch(url, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }
    });
    
    if (!response.ok) {
        return Response.error("Lỗi kết nối");
    }
    
    var html = response.text();
    
    // Parse the style blocks to construct the icon map
    var iconMap = {};
    var styleRegex = /\.icon-(\d+):before\s*\{\s*content:\s*['"]\\([0-9a-fA-F]+)['"]/g;
    var match;
    while ((match = styleRegex.exec(html)) !== null) {
        var iconClass = "icon-" + match[1];
        var codePoint = parseInt(match[2], 16);
        iconMap[iconClass] = String.fromCharCode(codePoint);
    }
    
    // Decrypt the raw HTML using regular expression replacement
    var iTagRegex = /<i\s+class=["'](icon-\d+)["']\s*>\s*<\/i\s*>/g;
    var decryptedHtml = html.replace(iTagRegex, function(match, iconClass) {
        return iconMap[iconClass] || "";
    });
    
    var doc = Html.parse(decryptedHtml);
    var contentEl = doc.select(".novelcontent");
    if (contentEl.isEmpty()) {
        contentEl = doc.select(".chapterContent");
    }
    
    if (contentEl.isEmpty()) {
        return Response.error("Không tìm thấy nội dung chương");
    }
    contentEl = contentEl.first();
    
    // Clean unwanted elements
    contentEl.select("script").remove();
    contentEl.select("style").remove();
    contentEl.select(".novel_share_container").remove();
    contentEl.select("div[data-ads-id]").remove();
    
    var text = contentEl.html();
    return Response.success(text);
}
