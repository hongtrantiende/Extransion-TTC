function execute() {
    return Response.success([
        { title: "Tất cả", input: "https://welove-gourmet.com/library?tid=0", script: "explore.js" },
        { title: "Mới cập nhật", input: "https://welove-gourmet.com/library?sort=0", script: "explore.js" },
        { title: "Xem nhiều", input: "https://welove-gourmet.com/library?sort=1", script: "explore.js" },
        { title: "Mới nhất", input: "https://welove-gourmet.com/library?sort=2", script: "explore.js" },
        { title: "Hot hôm nay", input: "https://welove-gourmet.com/library?sort=3", script: "explore.js" },
        { title: "Hiện đại", input: "https://welove-gourmet.com/library?tid=395", script: "explore.js" },
        { title: "Huyền nghi", input: "https://welove-gourmet.com/library?tid=332", script: "explore.js" },
        { title: "Kinh dị", input: "https://welove-gourmet.com/library?tid=328", script: "explore.js" },
        { title: "Não động", input: "https://welove-gourmet.com/library?tid=331", script: "explore.js" },
        { title: "Phạm tội", input: "https://welove-gourmet.com/library?tid=361", script: "explore.js" },
        { title: "Dân gian kinh dị", input: "https://welove-gourmet.com/library?tid=408", script: "explore.js" },
        { title: "Dân gian kỳ văn", input: "https://welove-gourmet.com/library?tid=339", script: "explore.js" },
        { title: "Huyền học", input: "https://welove-gourmet.com/library?tid=373", script: "explore.js" },
        { title: "Hiện thực tình cảm", input: "https://welove-gourmet.com/library?tid=324", script: "explore.js" },
        { title: "Phục thù", input: "https://welove-gourmet.com/library?tid=330", script: "explore.js" }
    ]);
}
