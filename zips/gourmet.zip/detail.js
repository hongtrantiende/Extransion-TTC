function execute(url) {
    var response = fetch(url, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }
    });
    
    if (!response.ok) {
        return Response.error("Lỗi kết nối");
    }
    
    var doc = Html.parse(response.text());
    var name = doc.select(".bookinfocont .title .name").text().trim();
    var cover = doc.select(".bookbox .cover img").first().attr("src");
    if (cover && cover.indexOf("//") === 0) {
        cover = "https:" + cover;
    }
    
    var authorText = doc.select(".bookinfocont .author").text().trim();
    var author = authorText.replace("作者 :", "").replace("作者:", "").trim();
    if (!author) {
        author = "快看小說";
    }
    
    var desc = doc.select(".bookinfocont .desc .overdesc").text().trim();
    
    return Response.success({
        name: name,
        cover: cover,
        description: desc,
        author: author,
        host: "https://welove-gourmet.com",
        url: url
    });
}
