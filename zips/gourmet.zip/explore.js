function execute(input, page) {
    var url = input;
    if (page > 1) {
        url = input + (input.indexOf("?") > -1 ? "&" : "?") + "pi=" + page;
    }
    
    var response = fetch(url, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }
    });
    
    if (!response.ok) {
        return Response.error("Lỗi kết nối");
    }
    
    var doc = Html.parse(response.text());
    var items = doc.select(".vlist ul.nlist li");
    var list = [];
    
    for (var i = 0; i < items.size(); i++) {
        var item = items.get(i);
        var aSelect = item.select("a");
        if (aSelect.isEmpty()) continue;
        var a = aSelect.first();
        
        var href = "";
        var onClick = a.attr("onclick");
        if (onClick) {
            var match = onClick.match(/chapterJumpUrl\(['"]([^'"]+)['"]\)/);
            if (match) href = match[1];
        }
        if (!href) {
            href = a.attr("href");
        }
        if (!href) continue;
        
        if (href.indexOf("?") > -1) {
            href = href.split("?")[0];
        }
        
        var cover = item.select(".cover .imgbox img").first().attr("data-src");
        if (!cover) {
            cover = item.select(".cover .imgbox img").first().attr("src");
        }
        if (cover && cover.indexOf("//") === 0) {
            cover = "https:" + cover;
        }
        
        var name = item.select("h2.name").text().trim();
        var desc = item.select(".desc").text().trim();
        var author = "快看小說";
        
        list.push({
            name: name,
            link: "https://welove-gourmet.com" + href,
            cover: cover,
            description: desc,
            author: author,
            host: "https://welove-gourmet.com"
        });
    }
    
    return Response.success(list);
}
