function execute(url) {
    var response = fetch(url, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }
    });
    
    if (!response.ok) {
        return Response.error("Lỗi kết nối");
    }
    
    var doc = Html.parse(response.text());
    var chapters = doc.select("#chapterlist li a");
    var list = [];
    
    for (var i = 0; i < chapters.size(); i++) {
        var ch = chapters.get(i);
        var name = ch.select("h3 em").text().trim();
        if (!name) {
            name = ch.select("h3").text().trim();
        }
        var href = ch.attr("href");
        if (href && href.indexOf("http") !== 0) {
            href = "https://www.petfama.com" + href;
        }
        list.push({
            name: name,
            url: href
        });
    }
    
    return Response.success(list);
}
