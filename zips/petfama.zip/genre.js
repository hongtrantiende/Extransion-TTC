function execute() {
    return Response.success([
        { title: "Tất cả", input: "https://www.petfama.com/library", script: "explore.js" },
        { title: "Mới nhất", input: "https://www.petfama.com/library?sort=3", script: "explore.js" },
        { title: "Xem nhiều", input: "https://www.petfama.com/library?sort=1", script: "explore.js" },
        { title: "Song nam chủ", input: "https://www.petfama.com/library?tid=353", script: "explore.js" },
        { title: "Hiện đại", input: "https://www.petfama.com/library?tid=395", script: "explore.js" },
        { title: "Thuần ái", input: "https://www.petfama.com/library?tid=341", script: "explore.js" },
        { title: "Điềm sủng", input: "https://www.petfama.com/library?tid=384", script: "explore.js" }
    ]);
}
