load("config.js");

function execute(key, page) {
    page = page || "1";
    var searchUrl = BASE_URL + "/search.html";

    var response = fetch(searchUrl, {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": LINOVELIB_UA,
            "Referer": BASE_URL + "/"
        },
        body: "searchkey=" + encodeURIComponent(key) + "&searchtype=all"
    });

    if (!response.ok) return Response.error("Failed to search");

    var doc = response.html();
    var data = [];

    var items = doc.select(".book-li, .module-book-item, li.book-item, .book-layout, .w-book-item, li");
    
    items.forEach(function(item) {
        var a = item.select("a[href*=/novel/]").first();
        if (!a) return;
        var href = safeText(a.attr("href"));
        if (!href || href.indexOf("/novel/") === -1) return;
        
        var name = safeText(item.select(".book-name, .module-book-name, h2, h3, h4, .title").text());
        if (!name) name = safeText(a.text());
        if (!name) return;

        var cover = safeText(item.select("img").attr("data-src") || item.select("img").attr("src"));
        var author = safeText(item.select(".author, .book-author, .module-book-author").text());
        var desc = safeText(item.select(".intro, .desc, .book-desc, .module-book-intro").text());

        data.push({
            name: name,
            link: normalizeUrl(href),
            cover: normalizeUrl(cover),
            description: desc,
            author: author,
            host: BASE_URL
        });
    });

    var uniqueData = [];
    var seenLinks = {};
    for (var i = 0; i < data.length; i++) {
        var item = data[i];
        if (!seenLinks[item.link]) {
            seenLinks[item.link] = true;
            uniqueData.push(item);
        }
    }

    return Response.success(uniqueData);
}
