load("config.js");

function execute(url) {
    url = normalizeUrl(url);
    
    // Extract base URL without sub-page suffix (e.g., _2.html)
    var baseUrlMatch = url.match(/^(https?:\/\/[^\/]+\/novel\/\d+\/\d+)(?:_\d+)?\.html/i);
    var baseChapUrl = baseUrlMatch ? baseUrlMatch[1] : url.replace(/\.html$/i, "");

    var fullText = [];
    var pageCount = 0;
    var maxPages = 15;

    while (pageCount < maxPages) {
        pageCount++;
        var targetUrl = pageCount === 1 ? (baseChapUrl + ".html") : (baseChapUrl + "_" + pageCount + ".html");
        
        var response = fetch(targetUrl, { headers: getHeaders() });
        if (!response.ok) break;

        var doc = response.html();
        var contentEl = doc.select("#acontent, #acontent1, .read-content, #content");
        if (!contentEl || contentEl.length === 0) break;

        contentEl.select("script, style, ins, .ad, .notice").remove();

        var htmlContent = contentEl.html();
        var cleanText = htmlContent
            .replace(/<br\s*\/?>/gi, "\n")
            .replace(/<\/p>/gi, "\n\n")
            .replace(/<p[^>]*>/gi, "")
            .replace(/<[^>]+>/g, "")
            .replace(/（內容加載失敗！請刷新或更換瀏覽器）/gi, "")
            .replace(/\n{3,}/g, "\n\n")
            .trim();

        if (!cleanText || cleanText.length === 0) break;

        fullText.push(cleanText);

        // Check if there is a next sub-page link in HTML (e.g., _2.html, _3.html)
        var rawHtml = doc.html() || "";
        var nextPageToken = "_" + (pageCount + 1) + ".html";
        if (rawHtml.indexOf(nextPageToken) === -1) {
            break;
        }
    }

    if (fullText.length === 0) {
        return Response.error("Chapter content not found");
    }

    return Response.success(fullText.join("\n\n"));
}
