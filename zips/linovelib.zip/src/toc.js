load("config.js");

function execute(url) {
    url = normalizeUrl(url);
    if (url.indexOf("/catalog") === -1 && url.match(/\/novel\/\d+\.html/i)) {
        url = url.replace(/\.html$/i, "/catalog");
    }

    var response = fetch(url, { headers: getHeaders() });
    if (!response.ok) return Response.error("Failed to load catalog");

    var doc = response.html();
    var chapters = [];
    var seen = {};

    var links = doc.select("a[href*=/novel/]");
    links.forEach(function(a) {
        var href = safeText(a.attr("href"));
        if (!href || href.indexOf("/catalog") !== -1) return;
        var name = safeText(a.text());
        if (!name) return;

        // Ensure link is a chapter link (/novel/{book_id}/{chap_id}.html)
        if (href.match(/\/novel\/\d+\/\d+\.html/i)) {
            var fullUrl = normalizeUrl(href);
            if (!seen[fullUrl]) {
                seen[fullUrl] = true;
                chapters.push({
                    name: name,
                    url: fullUrl,
                    host: BASE_URL
                });
            }
        }
    });

    return Response.success(chapters);
}
