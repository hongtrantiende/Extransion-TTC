var BASE_URL = "https://m.bilinovel.com";
var LINOVELIB_UA = "Mozilla/5.0 (Linux; Android 14; Mobile; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36";

function getHeaders() {
    return {
        "User-Agent": LINOVELIB_UA,
        "Referer": BASE_URL + "/"
    };
}

function safeText(str) {
    if (!str) return "";
    return String(str).replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
}

function normalizeUrl(url) {
    if (!url) return BASE_URL;
    url = String(url).trim();
    if (url.indexOf("http://") === 0 || url.indexOf("https://") === 0) return url;
    if (url.indexOf("//") === 0) return "https:" + url;
    if (url.indexOf("/") !== 0) url = "/" + url;
    return BASE_URL + url;
}
