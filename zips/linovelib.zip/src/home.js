load("config.js");

function execute() {
    return Response.success([
        { title: "BXH Tháng", input: BASE_URL + "/top/monthvisit/1.html", script: "gen.js" },
        { title: "BXH Tuần", input: BASE_URL + "/top/weekvisit/1.html", script: "gen.js" },
        { title: "BXH Tổng", input: BASE_URL + "/top/allvisit/1.html", script: "gen.js" },
        { title: "Mới Cập Nhật", input: BASE_URL + "/top/lastupdate/1.html", script: "gen.js" },
        { title: "Nhiều Đề Xuất", input: BASE_URL + "/top/allvote/1.html", script: "gen.js" },
        { title: "Thư Viện LN", input: BASE_URL + "/wenku/", script: "gen.js" }
    ]);
}
