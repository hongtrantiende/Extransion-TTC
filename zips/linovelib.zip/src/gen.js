load("config.js");

function execute(url, page) {
    page = page || "1";
    var pageUrl = url;
    if (page !== "1" && pageUrl.indexOf(".html") !== -1) {
        pageUrl = pageUrl.replace(/(\d+)\.html$/i, page + ".html");
    }

    var response = fetch(pageUrl, { headers: getHeaders() });
    if (!response.ok) return Response.error("Failed to load page");

    var doc = response.html();
    var data = [];

    // Parse cards using JSoup selectors
    var items = doc.select(".book-li, .module-book-item, li.book-item, .book-layout, .w-book-item, li");
    
    items.forEach(function(item) {
        var a = item.select("a[href*=/novel/]").first();
        if (!a) return;
        var href = safeText(a.attr("href"));
        if (!href || href.indexOf("/novel/") === -1) return;
        
        var name = safeText(item.select(".book-name, .module-book-name, h2, h3, h4, .title").text());
        if (!name) name = safeText(a.text());
        if (!name) return;

        var cover = safeText(item.select("img").attr("data-src") || item.select("img").attr("src"));
        var author = safeText(item.select(".author, .book-author, .module-book-author").text());
        var desc = safeText(item.select(".intro, .desc, .book-desc, .module-book-intro").text());

        data.push({
            name: name,
            link: normalizeUrl(href),
            cover: normalizeUrl(cover),
            description: desc,
            author: author,
            host: BASE_URL
        });
    });

    // Deduplicate by link
    var uniqueData = [];
    var seenLinks = {};
    for (var i = 0; i < data.length; i++) {
        var item = data[i];
        if (!seenLinks[item.link]) {
            seenLinks[item.link] = true;
            uniqueData.push(item);
        }
    }

    var nextPage = null;
    if (uniqueData.length > 0) {
        nextPage = String(parseInt(page) + 1);
    }

    return Response.success(uniqueData, nextPage);
}
