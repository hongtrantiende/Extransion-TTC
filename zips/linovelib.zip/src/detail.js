load("config.js");

function execute(url) {
    url = normalizeUrl(url);
    var response = fetch(url, { headers: getHeaders() });
    if (!response.ok) return Response.error("Failed to load detail page");

    var doc = response.html();
    
    var name = safeText(doc.select("meta[property=og:novel:book_name]").attr("content"));
    if (!name) name = safeText(doc.select(".book-name, .book-title, h1").text());

    var author = safeText(doc.select("meta[property=og:novel:author]").attr("content"));
    if (!author) author = safeText(doc.select(".author, .book-author").text());

    var cover = safeText(doc.select("meta[property=og:image]").attr("content"));
    if (!cover) cover = safeText(doc.select("img.cover, .book-cover img").attr("src"));

    var desc = safeText(doc.select("meta[property=og:description]").attr("content"));
    if (!desc) desc = safeText(doc.select("#bookIntro, .book-intro, .intro").text());

    var kind = safeText(doc.select("meta[property=og:novel:category]").attr("content"));

    // Extract book ID to form catalog URL
    var match = url.match(/\/novel\/(\d+)\.html/i);
    var bookId = match ? match[1] : "";
    var catalogUrl = bookId ? (BASE_URL + "/novel/" + bookId + "/catalog") : url;

    return Response.success({
        name: name,
        cover: normalizeUrl(cover),
        author: author,
        description: desc,
        detail: catalogUrl,
        kind: kind,
        host: BASE_URL
    });
}
