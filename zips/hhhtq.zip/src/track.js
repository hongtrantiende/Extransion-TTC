load('config.js');

// TRACK v2 — Direct Only (Không browser extract)
// Chỉ hoạt động với: DU server (bysezejataos.com) và direct MP4/M3U8
// Các nguồn embed (dailymotion, ok.ru, rumble, abysscdn...) KHÔNG hỗ trợ

var DEFAULT_HEADERS = {
    "Referer": BASE_URL + "/",
    "User-Agent": USER_AGENT
};

// Chỉ hỗ trợ các nguồn direct
var SUPPORTED_SOURCES = [
    {
        name: "du",
        test: function(url) { return url.indexOf("bysezejataos.com/") >= 0; },
        referer: BASE_URL
    },
    {
        name: "direct",
        test: function(url) { return url.match(/\.(mp4|m3u8|webm)(\?|$)/i); },
        referer: BASE_URL
    }
];

// Kiểm tra nguồn có được hỗ trợ không
function findSource(url) {
    for (var i = 0; i < SUPPORTED_SOURCES.length; i++) {
        if (SUPPORTED_SOURCES[i].test(url)) return SUPPORTED_SOURCES[i];
    }
    return null;
}

// ===== MAIN EXECUTE =====
function execute(input) {
    var url;
    if (typeof input === "string") {
        url = input;
    } else if (Array.isArray(input) && input.length > 0) {
        url = input[0];
    } else if (input && typeof input === "object" && input.url) {
        url = input.url;
    } else {
        Log.log("[TRACK] Invalid input");
        return Response.success({ data: "", type: "auto", host: BASE_URL });
    }

    url = normalizeUrl(url);
    Log.log("[TRACK] Input: " + url);

    // Fetch episode page
    var resp = fetch(url, { headers: DEFAULT_HEADERS });
    if (!resp.ok) {
        Log.log("[TRACK] Fetch failed");
        return Response.success({ data: url, type: "auto", host: BASE_URL });
    }

    // Extract video URL từ player_aaaa
    var html = resp.text();
    var videoUrl = "";
    var pdMatch = html.match(/var\s+player_aaaa\s*=\s*\{[^}]+\}/i);
    if (pdMatch) {
        var urlMatch = pdMatch[0].match(/"url"\s*:\s*"([^"]+)"/i);
        if (urlMatch) videoUrl = urlMatch[1].replace(/\\\//g, "/");
    }

    if (!videoUrl) {
        Log.log("[TRACK] No video URL in page");
        return Response.success({ data: url, type: "auto", host: BASE_URL });
    }

    Log.log("[TRACK] Raw URL: " + videoUrl);

    // Đối với Spexliu/StreamQQ, trả về trực tiếp url embed dạng auto để WebView sniffing ngầm load trực tiếp (không iframe) nhằm tự động click play và lấy cookie
    if (videoUrl.indexOf("/play") !== -1 && (videoUrl.indexOf("streamqq") !== -1 || videoUrl.indexOf("trivonix") !== -1 || videoUrl.indexOf("spexliu") !== -1 || videoUrl.indexOf("bysezejataos") !== -1 || videoUrl.indexOf("grayeel") !== -1)) {
        Log.log("[TRACK] Spexliu/StreamQQ embed url direct routing: " + videoUrl);
        return Response.success({
            data: videoUrl,
            type: "auto",
            headers: {
                "Referer": BASE_URL + "/"
            },
            host: BASE_URL,
            timeSkip: []
        });
    }

    // Kiểm tra nguồn có được hỗ trợ không
    var source = findSource(videoUrl);
    
    if (!source) {
        Log.log("[TRACK] Unsupported embed source, wrapping in iframe: " + videoUrl);
        // AbyssPlayer và các embed player kiểm tra top.location == self.location.
        // Nếu load thẳng URL → detect không phải iframe → redirect sang trang chủ → sniff stuck.
        // Giải pháp: wrap trong iframe HTML → app tự convert sang data:text/html;base64 → load trong WebView
        // → player thấy top.location != self.location → pass check → JWPlayer init → CDN URL bị sniff.
        var referer = BASE_URL;
        var iframeHtml = '<!DOCTYPE html><html><head><style>' +
            '*{margin:0;padding:0;background:#000}' +
            'html,body{width:100%;height:100%;overflow:hidden}' +
            'iframe{width:100%;height:100%;border:none;display:block}' +
            '</style></head><body>' +
            '<iframe src="' + videoUrl + '" ' +
            'allowfullscreen ' +
            'allow="autoplay;encrypted-media;fullscreen;picture-in-picture" ' +
            'referrerpolicy="origin" ' +
            'scrolling="no">' +
            '</iframe></body></html>';
        return Response.success({
            data: iframeHtml,
            type: "auto",
            headers: { "Referer": referer },
            host: BASE_URL,
            timeSkip: []
        });
    }

    Log.log("[TRACK] Source: " + source.name);

    // Trả về trực tiếp cho nguồn được hỗ trợ
    return Response.success({
        data: videoUrl,
        type: "native",
        headers: { "Referer": source.referer },
        host: BASE_URL,
        timeSkip: []
    });
}