var BASE_URL = "https://hhhtq.team";

function normalizeUrl(url) {
    // Handle array input (from test tool)
    if (url && typeof url !== "string") {
        if (url.length > 0) {
            url = url[0];
        } else {
            url = BASE_URL;
        }
    }
    url = url || BASE_URL;
    
    // Normalize: thay thế domain bằng BASE_URL nhưng giữ nguyên path
    // Regex này chỉ thay thế phần protocol + domain, giữ lại path, query, hash
    return url.replace(/^https?:\/\/([^\/]+)(\/.*)?$/, function(match, domain, path) {
        path = path || "";
        return BASE_URL + path;
    });
}

function parseCards(doc) {
    var list = [];
    var seen = {};

    var items = doc.select(".module-item, .myui-vodlist__box, .myui-vodlist__item, .movie-item, .film-item, .card");

    if (items.size() === 0) {
        items = doc.select("a[href*='/phim/'], a[href*='/xem/']");
    }

    items.forEach(function(item) {
        var a = item;
        if (!item.attr("href")) {
            a = item.select("a[href*='/phim/'], a[href*='/xem/']").first();
            if (!a) {
                a = item.select("a").first();
            }
        }
        if (!a) return;
        
        var href = a.attr("href") || "";
        if (!href) return;
        if (href.indexOf("/phim/") < 0 && href.indexOf("/xem/") < 0) return;

        var convertHref = href;
        var xemMatch = href.match(/\/xem\/(\d+)-/);
        if (xemMatch) {
            convertHref = "/phim/" + xemMatch[1] + "/";
        }

        if (convertHref.indexOf("http") < 0) convertHref = BASE_URL + convertHref;
        if (seen[convertHref]) return;

        var name = a.attr("title") || "";
        if (!name) {
            var titleEl = item.select(".module-item-title, .movie-title, .title").first();
            name = titleEl ? titleEl.text().trim() : "";
        }
        if (!name) {
            name = a.text().trim();
        }
        if (name.length < 2 || name.toLowerCase().indexOf("xem thêm") >= 0) return;

        seen[convertHref] = true;

        var cover = "";
        var img = item.select("img").first();
        if (img) {
            cover = img.attr("data-src") || img.attr("data-original") || img.attr("src") || "";
        }
        if (!cover) {
            var style = a.attr("style") || "";
            var bgMatch = style.match(/url\((['"]?)(.*?)\1\)/);
            if (bgMatch) cover = bgMatch[2];
        }
        if (!cover) {
            cover = a.attr("data-original") || a.attr("data-src") || "";
        }

        var tag = "";
        var tagSelectors = ".module-item-text, .text-muted, .pic-tag, .pic-text, .tag, .episode, .pic-tag-top, .font-12, .pic-tag-bottom";
        var tagEl = item.select(tagSelectors).first();
        if (tagEl) {
            tag = tagEl.text().trim();
        }

        list.push({
            name: name,
            link: convertHref,
            cover: cover,
            tag: tag,
            host: BASE_URL
        });
    });

    return list;
}


// Bỏ parseCards cũ và parseCardsDirect, gộp vào 1 hàm parseCards duy nhất cho gọn và mạnh
function getNextPage(doc, page) {
    var nextPage = (parseInt(page, 10) || 1) + 1;
    var found = "";
    // Tìm link phân trang
    doc.select("a[href*='---']").forEach(function(a) {
        if (found) return;
        var href = a.attr("href");
        // Pattern: /show/1--------2---/
        var m = href.match(/--------(\d+)---\/?$/);
        if (m && m[1] === String(nextPage)) {
            found = String(nextPage);
        }
    });
    
    if (!found) {
        doc.select("a").forEach(function(a) {
            if (found) return;
            var text = a.text().trim();
            if (text === String(nextPage)) {
                found = String(nextPage);
            }
        });
    }
    return found;
}
