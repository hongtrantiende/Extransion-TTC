load('config.js');

// Search — URL: /?s={key} hoặc /vodsearch/?wd={key}
function execute(key, page) {
    if (!page) page = '1';

    var url = BASE_URL + "/?s=" + encodeURIComponent(key);
    var browser = Engine.newBrowser();
    var doc = browser.launch(url, 10000);
    browser.close();
    
    if (!doc) {
        return Response.success([]);
    }
    
    var list = parseCards(doc);
    if (!list || list.length === 0) {
        return Response.success([]);
    }
    
    return Response.success(list);
}

