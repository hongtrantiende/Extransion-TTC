load('config.js');

// TOC — trang /phim/{id}/
function execute(url) {
    url = normalizeUrl(url);
    var response = fetch(url, {
        headers: {
            "Referer": BASE_URL + "/"
        }
    });
    
    if (!response.ok) {
        return Response.success([]);
    }
    
    var doc = response.html();
    if (!doc) {
        return Response.success([]);
    }
    var list = [];

    // Trích xuất ID phim từ URL hiện tại để lọc các link tập phim chính xác
    var movieIdMatch = url.match(/\/phim\/(\d+)/);
    var movieId = movieIdMatch ? movieIdMatch[1] : "";

    // Tìm các server containers (#playlist1... trên desktop hoặc #sort-item-1... trên mobile)
    var servers = [];
    for (var i = 1; i <= 6; i++) {
        servers.push(["#playlist" + i, "#sort-item-" + i]);
    }
    var serverNames = ["Server 1", "Server 2", "Server 3", "Server 4", "Server 5", "Server 6"];

    var foundAny = false;
    for (var i = 0; i < servers.length; i++) {
        var container = null;
        var selectors = servers[i];
        for (var j = 0; j < selectors.length; j++) {
            container = doc.select(selectors[j]).first();
            if (container) break;
        }

        if (container) {
            var episodes = container.select("a[href*='/xem/']");
            if (episodes.size() > 0) {
                var epArray = [];
                episodes.forEach(function(a) {
                    var epUrl = a.attr("href") || "";
                    var epTitle = a.attr("title") || a.text().trim();
                    if (!epUrl || epUrl.indexOf("/xem/") < 0) return;
                    
                    // Bộ lọc: Chỉ chấp nhận link tập của đúng bộ phim này
                    if (movieId) {
                        var prefix = "/xem/" + movieId + "-";
                        if (epUrl.indexOf(prefix) < 0) return;
                    }

                    // Làm sạch tiêu đề tập
                    var cleanTitle = epTitle;
                    var aText = a.text().trim();
                    // Ưu tiên text node nếu text có dạng "Tập X"
                    if (aText && aText.match(/^Tập\s+\d+/i)) {
                        cleanTitle = aText;
                    } else if (cleanTitle) {
                        // Nếu title chứa tên phim kèm số tập dính liền (ví dụ "Tiêu Nhân (Phần 2)1")
                        var numMatch = cleanTitle.match(/(\d+)$/);
                        if (numMatch) {
                            cleanTitle = "Tập " + numMatch[1];
                        }
                    }
                    
                    if (!cleanTitle) {
                        var epMatch = epUrl.match(/-ep(\d+)/);
                        cleanTitle = epMatch ? "Tập " + epMatch[1] : "Tập";
                    }

                    if (epUrl.indexOf("http") !== 0) {
                        epUrl = BASE_URL + epUrl;
                    }
                    epArray.push({
                        name: cleanTitle,
                        url: epUrl,
                        host: BASE_URL
                    });
                });

                if (epArray.length > 0) {
                    list.push({ name: serverNames[i], type: "section" });
                    
                    // Tránh trùng lặp trong cùng server
                    var seenEp = {};
                    var uniqueEpArray = [];
                    epArray.forEach(function(ep) {
                        if (!seenEp[ep.url]) {
                            seenEp[ep.url] = true;
                            uniqueEpArray.push(ep);
                        }
                    });

                    // Sắp xếp theo số tập tăng dần
                    uniqueEpArray.sort(function(a, b) {
                        var numA = (a.url.match(/-ep(\d+)/) || [0,0])[1];
                        var numB = (b.url.match(/-ep(\d+)/) || [0,0])[1];
                        return parseInt(numA, 10) - parseInt(numB, 10);
                    });

                    for (var k = 0; k < uniqueEpArray.length; k++) {
                        list.push(uniqueEpArray[k]);
                    }
                    foundAny = true;
                }
            }
        }
    }

    // Fallback nếu không tìm thấy server container cụ thể nào
    if (!foundAny) {
        var allEpLinks = doc.select("a[href*='/xem/']");
        var serverMap = {};
        var serverOrder = [];

        allEpLinks.forEach(function(a) {
            var href = a.attr("href") || "";
            if (!href || href.indexOf("/xem/") < 0) return;
            
            // Lọc theo ID phim
            if (movieId) {
                var prefix = "/xem/" + movieId + "-";
                if (href.indexOf(prefix) < 0) return;
            }

            var svMatch = href.match(/-sv(\d+)-/);
            var svKey = svMatch ? "Server " + svMatch[1] : "Server 1";

            if (!serverMap[svKey]) {
                serverMap[svKey] = [];
                serverOrder.push(svKey);
            }

            if (href.indexOf("http") !== 0) {
                href = BASE_URL + href;
            }

            var epTitle = a.attr("title") || a.text().trim();
            var cleanTitle = epTitle;
            var aText = a.text().trim();
            if (aText && aText.match(/^Tập\s+\d+/i)) {
                cleanTitle = aText;
            } else if (cleanTitle) {
                var numMatch = cleanTitle.match(/(\d+)$/);
                if (numMatch) {
                    cleanTitle = "Tập " + numMatch[1];
                }
            }

            serverMap[svKey].push({
                name: cleanTitle,
                url: href
            });
        });

        for (var i = 0; i < serverOrder.length; i++) {
            var sv = serverOrder[i];
            var eps = serverMap[sv];
            
            if (eps.length > 0) {
                list.push({ name: sv, type: "section" });
                
                // Tránh trùng lặp
                var seenEp = {};
                var uniqueEps = [];
                eps.forEach(function(ep) {
                    if (!seenEp[ep.url]) {
                        seenEp[ep.url] = true;
                        uniqueEps.push(ep);
                    }
                });

                uniqueEps.sort(function(a, b) {
                    var numA = (a.url.match(/-ep(\d+)/) || [0,0])[1];
                    var numB = (b.url.match(/-ep(\d+)/) || [0,0])[1];
                    return parseInt(numA, 10) - parseInt(numB, 10);
                });

                for (var j = 0; j < uniqueEps.length; j++) {
                    list.push({ name: uniqueEps[j].name, url: uniqueEps[j].url, host: BASE_URL });
                }
            }
        }
    }

    return Response.success(list);
}
