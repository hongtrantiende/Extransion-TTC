load('config.js');

function execute(url) {
    url = normalizeUrl(url);

    if (url.indexOf(".mp4") !== -1 || url.indexOf(".m3u8") !== -1) {
        return Response.success({
            data: url,
            type: "native",
            headers: {
                "Referer": BASE_URL + "/"
            },
            host: BASE_URL,
            timeSkip: []
        });
    }

    // Đối với Spexliu/StreamQQ, trả về trực tiếp url embed dạng auto để WebView sniffing ngầm load trực tiếp nhằm tự động click play và lấy cookie
    if (url.indexOf("/play") !== -1 && (url.indexOf("streamqq") !== -1 || url.indexOf("trivonix") !== -1 || url.indexOf("spexliu") !== -1 || url.indexOf("bysezejataos") !== -1 || url.indexOf("grayeel") !== -1)) {
        return Response.success({
            data: url,
            type: "auto",
            headers: {
                "Referer": BASE_URL + "/"
            },
            host: BASE_URL,
            timeSkip: []
        });
    }

    return Response.success({
        data: url,
        type: "auto",
        headers: {
            "Referer": BASE_URL + "/"
        },
        host: BASE_URL,
        timeSkip: []
    });
}
