function execute(url) {
    let res = Http.get(`https://api.truyendichmienphi.com/api/novels/${url}`).string();
    let item = JSON.parse(res);
    
    let book = {
        name: item.title,
        cover: item.poster_url ? ("https://s3-hcm-r2.s3cloud.vn/tdmp/" + item.poster_url) : "",
        author: item.author_name || "Khác",
        ongoing: item.status === "ongoing",
        category: item.genres ? item.genres.map(g => g.name).join(" ") : "",
        description: item.description,
        host: "https://truyendichmienphi.com"
    };
    
    return Response.success(book);
}
