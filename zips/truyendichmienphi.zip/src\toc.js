function execute(url) {
    let res = Http.get(`https://api.truyendichmienphi.com/api/novels/${url}/chapters?limit=5000&sortBy=chapter_number:asc`).string();
    let json = JSON.parse(res);
    let list = [];
    
    json.results.forEach(item => {
        list.push({
            name: item.title,
            url: `${url}/chap/${item.slug}`,
            host: "https://truyendichmienphi.com"
        });
    });
    
    return Response.success(list);
}
