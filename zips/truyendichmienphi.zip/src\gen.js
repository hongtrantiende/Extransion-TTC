function execute(url, page) {
    if (!page) page = '1';
    let res = Http.get(`https://api.truyendichmienphi.com/api/novels/${url}?limit=20&page=${page}`).string();
    let list = JSON.parse(res);
    let books = [];
    
    list.forEach(item => {
        books.push({
            name: item.title,
            link: item.slug,
            cover: item.poster_url ? ("https://s3-hcm-r2.s3cloud.vn/tdmp/" + item.poster_url) : "",
            description: item.description,
            author: item.author_name || "Khác",
            host: "https://truyendichmienphi.com"
        });
    });
    
    let next = list.length === 20 ? (parseInt(page, 10) + 1).toString() : "";
    return Response.success(books, next);
}
