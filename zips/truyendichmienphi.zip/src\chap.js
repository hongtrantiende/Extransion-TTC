function execute(url) {
    let res = fetch(`https://api.truyendichmienphi.com/api/novels/${url}`, {
        method: "GET",
        headers: {
            "X-Chapter-Token": "e330ae3432c52784a6fd234dd1877676"
        }
    });
    
    if (res.status === 401) {
        return Response.error("Bạn cần đăng nhập trên trang truyendichmienphi.com bằng trình duyệt của ứng dụng để đọc chương này!");
    }
    
    let json = res.json();
    if (!json || !json.content) {
        return Response.error("Không thể tải nội dung chương truyện.");
    }
    
    let decrypted = CryptoJS.AES.decrypt(json.content, "z4x8vog2a13vz4x8vog2a13v").toString(CryptoJS.enc.Utf8);
    if (!decrypted) {
        return Response.error("Giải mã nội dung thất bại.");
    }
    
    let html = decrypted.trim().replace(/\n/g, "<br>");
    return Response.success(html);
}
