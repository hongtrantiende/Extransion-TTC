function execute() {
    return Response.success([
        { title: "Truyện mới cập nhật", input: "latest", script: "gen.js" },
        { title: "Truyện đọc nhiều", input: "popular", script: "gen.js" },
        { title: "Truyện đã hoàn thành", input: "completed", script: "gen.js" },
        { title: "Top đọc nhiều", input: "top-read", script: "gen.js" }
    ]);
}
