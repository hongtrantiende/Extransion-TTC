load("shared.js");

function addSingleAudioFallback(response) {
    var base;
    if (!response || !response.audios || response.audios.length !== 1) return;
    base = response.audios[0] || {};
    response.audios.push({
        data: base.data || "",
        headers: base.headers || {},
        type: base.type || "audio/mp4",
        label: trimText(base.label || "Audio") + " · dự phòng",
        language: trimText(base.language || "")
    });
    if (!response.audio && response.audios[0]) response.audio = response.audios[0].data;
}

function execute(input) {
    var payload = parseTrackPayload(input);
    payload = resolveFreshTrackPayload(payload);
    try {
        markWatchHistoryByVideoId(payload.videoId || "", false);
    } catch (e) {}
    var url = trimText(payload.url || "");
    if (!/^https?:\/\//i.test(url) && !/^data:application\/vnd\.apple\.mpegurl/i.test(url)) {
        return Response.error("URL track không hợp lệ");
    }
    var response = {
        data: url,
        type: "native",
        mimeType: trimText(payload.mimeType || ""),
        headers: {
            "Referer": trimText(payload.referer || (YT_BASE + "/")),
            "User-Agent": trimText(payload.userAgent || ANDROID_VR_CLIENT.userAgent)
        },
        timeSkip: []
    };
    if (payload.audioChoices && payload.audioChoices.length) {
        response.audios = [];
        for (var i = 0; i < payload.audioChoices.length; i++) {
            var audio = payload.audioChoices[i] || {};
            var audioUrl = trimText(audio.data || audio.url || "");
            if (!/^https?:\/\//i.test(audioUrl)) continue;
            response.audios.push({
                data: audioUrl,
                headers: {
                    "Referer": trimText(payload.referer || (YT_BASE + "/")),
                    "User-Agent": trimText(payload.userAgent || ANDROID_VR_CLIENT.userAgent)
                },
                type: trimText(audio.type || audio.mimeType || "audio/mp4"),
                label: trimText(audio.label || "Audio"),
                language: trimText(audio.language || "")
            });
        }
        if (response.audios.length) response.audio = response.audios[0].data;
    } else if (payload.audioUrl) {
        response.audio = payload.audioUrl;
        response.audios = [{
            data: payload.audioUrl,
            headers: {
                "Referer": trimText(payload.referer || (YT_BASE + "/")),
                "User-Agent": trimText(payload.userAgent || ANDROID_VR_CLIENT.userAgent)
            },
            type: trimText(payload.audioMimeType || "audio/mp4"),
            label: trimText(payload.audioLabel || "Audio"),
            language: ""
        }];
    }
    addSingleAudioFallback(response);
    if (payload.subtitles && payload.subtitles.length) {
        response.subtitles = payload.subtitles;
        response.subtitleTracks = payload.subtitles;
    } else if (payload.subtitleTracks && payload.subtitleTracks.length) {
        response.subtitles = payload.subtitleTracks;
        response.subtitleTracks = payload.subtitleTracks;
    }
    return Response.success(response);
}
