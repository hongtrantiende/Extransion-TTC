load("shared.js");

function execute(url) {
    if (!extractPlaylistId(url)) return Response.success([url]);
    return Response.success(buildPlaylistTocPages(url));
}
