load("shared.js");

function execute(input, page) {
    var payload = parsePagedInput(composePagedInput(input, page));
    var feed = parseFeedInput(payload.value);
    var pageCursor = payload.page;
    if (feed.kind === "channel" && feed.value) {
        var channelPage = fetchChannelVideoCards(feed.value, pageCursor);
        return Response.success(channelPage.items, channelPage.next);
    }
    if (feed.kind === "home-chip") {
        var homeChipPage = fetchHomeChipCards(feed.value, pageCursor);
        return Response.success(homeChipPage.items, homeChipPage.next);
    }
    if (feed.kind === "home") {
        var homePage = fetchHomeCards(pageCursor);
        return Response.success(homePage.items, homePage.next);
    }
    if (feed.kind === "subscriptions") {
        var subPage = fetchSubscriptionCards(pageCursor);
        return Response.success(subPage.items, subPage.next);
    }
    if (feed.kind === "history") {
        var historyPage = fetchHistoryCards(pageCursor);
        return Response.success(historyPage.items, historyPage.next);
    }
    if (feed.kind === "search") {
        var searchPage = fetchSearchCards(feed.value, pageCursor);
        return Response.success(searchPage.items, searchPage.next);
    }
    var videoId = getActiveVideoId(payload.value);
    return Response.success([buildSearchCard(videoId)], null);
}
