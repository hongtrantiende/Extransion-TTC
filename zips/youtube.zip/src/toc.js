load("shared.js");

function execute(url) {
    var playlistId = extractPlaylistId(url);
    if (playlistId) {
        var items = fetchPlaylistTocItems(url);
        if (!items.length) return Response.error("Playlist chưa có video");
        return Response.success(items);
    }
    var videoId = parseBookLink(url) || getActiveVideoId(url);
    return Response.success([
        {
            name: "Phát video",
            url: buildEpisodeLink(videoId),
            host: YT_BASE
        }
    ]);
}
