load("shared.js");

function execute(key, page) {
    var payload = parsePagedInput(composePagedInput(key, page));
    var videoId = extractVideoId(payload.value);
    if (videoId) return Response.success([buildSearchCard(videoId)], null);
    var result = fetchSearchCards(payload.value, payload.page);
    return Response.success(result.items, result.next);
}
