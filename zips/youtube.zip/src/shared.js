var YT_BASE = "https://www.youtube.com";
var YT_SHORT_BASE = "https://youtu.be";
var YT_EMBED_BASE = "https://www.youtube.com/embed";
var YT_OEMBED_BASE = "https://www.youtube.com/oembed";
var DEFAULT_VIDEO_ID = "aqz-KE-bpKQ";
var ANDROID_VR_CLIENT = {
    name: "ANDROID_VR",
    clientName: "ANDROID_VR",
    clientVersion: "1.65.10",
    clientNum: "28",
    userAgent: "com.google.android.apps.youtube.vr.oculus/1.65.10 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip",
    context: {
        clientName: "ANDROID_VR",
        clientVersion: "1.65.10",
        deviceMake: "Oculus",
        deviceModel: "Quest 3",
        androidSdkVersion: 32,
        userAgent: "com.google.android.apps.youtube.vr.oculus/1.65.10 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip",
        osName: "Android",
        osVersion: "12L"
    }
};
var ANDROID_CLIENT = {
    name: "ANDROID",
    clientName: "ANDROID",
    clientVersion: "20.16.32",
    clientNum: "3",
    userAgent: "com.google.android.youtube/20.16.32 (Linux; U; Android 14; en_US; Pixel 8 Pro; Build/AP1A.240405.002; Cronet/130.0.6723.0)",
    context: {
        clientName: "ANDROID",
        clientVersion: "20.16.32",
        androidSdkVersion: 34,
        userAgent: "com.google.android.youtube/20.16.32 (Linux; U; Android 14; en_US; Pixel 8 Pro; Build/AP1A.240405.002; Cronet/130.0.6723.0)",
        osName: "Android",
        osVersion: "14"
    }
};
var IOS_CLIENT = {
    name: "IOS",
    clientName: "iOS",
    clientVersion: "20.11.6",
    clientNum: "5",
    userAgent: "com.google.ios.youtube/20.11.6 (iPhone10,4; U; CPU iOS 16_7_7 like Mac OS X)",
    context: {
        clientName: "iOS",
        clientVersion: "20.11.6",
        deviceMake: "Apple",
        deviceModel: "iPhone10,4",
        userAgent: "com.google.ios.youtube/20.11.6 (iPhone10,4; U; CPU iOS 16_7_7 like Mac OS X)",
        osName: "iOS",
        osVersion: "16.7.7.20H330"
    }
};
var TV_CLIENT = {
    name: "TV",
    clientName: "TVHTML5",
    clientVersion: "7.20260311.12.00",
    clientNum: "7",
    userAgent: "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
    context: {
        clientName: "TVHTML5",
        clientVersion: "7.20260311.12.00",
        clientScreen: "WATCH",
        userAgent: "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version"
    }
};
var TV_KIDS_CLIENT = {
    name: "TV_KIDS",
    clientName: "TVHTML5_KIDS",
    clientVersion: "3.20231113.03.00",
    clientNum: "59",
    userAgent: TV_CLIENT.userAgent,
    context: {
        clientName: "TVHTML5_KIDS",
        clientVersion: "3.20231113.03.00",
        clientScreen: "WATCH",
        userAgent: TV_CLIENT.userAgent
    }
};
var WEB_SAFARI_CLIENT = {
    name: "WEB_SAFARI",
    clientName: "WEB",
    clientVersion: "2.20260206.01.00",
    clientNum: "1",
    userAgent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Safari/605.1.15,gzip(gfe)",
    context: {
        clientName: "WEB",
        clientVersion: "2.20260206.01.00",
        clientScreen: "WATCH",
        userAgent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Safari/605.1.15,gzip(gfe)",
        browserName: "Safari",
        browserVersion: "15.5"
    },
    requiresPot: true
};
var PLAYER_CLIENTS = [ANDROID_VR_CLIENT, ANDROID_CLIENT, TV_KIDS_CLIENT, TV_CLIENT, IOS_CLIENT, WEB_SAFARI_CLIENT];
var ENABLE_STATE_CACHE = false;
var CACHE_PREFIX = "yt:v2:state:";
var CACHE_INDEX_KEY = "yt:v2:state:index";
var CACHE_TTL_MS = 5 * 60 * 1000;
var CACHE_MAX_ITEMS = 12;
var WATCH_MARK_CACHE_KEY = "yt:v2:watch-mark";
var WATCH_MARK_TTL_MS = 30 * 60 * 1000;
var WATCH_MARK_MAX_ITEMS = 50;
var HOME_PAGE_CACHE_KEY = "yt:v2:home:first-page";
var HOME_PAGE_CACHE_TTL_MS = 5 * 60 * 1000;
var HOME_PAGE_CACHE_MAX_ITEMS = 36;
var YT_PREFERRED_HL = "vi";
var YT_PREFERRED_GL = "VN";
var PLAYLIST_TOC_PAGE_SIZE = 50;
var PLAYLIST_TOC_MAX_PAGE = 80;
var WEB_DESKTOP_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36,gzip(gfe)";

function trimText(value) {
    if (value == null) return "";
    return String(value).replace(/^\s+|\s+$/g, "");
}

function getRuntimeCacheValue(key) {
    try {
        if (typeof cacheStorage !== "undefined" && cacheStorage && cacheStorage.getItem) {
            return cacheStorage.getItem(key) || "";
        }
    } catch (e) { }
    try {
        if (typeof localStorage !== "undefined" && localStorage && localStorage.getItem) {
            return localStorage.getItem(key) || "";
        }
    } catch (e2) { }
    return "";
}

function setRuntimeCacheValue(key, value) {
    try {
        if (typeof cacheStorage !== "undefined" && cacheStorage && cacheStorage.setItem) {
            cacheStorage.setItem(key, value);
            return true;
        }
    } catch (e) { }
    try {
        if (typeof localStorage !== "undefined" && localStorage && localStorage.setItem) {
            localStorage.setItem(key, value);
            return true;
        }
    } catch (e2) { }
    return false;
}

function removeRuntimeCacheValue(key) {
    try {
        if (typeof cacheStorage !== "undefined" && cacheStorage && cacheStorage.removeItem) {
            cacheStorage.removeItem(key);
        }
    } catch (e) { }
    try {
        if (typeof localStorage !== "undefined" && localStorage && localStorage.removeItem) {
            localStorage.removeItem(key);
        }
    } catch (e2) { }
}

function startsWithText(value, prefix) {
    value = String(value || "");
    prefix = String(prefix || "");
    return value.slice(0, prefix.length) === prefix;
}

function extractVideoId(input) {
    if (input && typeof input === "object") {
        return extractVideoId(
            input.videoId || input.bookId || input.url || input.link || input.input || input.data || ""
        );
    }
    input = trimText(input);
    if (!input) return "";

    var match = input.match(/[?&]v=([A-Za-z0-9_-]{11})(?:[^A-Za-z0-9_-]|$)/i);
    if (match && match[1]) return match[1];

    match = input.match(/youtu\.be\/([A-Za-z0-9_-]{11})(?:[^A-Za-z0-9_-]|$)/i);
    if (match && match[1]) return match[1];

    match = input.match(/\/embed\/([A-Za-z0-9_-]{11})(?:[^A-Za-z0-9_-]|$)/i);
    if (match && match[1]) return match[1];

    match = input.match(/\/shorts\/([A-Za-z0-9_-]{11})(?:[^A-Za-z0-9_-]|$)/i);
    if (match && match[1]) return match[1];

    if (/^[A-Za-z0-9_-]{11}$/.test(input)) return input;
    return "";
}

function getConfiguredSampleId() {
    try {
        if (typeof youtubeSampleId !== "undefined" && youtubeSampleId) {
            return extractVideoId(youtubeSampleId);
        }
    } catch (e) { }
    return "";
}

function getActiveVideoId(input) {
    return extractVideoId(input) || getConfiguredSampleId() || DEFAULT_VIDEO_ID;
}

function extractPlaylistId(input) {
    if (input && typeof input === "object") {
        return extractPlaylistId(input.playlistId || input.list || input.url || input.link || input.input || input.data || "");
    }
    input = trimText(input);
    if (!input) return "";
    var match = input.match(/yt-playlist\|([A-Za-z0-9_-]+)/);
    if (match && match[1]) return trimText(match[1]);
    match = input.match(/[?&]list=([A-Za-z0-9_-]+)/i);
    if (match && match[1]) return trimText(match[1]);
    return "";
}

function buildPlaylistUrl(playlistId) {
    return YT_BASE + "/playlist?list=" + encodeURIComponent(trimText(playlistId || ""));
}

function buildPlaylistEpisodeLink(playlistId, videoId, index) {
    var url = buildWatchUrl(videoId);
    playlistId = trimText(playlistId || "");
    if (playlistId) url += "&list=" + encodeURIComponent(playlistId);
    if (index) url += "&index=" + encodeURIComponent(String(index));
    return url;
}

function buildPlaylistTocPageUrl(playlistId, page, size) {
    return appendQueryParams(buildPlaylistUrl(playlistId), {
        yt_toc_page: page,
        yt_toc_size: size || PLAYLIST_TOC_PAGE_SIZE
    });
}

function readUrlQueryParam(url, name) {
    var pattern = new RegExp("[?&]" + String(name || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "=([^&#]*)", "i");
    var match = String(url || "").match(pattern);
    return match && match[1] ? safeDecodeURIComponent(match[1]) : "";
}

function readUrlQueryNumber(url, name, fallback) {
    var value = readUrlQueryParam(url, name);
    var number = Number(String(value || "").replace(/[^\d]/g, ""));
    return number > 0 ? number : Number(fallback || 0);
}

function buildWatchUrl(videoId) {
    return YT_BASE + "/watch?v=" + trimText(videoId);
}

function buildEmbedUrl(videoId) {
    return YT_EMBED_BASE + "/" + trimText(videoId) + "?html5=1";
}

function buildThumbnailUrl(videoId) {
    return "https://i.ytimg.com/vi/" + trimText(videoId) + "/hqdefault.jpg";
}

function buildBookLink(videoId) {
    return buildWatchUrl(videoId);
}

function parseBookLink(value) {
    if (value && typeof value === "object") {
        return parseBookLink(value.url || value.link || value.input || value.data || value.bookId || value.videoId || "");
    }
    value = trimText(value);
    if (!value) return "";
    var match = value.match(/yt-book\|([A-Za-z0-9_-]{11})/);
    if (match && match[1]) return trimText(match[1]);
    return extractVideoId(value);
}

function buildEpisodeLink(videoId) {
    return buildWatchUrl(videoId);
}

function parseEpisodeLink(value) {
    if (value && typeof value === "object") {
        return parseEpisodeLink(value.url || value.link || value.input || value.data || "");
    }
    value = trimText(value);
    if (!value) return "";
    var match = value.match(/yt-episode\|([A-Za-z0-9_-]{11})/);
    if (match && match[1]) return trimText(match[1]);
    return extractVideoId(value);
}

function buildTrackPayload(payload) {
    return JSON.stringify(payload || {});
}

function parseTrackPayload(input) {
    if (input && typeof input === "object") return input;
    input = trimText(input);
    if (!input) return {};
    try {
        return JSON.parse(input);
    } catch (e) { }
    return { url: input };
}

function matchValue(text, re) {
    var match = String(text || "").match(re);
    return match && match[1] ? String(match[1]) : "";
}

function getUrlOrigin(url) {
    var match = String(url || "").match(/^(https?:\/\/[^\/?#]+)/i);
    return match && match[1] ? match[1] : "";
}

function resolveRelativeUrl(baseUrl, url) {
    baseUrl = trimText(baseUrl);
    url = trimText(url);
    if (!url) return "";
    if (/^https?:\/\//i.test(url)) return url;
    if (startsWithText(url, "//")) return "https:" + url;
    if (startsWithText(url, "/")) return getUrlOrigin(baseUrl) + url;
    return getUrlOrigin(baseUrl) + "/" + url.replace(/^\/+/, "");
}

function normalizeUrl(url) {
    url = trimText(url);
    if (!url) return "";
    if (startsWithText(url, "//")) return "https:" + url;
    if (startsWithText(url, "/")) return YT_BASE + url;
    return url;
}

function stripQueryHash(url) {
    return String(url || "").replace(/[?#].*$/, "").replace(/\/+$/, "");
}

function composeParts(parts) {
    var out = [];
    var i;
    for (i = 0; i < parts.length; i++) {
        var value = trimText(parts[i]);
        if (value) out.push(value);
    }
    return out.join(" · ");
}

function escapeHtml(text) {
    return String(text == null ? "" : text)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/\"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

function textToHtml(text) {
    return escapeHtml(text).replace(/\r\n|\r|\n/g, "<br>");
}

function getTextValue(value) {
    var out = [];
    var i;
    if (value == null) return "";
    if (typeof value === "string") return trimText(value);
    if (typeof value.content === "string") return trimText(value.content);
    if (typeof value.simpleText === "string") return trimText(value.simpleText);
    if (value.runs && value.runs.length) {
        for (i = 0; i < value.runs.length; i++) {
            if (value.runs[i] && value.runs[i].text) out.push(String(value.runs[i].text));
        }
        return trimText(out.join(""));
    }
    return "";
}

function getThumbnails(value) {
    if (!value) return [];
    if (value.thumbnails && value.thumbnails.length) return value.thumbnails;
    if (value.thumbnail && value.thumbnail.thumbnails && value.thumbnail.thumbnails.length) return value.thumbnail.thumbnails;
    return [];
}

function pickThumbnailFromValue(value) {
    var thumbs = getThumbnails(value);
    return thumbs.length ? normalizeUrl(thumbs[thumbs.length - 1].url || "") : "";
}

function extractEndpointUrl(endpoint) {
    if (!endpoint) return "";
    if (endpoint.navigationEndpoint) return extractEndpointUrl(endpoint.navigationEndpoint);
    if (endpoint.commandMetadata && endpoint.commandMetadata.webCommandMetadata && endpoint.commandMetadata.webCommandMetadata.url) {
        return normalizeUrl(endpoint.commandMetadata.webCommandMetadata.url);
    }
    if (endpoint.urlEndpoint && endpoint.urlEndpoint.url) {
        return normalizeUrl(endpoint.urlEndpoint.url);
    }
    if (endpoint.browseEndpoint && endpoint.browseEndpoint.canonicalBaseUrl) {
        return normalizeUrl(endpoint.browseEndpoint.canonicalBaseUrl);
    }
    return "";
}

function extractBalancedJson(text, start) {
    var depth = 0;
    var inString = false;
    var quote = "";
    var escaped = false;
    var i;
    for (i = start; i < text.length; i++) {
        var ch = text.charAt(i);
        if (inString) {
            if (escaped) {
                escaped = false;
            } else if (ch === "\\") {
                escaped = true;
            } else if (ch === quote) {
                inString = false;
                quote = "";
            }
            continue;
        }
        if (ch === "\"" || ch === "'") {
            inString = true;
            quote = ch;
            continue;
        }
        if (ch === "{") {
            depth++;
        } else if (ch === "}") {
            depth--;
            if (depth === 0) return text.slice(start, i + 1);
        }
    }
    return "";
}

function extractQuotedLiteral(text, start) {
    var quote = text.charAt(start);
    var escaped = false;
    var i;
    if (quote !== "\"" && quote !== "'") return "";
    for (i = start + 1; i < text.length; i++) {
        var ch = text.charAt(i);
        if (escaped) {
            escaped = false;
            continue;
        }
        if (ch === "\\") {
            escaped = true;
            continue;
        }
        if (ch === quote) return text.slice(start, i + 1);
    }
    return "";
}

function decodeJsStringLiteral(literal) {
    var quote = literal.charAt(0);
    var inner = literal.slice(1, -1);
    var out = "";
    var i = 0;
    while (i < inner.length) {
        var ch = inner.charAt(i);
        if (ch !== "\\") {
            out += ch;
            i++;
            continue;
        }
        i++;
        if (i >= inner.length) break;
        var esc = inner.charAt(i);
        if (esc === "x" && i + 2 < inner.length) {
            out += String.fromCharCode(parseInt(inner.slice(i + 1, i + 3), 16));
            i += 3;
            continue;
        }
        if (esc === "u" && i + 4 < inner.length) {
            out += String.fromCharCode(parseInt(inner.slice(i + 1, i + 5), 16));
            i += 5;
            continue;
        }
        if (esc === "n") {
            out += "\n";
        } else if (esc === "r") {
            out += "\r";
        } else if (esc === "t") {
            out += "\t";
        } else if (esc === "b") {
            out += "\b";
        } else if (esc === "f") {
            out += "\f";
        } else if (esc === "v") {
            out += "\v";
        } else if (esc === "\\" || esc === "/" || esc === "\"" || esc === "'") {
            out += esc;
        } else {
            out += esc;
        }
        i++;
    }
    return out;
}

function extractInitialDataFromHtml(html) {
    var markers = [
        "var ytInitialData = ",
        "window['ytInitialData'] = ",
        "window[\"ytInitialData\"] = ",
        "ytInitialData = "
    ];
    var i;
    for (i = 0; i < markers.length; i++) {
        var index = String(html || "").indexOf(markers[i]);
        if (index < 0) continue;
        var text = String(html || "");
        var start = index + markers[i].length;
        while (start < text.length && /\s/.test(text.charAt(start))) start++;
        var raw = "";
        var json = null;
        if (text.charAt(start) === "{") {
            raw = extractBalancedJson(text, start);
            json = safeJsonParse(raw);
        } else if (text.charAt(start) === "\"" || text.charAt(start) === "'") {
            raw = extractQuotedLiteral(text, start);
            json = safeJsonParse(decodeJsStringLiteral(raw));
        }
        if (json) return json;
    }
    return null;
}

function extractInitialPlayerResponseFromHtml(html) {
    var markers = [
        "var ytInitialPlayerResponse = ",
        "window['ytInitialPlayerResponse'] = ",
        "window[\"ytInitialPlayerResponse\"] = ",
        "ytInitialPlayerResponse = "
    ];
    var text = String(html || "");
    var i;
    for (i = 0; i < markers.length; i++) {
        var index = text.indexOf(markers[i]);
        if (index < 0) continue;
        var start = index + markers[i].length;
        var raw;
        var json;
        while (start < text.length && /\s/.test(text.charAt(start))) start++;
        if (text.charAt(start) !== "{") continue;
        raw = extractBalancedJson(text, start);
        json = safeJsonParse(raw);
        if (json) return json;
    }
    var keyIndex = text.indexOf("\"ytInitialPlayerResponse\"");
    if (keyIndex >= 0) {
        var colon = text.indexOf(":", keyIndex);
        var brace = colon >= 0 ? text.indexOf("{", colon) : -1;
        if (brace >= 0) {
            var embedded = safeJsonParse(extractBalancedJson(text, brace));
            if (embedded) return embedded;
        }
    }
    return null;
}

function collectRenderers(root, key) {
    var out = [];
    var stack = [root];
    while (stack.length) {
        var node = stack.pop();
        var prop;
        if (!node || typeof node !== "object") continue;
        if (node[key] && typeof node[key] === "object") out.push(node[key]);
        if (node.length && typeof node.length === "number") {
            for (prop = node.length - 1; prop >= 0; prop--) stack.push(node[prop]);
        } else {
            for (prop in node) {
                if (Object.prototype.hasOwnProperty.call(node, prop)) stack.push(node[prop]);
            }
        }
    }
    return out;
}

function normalizeChannelVideosUrl(url) {
    url = stripQueryHash(normalizeUrl(url));
    if (!url) return "";
    url = url.replace(/\/(featured|shorts|streams|playlists|community|about)$/, "");
    if (/\/videos$/i.test(url)) return url;
    return url + "/videos";
}

function buildDurationTag(seconds) {
    seconds = Number(seconds || 0);
    if (!seconds || seconds < 0) return "";
    var h = Math.floor(seconds / 3600);
    var m = Math.floor((seconds % 3600) / 60);
    var s = Math.floor(seconds % 60);
    function pad(value) {
        return value < 10 ? "0" + value : String(value);
    }
    if (h) return h + ":" + pad(m) + ":" + pad(s);
    return m + ":" + pad(s);
}

function extractVideoTag(renderer) {
    var tag = getTextValue(renderer.lengthText);
    if (tag) return tag;
    var overlays = renderer.thumbnailOverlays || [];
    var i;
    for (i = 0; i < overlays.length; i++) {
        var status = overlays[i] && overlays[i].thumbnailOverlayTimeStatusRenderer ? overlays[i].thumbnailOverlayTimeStatusRenderer : null;
        if (!status) continue;
        tag = getTextValue(status.text);
        if (tag) return tag;
        if (trimText(status.style) === "LIVE") return "LIVE";
    }
    if (renderer.badges && renderer.badges.length) {
        for (i = 0; i < renderer.badges.length; i++) {
            var badge = renderer.badges[i] && renderer.badges[i].metadataBadgeRenderer ? renderer.badges[i].metadataBadgeRenderer : null;
            var label = badge ? getTextValue(badge.label) : "";
            if (/live/i.test(label)) return "LIVE";
        }
    }
    if (renderer.upcomingEventData) return "SẮP CHIẾU";
    if (renderer.lengthSeconds) return buildDurationTag(renderer.lengthSeconds);
    return "";
}

function safeDecodeURIComponent(value) {
    try {
        return decodeURIComponent(String(value || ""));
    } catch (e) {
        return trimText(value);
    }
}

function buildFeedInput(kind, value) {
    return "yt-feed|" + trimText(kind) + "|" + encodeURIComponent(trimText(value));
}

function parsePagedInput(input) {
    if (input && typeof input === "object") {
        return parsePagedInput(input.url || input.link || input.input || input.data || "");
    }
    input = trimText(input);
    if (!input) return { value: "", page: "1" };
    var index = input.lastIndexOf(",");
    if (index < 0) return { value: input, page: "1" };
    var suffix = trimText(input.slice(index + 1));
    if (!suffix || (!/^\d+$/.test(suffix) && !startsWithText(suffix, "yt-next|"))) {
        return { value: input, page: "1" };
    }
    return {
        value: trimText(input.slice(0, index)),
        page: suffix || "1"
    };
}

function composePagedInput(value, page) {
    value = trimText(value);
    page = trimText(page);
    if (!page) return value;
    return value + ", " + page;
}

function parseFeedInput(input) {
    if (input && typeof input === "object") {
        return parseFeedInput(input.url || input.link || input.input || input.data || "");
    }
    input = trimText(input);
    if (!input) return { kind: "", value: "" };
    if (startsWithText(input, "yt-feed|")) {
        var parts = input.split("|");
        return {
            kind: trimText(parts[1] || ""),
            value: safeDecodeURIComponent(parts.slice(2).join("|"))
        };
    }
    if (/youtube\.com\/@|youtube\.com\/channel\/|youtube\.com\/c\/|youtube\.com\/user\//i.test(input)) {
        return {
            kind: "channel",
            value: normalizeChannelVideosUrl(input)
        };
    }
    return { kind: "", value: input };
}

function isFirstPageCursor(value) {
    value = trimText(value);
    return !value || value === "1";
}

function buildContinuationCursor(token, apiUrl, clickTrackingParams) {
    token = trimText(token);
    apiUrl = trimText(apiUrl || "/youtubei/v1/browse");
    if (!token) return null;
    clickTrackingParams = trimText(clickTrackingParams || "");
    var cursor = "yt-next|" + encodeURIComponent(apiUrl) + "|" + encodeURIComponent(token);
    if (clickTrackingParams) cursor += "|" + encodeURIComponent(clickTrackingParams);
    return cursor;
}

function parseContinuationCursor(value) {
    value = trimText(value);
    if (!startsWithText(value, "yt-next|")) {
        return {
            token: value,
            apiUrl: "/youtubei/v1/browse",
            clickTrackingParams: ""
        };
    }
    var parts = value.split("|");
    var token = "";
    var clickTrackingParams = "";
    if (parts.length > 3) {
        token = safeDecodeURIComponent(parts[2] || "");
        clickTrackingParams = safeDecodeURIComponent(parts.slice(3).join("|"));
    } else {
        token = safeDecodeURIComponent(parts.slice(2).join("|"));
    }
    return {
        apiUrl: safeDecodeURIComponent(parts[1] || "/youtubei/v1/browse") || "/youtubei/v1/browse",
        token: token,
        clickTrackingParams: clickTrackingParams
    };
}

function collectContinuationEntries(root) {
    var out = [];

    function walk(node, path) {
        var i;
        var key;
        if (!node || typeof node !== "object") return;
        if (node.continuationItemRenderer) {
            var renderer = node.continuationItemRenderer || {};
            var endpoint = renderer.continuationEndpoint || {};
            var command = endpoint.continuationCommand || endpoint.nextContinuationData || endpoint.reloadContinuationData || {};
            var apiUrl = endpoint.commandMetadata && endpoint.commandMetadata.webCommandMetadata
                ? trimText(endpoint.commandMetadata.webCommandMetadata.apiUrl || "")
                : "";
            out.push({
                path: path.join("."),
                token: trimText(command.token || command.continuation || ""),
                clickTrackingParams: trimText(endpoint.clickTrackingParams || command.clickTrackingParams || ""),
                apiUrl: apiUrl || "/youtubei/v1/next"
            });
        }
        if (node.length && typeof node.length === "number") {
            for (i = 0; i < node.length; i++) walk(node[i], path.concat("[" + i + "]"));
            return;
        }
        for (key in node) {
            if (Object.prototype.hasOwnProperty.call(node, key)) walk(node[key], path.concat(key));
        }
    }

    walk(root || {}, []);
    return out;
}

function extractVideoAuthor(renderer) {
    return getTextValue(renderer.longBylineText) ||
        getTextValue(renderer.shortBylineText) ||
        getTextValue(renderer.ownerText) ||
        getTextValue(renderer.channelTitleText) ||
        "";
}

function extractVideoViews(renderer) {
    return getTextValue(renderer.shortViewCountText) ||
        getTextValue(renderer.viewCountText) ||
        "";
}

function extractVideoPublished(renderer) {
    return getTextValue(renderer.publishedTimeText);
}

function buildVideoDescription(renderer) {
    return composeParts([
        extractVideoAuthor(renderer),
        extractVideoPublished(renderer),
        extractVideoViews(renderer)
    ]);
}

function buildVideoCardFromRenderer(renderer) {
    var videoId = trimText(renderer && renderer.videoId ? renderer.videoId : "");
    var title = getTextValue(renderer && renderer.title ? renderer.title : null) ||
        getTextValue(renderer && renderer.headline ? renderer.headline : null);
    if (!videoId || !title) return null;
    return {
        name: title,
        link: buildBookLink(videoId),
        cover: pickThumbnailFromValue(renderer.thumbnail || renderer),
        description: buildVideoDescription(renderer),
        tag: extractVideoTag(renderer)
    };
}

function getImageSources(value) {
    if (!value) return [];
    if (value.sources && value.sources.length) return value.sources;
    if (value.image && value.image.sources && value.image.sources.length) return value.image.sources;
    if (value.thumbnailViewModel && value.thumbnailViewModel.image && value.thumbnailViewModel.image.sources && value.thumbnailViewModel.image.sources.length) {
        return value.thumbnailViewModel.image.sources;
    }
    return [];
}

function pickImageSourceUrl(value) {
    var sources = getImageSources(value);
    return sources.length ? normalizeUrl(sources[sources.length - 1].url || "") : "";
}

function extractLockupVideoId(lockup) {
    var videoId = trimText(lockup && lockup.contentId ? lockup.contentId : "");
    if (extractVideoId(videoId)) return videoId;
    var command = lockup && lockup.rendererContext && lockup.rendererContext.commandContext && lockup.rendererContext.commandContext.onTap
        ? lockup.rendererContext.commandContext.onTap.innertubeCommand || {}
        : {};
    if (command.watchEndpoint && command.watchEndpoint.videoId) return trimText(command.watchEndpoint.videoId);
    return "";
}

function extractLockupRows(lockup) {
    var rows = [];
    var metadata = lockup && lockup.metadata && lockup.metadata.lockupMetadataViewModel
        ? lockup.metadata.lockupMetadataViewModel.metadata && lockup.metadata.lockupMetadataViewModel.metadata.contentMetadataViewModel
            ? lockup.metadata.lockupMetadataViewModel.metadata.contentMetadataViewModel
            : null
        : null;
    var metadataRows = metadata && metadata.metadataRows ? metadata.metadataRows : [];
    var i;
    var j;
    for (i = 0; i < metadataRows.length; i++) {
        var parts = metadataRows[i] && metadataRows[i].metadataParts ? metadataRows[i].metadataParts : [];
        var values = [];
        for (j = 0; j < parts.length; j++) {
            var text = parts[j] && parts[j].text ? getTextValue(parts[j].text) : "";
            if (text) values.push(text);
        }
        if (values.length) rows.push(values);
    }
    return rows;
}

function extractLockupTag(lockup) {
    var overlays = lockup && lockup.contentImage && lockup.contentImage.thumbnailViewModel && lockup.contentImage.thumbnailViewModel.overlays
        ? lockup.contentImage.thumbnailViewModel.overlays
        : [];
    var i;
    var j;
    for (i = 0; i < overlays.length; i++) {
        var overlay = overlays[i] && overlays[i].thumbnailBottomOverlayViewModel ? overlays[i].thumbnailBottomOverlayViewModel : null;
        var badges = overlay && overlay.badges ? overlay.badges : [];
        for (j = 0; j < badges.length; j++) {
            var badge = badges[j] && badges[j].thumbnailBadgeViewModel ? badges[j].thumbnailBadgeViewModel : null;
            var text = badge ? getTextValue(badge.text) : "";
            if (text) return text;
        }
    }
    return "";
}

function buildVideoCardFromLockup(lockup) {
    var videoId = extractLockupVideoId(lockup);
    var contentType = trimText(lockup && lockup.contentType ? lockup.contentType : "");
    var title = lockup && lockup.metadata && lockup.metadata.lockupMetadataViewModel
        ? getTextValue(lockup.metadata.lockupMetadataViewModel.title)
        : "";
    if (!videoId || !title) return null;
    if (contentType && !/VIDEO|SHORT/i.test(contentType)) return null;
    var rows = extractLockupRows(lockup);
    return {
        name: title,
        link: buildBookLink(videoId),
        cover: pickImageSourceUrl(lockup && lockup.contentImage ? lockup.contentImage : null),
        description: composeParts([].concat(rows.length ? rows[0] : [], rows.length > 1 ? rows[1] : [])),
        tag: extractLockupTag(lockup)
    };
}

function pushUniqueCard(list, seen, card) {
    if (!card || !card.link || seen[card.link]) return;
    seen[card.link] = true;
    list.push(card);
}

function buildVideoCardsFromInitialData(initialData) {
    var cards = [];
    var seen = {};
    var keys = ["videoRenderer", "videoWithContextRenderer", "gridVideoRenderer", "compactVideoRenderer"];
    var i;
    var j;
    for (i = 0; i < keys.length; i++) {
        var renderers = collectRenderers(initialData, keys[i]);
        for (j = 0; j < renderers.length; j++) {
            pushUniqueCard(cards, seen, buildVideoCardFromRenderer(renderers[j]));
        }
    }
    var lockups = collectRenderers(initialData, "lockupViewModel");
    for (i = 0; i < lockups.length; i++) {
        pushUniqueCard(cards, seen, buildVideoCardFromLockup(lockups[i]));
    }
    return cards;
}

function buildPlaylistEpisodeItemsFromData(root, playlistId, startIndex, seen) {
    var renderers = collectRenderers(root || {}, "playlistVideoRenderer");
    var items = [];
    var i;
    var index = Number(startIndex || 1);
    seen = seen || {};
    for (i = 0; i < renderers.length; i++) {
        var renderer = renderers[i] || {};
        var videoId = trimText(renderer.videoId || "");
        var title = getTextValue(renderer.title);
        var author = extractVideoAuthor(renderer);
        var duration = getTextValue(renderer.lengthText) || extractVideoTag(renderer);
        if (!extractVideoId(videoId) || !title || seen[videoId]) continue;
        if (renderer.isPlayable === false) continue;
        seen[videoId] = true;
        items.push({
            name: "Tập " + index + " - " + title,
            url: buildPlaylistEpisodeLink(playlistId, videoId, index),
            host: YT_BASE,
            description: composeParts([author, duration])
        });
        index++;
    }
    return {
        items: items,
        nextIndex: index
    };
}

function extractPlaylistTitle(initialData, fallback) {
    var renderers;
    var i;
    var title = "";
    renderers = collectRenderers(initialData || {}, "playlistHeaderRenderer");
    for (i = 0; i < renderers.length && !title; i++) title = getTextValue(renderers[i].title);
    renderers = collectRenderers(initialData || {}, "playlistSidebarPrimaryInfoRenderer");
    for (i = 0; i < renderers.length && !title; i++) title = getTextValue(renderers[i].title);
    renderers = collectRenderers(initialData || {}, "pageHeaderRenderer");
    for (i = 0; i < renderers.length && !title; i++) title = getTextValue(renderers[i].pageTitle) || getTextValue(renderers[i].title);
    renderers = collectRenderers(initialData || {}, "pageHeaderViewModel");
    for (i = 0; i < renderers.length && !title; i++) title = getTextValue(renderers[i].title);
    return title || trimText(fallback || "YouTube Playlist");
}

function parsePlaylistCountText(text) {
    var match = String(text || "").match(/(\d[\d\s.,]*)(?:\+)?\s*(?:videos?|video)\b/i);
    var digits;
    if (!match || !match[1]) return 0;
    digits = String(match[1] || "").replace(/[^\d]/g, "");
    return Number(digits || 0);
}

function extractPlaylistVideoCount(initialData) {
    var values = [];
    var seen = {};
    var best = 0;
    var roots = [];
    var keys = ["playlistHeaderRenderer", "playlistSidebarPrimaryInfoRenderer", "pageHeaderRenderer", "pageHeaderViewModel"];
    var i;
    var j;

    function pushValue(value) {
        var text = getTextValue(value) || (typeof value === "string" || typeof value === "number" ? String(value) : "");
        if (!text || seen[text]) return;
        seen[text] = true;
        values.push(text);
    }

    function scan(node, key) {
        var prop;
        if (!node || typeof node !== "object") return;
        if (key === "numVideosText" || key === "videoCountText") pushValue(node);
        if (node.length && typeof node.length === "number") {
            for (prop = 0; prop < node.length; prop++) scan(node[prop], "");
            return;
        }
        for (prop in node) {
            if (!Object.prototype.hasOwnProperty.call(node, prop)) continue;
            if (prop === "numVideosText" || prop === "videoCountText") pushValue(node[prop]);
            if (typeof node[prop] === "string" && /videos?|video/i.test(node[prop])) pushValue(node[prop]);
            scan(node[prop], prop);
        }
    }

    for (i = 0; i < keys.length; i++) {
        var renderers = collectRenderers(initialData || {}, keys[i]);
        for (j = 0; j < renderers.length; j++) roots.push(renderers[j]);
    }
    for (i = 0; i < roots.length; i++) scan(roots[i], "");
    for (i = 0; i < values.length; i++) {
        var count = parsePlaylistCountText(values[i]);
        if (count > best) best = count;
    }
    return best;
}

function buildPlaylistDetail(input) {
    var playlistId = extractPlaylistId(input);
    var page = fetchInitialDataPage(buildPlaylistUrl(playlistId));
    var seen = {};
    var first = buildPlaylistEpisodeItemsFromData(page.initialData || {}, playlistId, 1, seen).items;
    var title = extractPlaylistTitle(page.initialData || {}, "YouTube Playlist");
    var cover = first.length ? pickThumbnail(getVideoState(extractVideoId(first[0].url))) : "";
    var count = extractPlaylistVideoCount(page.initialData || {});
    return {
        bookId: "yt-playlist|" + playlistId,
        name: title,
        cover: cover,
        host: YT_BASE,
        author: "YouTube",
        description: "",
        detail: count ? ("Danh sách phát · " + count + " video") : (first.length ? ("Danh sách phát · " + first.length + "+ video") : "Danh sách phát"),
        ongoing: false,
        type: "video",
        suggests: [],
        comments: []
    };
}

function buildPlaylistTocPages(input) {
    var playlistId = extractPlaylistId(input);
    var page;
    var first;
    var next;
    var count;
    var totalPages;
    var pages = [];
    var size = PLAYLIST_TOC_PAGE_SIZE;
    if (!playlistId) return [input];
    page = fetchInitialDataPage(buildPlaylistUrl(playlistId));
    first = buildPlaylistEpisodeItemsFromData(page.initialData || {}, playlistId, 1, {}).items;
    next = extractNextContinuation(page.initialData || {}, "/youtubei/v1/browse");
    count = extractPlaylistVideoCount(page.initialData || {});
    if (count > 0) {
        totalPages = Math.ceil(count / size);
    } else {
        totalPages = Math.ceil(first.length / size);
        if (next && next.token) totalPages++;
    }
    if (totalPages < 1) totalPages = 1;
    if (totalPages > PLAYLIST_TOC_MAX_PAGE) totalPages = PLAYLIST_TOC_MAX_PAGE;
    for (var i = 1; i <= totalPages; i++) {
        pages.push(buildPlaylistTocPageUrl(playlistId, i, size));
    }
    return pages.length ? pages : [buildPlaylistUrl(playlistId)];
}

function fetchPlaylistTocPageItems(input, requestedPage, requestedSize) {
    var playlistId = extractPlaylistId(input);
    var page = fetchInitialDataPage(buildPlaylistUrl(playlistId));
    var config = extractWebClientConfigFromHtml(page.html || "");
    var seen = {};
    var first = buildPlaylistEpisodeItemsFromData(page.initialData || {}, playlistId, 1, seen);
    var items = first.items;
    var nextIndex = first.nextIndex;
    var next = extractNextContinuation(page.initialData || {}, "/youtubei/v1/browse");
    var targetStart = (requestedPage - 1) * requestedSize;
    var targetEnd = targetStart + requestedSize;
    var guard = 0;
    while (next && next.token && guard < PLAYLIST_TOC_MAX_PAGE && items.length < targetEnd) {
        var cursor = buildContinuationCursor(next.token, next.apiUrl, next.clickTrackingParams);
        var json = postContinuation(cursor, config);
        var batch = buildPlaylistEpisodeItemsFromData(json || {}, playlistId, nextIndex, seen);
        if (!batch.items.length) break;
        for (var i = 0; i < batch.items.length; i++) items.push(batch.items[i]);
        nextIndex = batch.nextIndex;
        next = extractNextContinuation(json || {}, "/youtubei/v1/browse");
        guard++;
    }
    return items.slice(targetStart, targetEnd);
}

function fetchPlaylistTocItems(input) {
    var playlistId = extractPlaylistId(input);
    var requestedPage = readUrlQueryNumber(input, "yt_toc_page", 0);
    var requestedSize = readUrlQueryNumber(input, "yt_toc_size", PLAYLIST_TOC_PAGE_SIZE) || PLAYLIST_TOC_PAGE_SIZE;
    if (requestedPage > 0) return fetchPlaylistTocPageItems(input, requestedPage, requestedSize);
    var page = fetchInitialDataPage(buildPlaylistUrl(playlistId));
    var config = extractWebClientConfigFromHtml(page.html || "");
    var seen = {};
    var first = buildPlaylistEpisodeItemsFromData(page.initialData || {}, playlistId, 1, seen);
    var items = first.items;
    var nextIndex = first.nextIndex;
    var next = extractNextContinuation(page.initialData || {}, "/youtubei/v1/browse");
    var guard = 0;
    while (next && next.token && guard < 20 && items.length < 500) {
        var cursor = buildContinuationCursor(next.token, next.apiUrl, next.clickTrackingParams);
        var json = postContinuation(cursor, config);
        var batch = buildPlaylistEpisodeItemsFromData(json || {}, playlistId, nextIndex, seen);
        if (!batch.items.length) break;
        for (var i = 0; i < batch.items.length; i++) items.push(batch.items[i]);
        nextIndex = batch.nextIndex;
        next = extractNextContinuation(json || {}, "/youtubei/v1/browse");
        guard++;
    }
    return items;
}

function extractContinuationFromEndpoint(endpoint, fallbackApiUrl) {
    endpoint = endpoint || {};
    if (endpoint.commandExecutorCommand && endpoint.commandExecutorCommand.commands) {
        var commands = endpoint.commandExecutorCommand.commands || [];
        for (var commandIndex = 0; commandIndex < commands.length; commandIndex++) {
            var nested = extractContinuationFromEndpoint(commands[commandIndex], fallbackApiUrl);
            if (nested && nested.token) return nested;
        }
    }
    var command = endpoint.continuationCommand ||
        endpoint.nextContinuationData ||
        endpoint.reloadContinuationData ||
        endpoint.timedContinuationData ||
        endpoint.invalidationContinuationData ||
        endpoint.liveChatReplayContinuationData ||
        {};
    if (!command.token && !command.continuation &&
        (typeof endpoint.token === "string" || typeof endpoint.continuation === "string")) {
        command = endpoint;
    }
    var tokenValue = typeof command.token === "string" || typeof command.token === "number"
        ? command.token
        : (typeof command.continuation === "string" || typeof command.continuation === "number" ? command.continuation : "");
    var token = trimText(tokenValue || "");
    var clickTrackingParams = trimText(endpoint.clickTrackingParams || command.clickTrackingParams || "");
    var apiUrl = endpoint.commandMetadata && endpoint.commandMetadata.webCommandMetadata
        ? trimText(endpoint.commandMetadata.webCommandMetadata.apiUrl || "")
        : "";
    if (!apiUrl) apiUrl = trimText(fallbackApiUrl || "/youtubei/v1/browse");
    if (!token) return null;
    return {
        token: token,
        apiUrl: apiUrl,
        clickTrackingParams: clickTrackingParams
    };
}

function extractNextContinuation(initialData, fallbackApiUrl) {
    var renderers = collectRenderers(initialData, "continuationItemRenderer");
    var i;
    for (i = 0; i < renderers.length; i++) {
        var renderer = renderers[i] || {};
        var endpoint = renderer.continuationEndpoint ||
            (renderer.button && renderer.button.buttonRenderer ? (renderer.button.buttonRenderer.command || renderer.button.buttonRenderer.navigationEndpoint || {}) : {});
        var info = extractContinuationFromEndpoint(endpoint, fallbackApiUrl);
        if (info && info.token) return info;
    }

    var nextData = collectRenderers(initialData, "nextContinuationData");
    for (i = 0; i < nextData.length; i++) {
        var nextInfo = extractContinuationFromEndpoint(nextData[i], fallbackApiUrl);
        if (nextInfo && nextInfo.token) return nextInfo;
    }

    var reloadData = collectRenderers(initialData, "reloadContinuationData");
    for (i = 0; i < reloadData.length; i++) {
        var reloadInfo = extractContinuationFromEndpoint(reloadData[i], fallbackApiUrl);
        if (reloadInfo && reloadInfo.token) return reloadInfo;
    }

    return null;
}

function findSelectedTabContent(initialData) {
    var roots = [];
    var i;
    if (initialData && initialData.contents && initialData.contents.singleColumnBrowseResultsRenderer && initialData.contents.singleColumnBrowseResultsRenderer.tabs) {
        roots.push(initialData.contents.singleColumnBrowseResultsRenderer.tabs);
    }
    if (initialData && initialData.contents && initialData.contents.twoColumnBrowseResultsRenderer && initialData.contents.twoColumnBrowseResultsRenderer.tabs) {
        roots.push(initialData.contents.twoColumnBrowseResultsRenderer.tabs);
    }
    for (i = 0; i < roots.length; i++) {
        var tabs = roots[i] || [];
        var j;
        for (j = 0; j < tabs.length; j++) {
            var tab = tabs[j] && tabs[j].tabRenderer ? tabs[j].tabRenderer : null;
            if (tab && tab.selected && tab.content) return tab.content;
        }
    }
    return null;
}

function extractSelectedTabContinuation(initialData, fallbackApiUrl) {
    var content = findSelectedTabContent(initialData);
    if (!content) return null;
    return extractNextContinuation(content, fallbackApiUrl);
}

function buildPagedVideoCardsFromInitialData(initialData, fallbackApiUrl, options) {
    options = options || {};
    var next = null;
    if (options.selectedTabOnly) {
        next = extractSelectedTabContinuation(initialData || {}, fallbackApiUrl);
    } else if (!options.disableNext) {
        next = extractNextContinuation(initialData || {}, fallbackApiUrl);
    }
    return {
        items: buildVideoCardsFromInitialData(initialData || {}),
        next: next ? buildContinuationCursor(next.token, next.apiUrl, next.clickTrackingParams) : null
    };
}

function isSoftReloadHomeResponse(json) {
    var promos = collectRenderers(json || {}, "backgroundPromoRenderer");
    var i;
    var j;
    for (i = 0; i < promos.length; i++) {
        var promo = promos[i] || {};
        var title = getTextValue(promo.title).toLowerCase();
        if (title.indexOf("expired") >= 0) return true;
        var button = promo.ctaButton && promo.ctaButton.buttonRenderer ? promo.ctaButton.buttonRenderer : {};
        var actions = button.serviceEndpoint && button.serviceEndpoint.signalServiceEndpoint
            ? button.serviceEndpoint.signalServiceEndpoint.actions || []
            : [];
        for (j = 0; j < actions.length; j++) {
            var signal = actions[j] && actions[j].signalAction ? trimText(actions[j].signalAction.signal || "") : "";
            if (signal === "SOFT_RELOAD_PAGE") return true;
        }
    }
    return false;
}

function extractChannelTitle(renderer) {
    return getTextValue(renderer.title) ||
        getTextValue(renderer.channelTitle) ||
        getTextValue(renderer.shortBylineText) ||
        "";
}

function extractChannelDescription(renderer) {
    return composeParts([
        getTextValue(renderer.subscriberCountText),
        getTextValue(renderer.videoCountText) || getTextValue(renderer.subscribedText)
    ]) || getTextValue(renderer.descriptionSnippet);
}

function extractChannelUrl(renderer) {
    var url = extractEndpointUrl(renderer.navigationEndpoint || renderer);
    if (!url && renderer.channelId) url = YT_BASE + "/channel/" + trimText(renderer.channelId);
    return normalizeChannelVideosUrl(url);
}

function buildGenreItemFromRenderer(renderer) {
    var title = extractChannelTitle(renderer);
    var channelUrl = extractChannelUrl(renderer);
    if (!title || !channelUrl) return null;
    return {
        title: title,
        input: buildFeedInput("channel", channelUrl),
        script: "gen.js"
    };
}

function buildChannelItemsFromInitialData(initialData) {
    var items = [];
    var seen = {};
    var keys = ["channelRenderer", "gridChannelRenderer", "compactChannelRenderer", "channelListItemRenderer"];
    var i;
    var j;
    for (i = 0; i < keys.length; i++) {
        var renderers = collectRenderers(initialData, keys[i]);
        for (j = 0; j < renderers.length; j++) {
            var item = buildGenreItemFromRenderer(renderers[j]);
            if (!item || !item.input || seen[item.input]) continue;
            seen[item.input] = true;
            items.push(item);
        }
    }
    return items;
}

function extractWebClientConfigFromHtml(html) {
    return {
        apiKey: matchValue(html, /"INNERTUBE_API_KEY":"([^"]+)"/),
        visitorData: matchValue(html, /"VISITOR_DATA":"([^"]+)"/),
        clientVersion: matchValue(html, /"INNERTUBE_CLIENT_VERSION":"([^"]+)"/) || "2.20260422.01.00"
    };
}

function postContinuation(cursor, config) {
    if (!config || !config.apiKey) return {};
    var continuation = parseContinuationCursor(cursor);
    var token = trimText(continuation.token || "");
    var apiUrl = trimText(continuation.apiUrl || "/youtubei/v1/browse") || "/youtubei/v1/browse";
    if (!token) return {};
    var clientVersion = trimText(config.clientVersion || "2.20260422.01.00");
    var visitorData = trimText(config.visitorData || "");
    var webUserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36,gzip(gfe)";
    var body = {
        continuation: token,
        context: {
            client: {
                clientName: "WEB",
                clientVersion: clientVersion,
                hl: "vi",
                gl: "VN",
                visitorData: visitorData,
                userAgent: webUserAgent,
                originalUrl: YT_BASE + "/",
                platform: "DESKTOP",
                clientFormFactor: "UNKNOWN_FORM_FACTOR",
                osName: "Windows",
                osVersion: "10.0",
                browserName: "Chrome",
                browserVersion: "147.0.0.0",
                utcOffsetMinutes: 420
            },
            request: {
                useSsl: true,
                internalExperimentFlags: [],
                consistencyTokenJars: []
            },
            user: {
                lockedSafetyMode: false
            }
        }
    };
    if (continuation.clickTrackingParams) {
        body.context.clickTracking = {
            clickTrackingParams: continuation.clickTrackingParams
        };
    }
    var response = fetch(YT_BASE + apiUrl + "?prettyPrint=false&key=" + config.apiKey, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Origin": YT_BASE,
            "User-Agent": webUserAgent,
            "X-Goog-Visitor-Id": visitorData,
            "X-YouTube-Client-Name": "1",
            "X-YouTube-Client-Version": clientVersion
        },
        body: JSON.stringify(body)
    });
    return safeJsonParse(String(response.text() || "")) || {};
}

function postLiveChatContinuation(cursor, config) {
    if (!config || !config.apiKey) return {};
    var continuation = parseContinuationCursor(cursor);
    var token = trimText(continuation.token || "");
    var apiUrl = trimText(continuation.apiUrl || "/youtubei/v1/live_chat/get_live_chat") || "/youtubei/v1/live_chat/get_live_chat";
    var visitorData = trimText(config.visitorData || "");
    var clientVersion = trimText(TV_CLIENT.clientVersion || "7.20260311.12.00");
    var body;
    var response;
    if (!token) return {};
    body = {
        context: {
            client: {
                clientName: "TVHTML5",
                clientVersion: clientVersion,
                clientScreen: "WATCH",
                hl: "vi",
                gl: "VN",
                visitorData: visitorData,
                userAgent: TV_CLIENT.userAgent,
                tvAppInfo: {
                    appQuality: "TV_APP_QUALITY_FULL_ANIMATION",
                    zylonLeftNav: true
                },
                webpSupport: false,
                animatedWebpSupport: true,
                utcOffsetMinutes: "420",
                acceptLanguage: "vi",
                acceptRegion: "VN"
            },
            request: {
                useSsl: true,
                internalExperimentFlags: [],
                consistencyTokenJars: []
            },
            user: {
                enableSafetyMode: false,
                lockedSafetyMode: false
            }
        },
        racyCheckOk: true,
        contentCheckOk: true,
        continuation: token
    };
    response = fetch(YT_BASE + apiUrl + "?prettyPrint=false", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Origin": "https://www.youtube.com",
            "Referer": "https://www.youtube.com/tv",
            "User-Agent": TV_CLIENT.userAgent,
            "X-Goog-Visitor-Id": visitorData,
            "X-YouTube-Client-Name": TV_CLIENT.clientNum,
            "X-YouTube-Client-Version": clientVersion
        },
        body: JSON.stringify(body)
    });
    return safeJsonParse(String(response.text() || "")) || {};
}

function postBrowseContinuation(token, config) {
    return postContinuation(buildContinuationCursor(token, "/youtubei/v1/browse"), config);
}

function buildPreferredWebHeaders(headers) {
    var out = {
        "Referer": YT_BASE + "/",
        "Accept-Language": YT_PREFERRED_HL + ",en;q=0.9,en-US;q=0.8"
    };
    headers = headers || {};
    for (var key in headers) {
        if (Object.prototype.hasOwnProperty.call(headers, key)) out[key] = headers[key];
    }
    return out;
}

function buildLocalizedYouTubeUrl(url) {
    url = trimText(url || "");
    if (!url || !/https?:\/\/([^\/]+\.)?(youtube\.com|youtu\.be)\//i.test(url)) return url;
    return appendQueryParams(url, {
        hl: YT_PREFERRED_HL,
        gl: YT_PREFERRED_GL
    });
}

function fetchInitialDataPage(url) {
    var pageUrl = buildLocalizedYouTubeUrl(url);
    var result = fetchText(pageUrl, {
        headers: buildPreferredWebHeaders()
    });
    return {
        status: result.status,
        ok: result.ok,
        url: pageUrl,
        html: result.text,
        initialData: extractInitialDataFromHtml(result.text),
        initialPlayer: extractInitialPlayerResponseFromHtml(result.text) || {}
    };
}

function fetchWatchPageContext(videoId) {
    var page = fetchInitialDataPage(buildWatchUrl(videoId));
    return {
        page: page,
        config: extractWebClientConfigFromHtml(page.html || "")
    };
}

function postNextContinuation(cursor, config) {
    return postContinuation(buildContinuationCursor(cursor, "/youtubei/v1/next"), config);
}

function isLivePlayerResponse(player) {
    var details = player && player.videoDetails ? player.videoDetails : {};
    var micro = player && player.microformat && player.microformat.playerMicroformatRenderer
        ? player.microformat.playerMicroformatRenderer
        : {};
    var liveDetails = micro && micro.liveBroadcastDetails ? micro.liveBroadcastDetails : {};
    var playability = player && player.playabilityStatus ? player.playabilityStatus : {};
    if (details && (details.isLive || details.isLiveContent)) return true;
    if (liveDetails && (liveDetails.isLiveNow === true || trimText(liveDetails.isLiveNow) === "true")) return true;
    if (playability && playability.liveStreamability) return true;
    return false;
}

function isKidsPlayerResponse(player) {
    var playability = player && player.playabilityStatus ? player.playabilityStatus : {};
    var miniplayer = playability && playability.miniplayer && playability.miniplayer.miniplayerRenderer
        ? playability.miniplayer.miniplayerRenderer
        : {};
    var endpoint = miniplayer.minimizedEndpoint || {};
    var popup = endpoint.openPopupAction && endpoint.openPopupAction.popup
        ? endpoint.openPopupAction.popup.notificationActionRenderer || {}
        : {};
    var message = getTextValue(popup.responseText);
    var playbackMode = trimText(miniplayer.playbackMode || "");
    if (playbackMode === "PLAYBACK_MODE_PAUSED_ONLY" && /trẻ em|kids|children/i.test(message)) return true;
    if (/answer=9632097/i.test(JSON.stringify(endpoint || {}))) return true;
    return false;
}

function isKidsState(state) {
    if (!state) return false;
    return isKidsPlayerResponse(state.webPlayer || {}) ||
        isKidsPlayerResponse(state.embedPlayer || {}) ||
        isKidsPlayerResponse(state.player || {});
}

function buildDetailCommentTabs(state) {
    if (isKidsState(state)) return [];
    return [{
        title: isLiveState(state) ? "Trò chuyện trực tiếp" : "Bình luận",
        input: buildWatchUrl(state && state.videoId ? state.videoId : ""),
        script: "comment.js"
    }];
}

function findWatchCommentInitialCursor(initialData) {
    var panels = collectRenderers(initialData || {}, "engagementPanelSectionListRenderer");
    var i;
    for (i = 0; i < panels.length; i++) {
        var targetId = trimText(panels[i].targetId || panels[i].panelIdentifier || "");
        if (targetId !== "engagement-panel-comments-section") continue;
        var entries = collectContinuationEntries(panels[i]);
        var j;
        for (j = 0; j < entries.length; j++) {
            if (entries[j].token) return buildContinuationCursor(entries[j].token, "/youtubei/v1/next", entries[j].clickTrackingParams);
        }
    }
    return null;
}

function findContinuationInNode(root, fallbackApiUrl) {
    var stack = [root];
    var i;
    var key;
    while (stack.length) {
        var node = stack.pop();
        var info;
        if (!node || typeof node !== "object") continue;
        info = extractContinuationFromEndpoint(node, fallbackApiUrl);
        if (info && info.token) return info;
        if (node.continuationEndpoint) {
            info = extractContinuationFromEndpoint(node.continuationEndpoint, fallbackApiUrl);
            if (info && info.token) return info;
        }
        if (node.length && typeof node.length === "number") {
            for (i = node.length - 1; i >= 0; i--) stack.push(node[i]);
            continue;
        }
        for (key in node) {
            if (Object.prototype.hasOwnProperty.call(node, key)) stack.push(node[key]);
        }
    }
    return null;
}

function findWatchLiveChatInitialCursor(initialData) {
    var renderers = collectRenderers(initialData || {}, "liveChatRenderer");
    var i;
    var j;
    var info;
    for (i = 0; i < renderers.length; i++) {
        var continuations = renderers[i] && renderers[i].continuations ? renderers[i].continuations : [];
        for (j = 0; j < continuations.length; j++) {
            info = extractContinuationFromEndpoint(continuations[j], "/youtubei/v1/live_chat/get_live_chat");
            if (info && info.token) return buildContinuationCursor(info.token, info.apiUrl, info.clickTrackingParams);
        }
        info = findContinuationInNode(renderers[i], "/youtubei/v1/live_chat/get_live_chat");
        if (info && info.token) return buildContinuationCursor(info.token, info.apiUrl, info.clickTrackingParams);
    }
    return null;
}

function findSuggestNextCursor(root) {
    var entries = collectContinuationEntries(root || {});
    var i;
    for (i = 0; i < entries.length; i++) {
        var entry = entries[i];
        var path = String(entry.path || "");
        if (!entry.token) continue;
        if (path.indexOf("engagementPanels") >= 0) continue;
        if (path.indexOf("comments-section") >= 0) continue;
        if (/comment/i.test(path)) continue;
        return buildContinuationCursor(entry.token, trimText(entry.apiUrl || "/youtubei/v1/next") || "/youtubei/v1/next", entry.clickTrackingParams);
    }
    return null;
}

function unwrapCommentViewModel(item) {
    if (!item || typeof item !== "object") return null;
    return item.commentViewModel ? item.commentViewModel : item;
}

function unwrapCommentEntityPayload(item) {
    if (!item || typeof item !== "object") return null;
    return item.commentEntityPayload ? item.commentEntityPayload : item;
}

function pickCommentAvatar(entity) {
    if (!entity || typeof entity !== "object") return "";
    if (entity.author && entity.author.avatarThumbnailUrl) return normalizeUrl(entity.author.avatarThumbnailUrl);
    return pickImageSourceUrl(entity.avatar || "");
}

function buildCommentDescription(entity) {
    var properties = entity && entity.properties ? entity.properties : {};
    var toolbar = entity && entity.toolbar ? entity.toolbar : {};
    var likes = trimText(toolbar.likeCountNotliked || toolbar.likeCountLiked || "");
    var replies = trimText(toolbar.replyCount || "");
    return composeParts([
        trimText(properties.publishedTime || ""),
        likes ? (likes + " thích") : "",
        replies ? (replies + " trả lời") : ""
    ]);
}

function buildCommentPageFromJson(json) {
    var models = collectRenderers(json || {}, "commentViewModel");
    var entities = collectRenderers(json || {}, "commentEntityPayload");
    var entityMap = {};
    var comments = [];
    var seen = {};
    var i;

    for (i = 0; i < entities.length; i++) {
        var entity = unwrapCommentEntityPayload(entities[i]);
        var key = trimText(entity && entity.key ? entity.key : "");
        if (!entity || !key || entityMap[key]) continue;
        entityMap[key] = entity;
    }

    for (i = 0; i < models.length; i++) {
        var model = unwrapCommentViewModel(models[i]);
        var entity = entityMap[trimText(model && model.commentKey ? model.commentKey : "")];
        var properties = entity && entity.properties ? entity.properties : {};
        var name;
        var content;
        var commentId;
        if (!entity || !model) continue;
        name = trimText(entity && entity.author ? entity.author.displayName || "" : "") || trimText(properties.authorButtonA11y || "") || "Ẩn danh";
        content = getTextValue(properties.content);
        commentId = trimText(properties.commentId || model.commentId || "");
        if (!content || (commentId && seen[commentId])) continue;
        if (commentId) seen[commentId] = true;
        comments.push({
            name: name,
            avatar: pickCommentAvatar(entity),
            content: textToHtml(content),
            description: buildCommentDescription(entity)
        });
    }

    return comments;
}

function pickLiveChatRenderer(item) {
    var keys = [
        "liveChatTextMessageRenderer",
        "liveChatPaidMessageRenderer",
        "liveChatPaidStickerRenderer",
        "liveChatMembershipItemRenderer",
        "liveChatSponsorshipsGiftPurchaseAnnouncementRenderer",
        "liveChatViewerEngagementMessageRenderer",
        "liveChatPlaceholderItemRenderer"
    ];
    var i;
    item = item || {};
    for (i = 0; i < keys.length; i++) {
        if (item[keys[i]]) return {
            type: keys[i],
            renderer: item[keys[i]]
        };
    }
    return null;
}

function collectLiveChatItemsFromActions(actions, out) {
    var i;
    actions = actions || [];
    out = out || [];
    for (i = 0; i < actions.length; i++) {
        var action = actions[i] || {};
        if (action.addChatItemAction && action.addChatItemAction.item) {
            out.push(action.addChatItemAction.item);
        }
        if (action.replayChatItemAction && action.replayChatItemAction.actions) {
            collectLiveChatItemsFromActions(action.replayChatItemAction.actions, out);
        }
    }
    return out;
}

function buildLiveChatContent(renderer, type) {
    var parts = [];
    var amount = getTextValue(renderer.purchaseAmountText);
    var message = getTextValue(renderer.message) ||
        getTextValue(renderer.headerSubtext) ||
        getTextValue(renderer.headerPrimaryText) ||
        getTextValue(renderer.body);
    if (amount) parts.push(amount);
    if (message) parts.push(message);
    if (!parts.length && type === "liveChatPaidStickerRenderer") parts.push("Sticker");
    return parts.join(" - ");
}

function buildLiveChatCommentFromItem(item) {
    var picked = pickLiveChatRenderer(item);
    var renderer;
    var name;
    var content;
    var timestamp;
    if (!picked) return null;
    renderer = picked.renderer || {};
    name = getTextValue(renderer.authorName) || "YouTube";
    content = buildLiveChatContent(renderer, picked.type);
    timestamp = getTextValue(renderer.timestampText);
    if (!content) return null;
    return {
        name: name,
        avatar: pickThumbnailFromValue(renderer.authorPhoto || renderer.authorPhotoThumbnail || null),
        content: textToHtml(content),
        description: composeParts([timestamp, "Trò chuyện trực tiếp"])
    };
}

function buildLiveChatPageFromJson(json) {
    var continuation = json && json.continuationContents && json.continuationContents.liveChatContinuation
        ? json.continuationContents.liveChatContinuation
        : {};
    var actions = continuation.actions || [];
    var items = collectLiveChatItemsFromActions(actions, []);
    var comments = [];
    var seen = {};
    var i;
    if (!items.length) {
        var keys = [
            "liveChatTextMessageRenderer",
            "liveChatPaidMessageRenderer",
            "liveChatPaidStickerRenderer",
            "liveChatMembershipItemRenderer",
            "liveChatSponsorshipsGiftPurchaseAnnouncementRenderer",
            "liveChatViewerEngagementMessageRenderer"
        ];
        for (i = 0; i < keys.length; i++) {
            var renderers = collectRenderers(json || {}, keys[i]);
            var j;
            for (j = 0; j < renderers.length; j++) {
                var wrapper = {};
                wrapper[keys[i]] = renderers[j];
                items.push(wrapper);
            }
        }
    }
    for (i = 0; i < items.length; i++) {
        var comment = buildLiveChatCommentFromItem(items[i]);
        var key;
        if (!comment) continue;
        key = comment.name + "|" + comment.description + "|" + comment.content;
        if (seen[key]) continue;
        seen[key] = true;
        comments.push(comment);
    }
    return comments;
}

function findCommentNextCursor(root) {
    var entries = collectContinuationEntries(root || {});
    var i;
    var last = null;
    for (i = 0; i < entries.length; i++) {
        var entry = entries[i];
        var path = String(entry.path || "");
        if (!entry.token) continue;
        if (path.indexOf("commentRepliesRenderer") >= 0) continue;
        if (path.indexOf(".replies.") >= 0) continue;
        if (path.indexOf("comments-section") >= 0) continue;
        if (/watch-next-feed/i.test(entry.token || "")) continue;
        last = entry;
    }
    if (!last) return null;
    return buildContinuationCursor(last.token, trimText(last.apiUrl || "/youtubei/v1/next") || "/youtubei/v1/next", last.clickTrackingParams);
}

function fetchSuggestPage(videoId, cursor) {
    var context = fetchWatchPageContext(videoId);
    var items;
    var next = null;
    var currentId = trimText(videoId || "");
    var filtered = [];
    var seen = {};
    var i;

    if (isFirstPageCursor(cursor)) {
        items = buildVideoCardsFromInitialData(context.page.initialData || {});
        next = findSuggestNextCursor(context.page.initialData || {});
        if ((!items || !items.length) && next) {
            var firstJson = postContinuation(next, context.config);
            items = buildVideoCardsFromInitialData(firstJson || {});
            next = findSuggestNextCursor(firstJson || {});
        }
    } else {
        var json = postContinuation(cursor, context.config);
        items = buildVideoCardsFromInitialData(json || {});
        next = findSuggestNextCursor(json || {});
    }

    for (i = 0; i < (items || []).length; i++) {
        var link = normalizeUrl(items[i].link || "");
        var itemVideoId = extractVideoId(link);
        var dedupeKey = itemVideoId || link;
        if (!dedupeKey) continue;
        if (itemVideoId && currentId && itemVideoId === currentId) continue;
        if (seen[dedupeKey]) continue;
        seen[dedupeKey] = true;
        filtered.push(items[i]);
    }

    return {
        items: filtered,
        next: next
    };
}

function fetchCommentPage(videoId, cursor) {
    var context = fetchWatchPageContext(videoId);
    var json = null;
    var initialPlayer = context.page.initialPlayer || {};
    if (isKidsPlayerResponse(initialPlayer)) return { comments: [], next: null };
    if (isLivePlayerResponse(initialPlayer)) return fetchLiveChatPageFromContext(context, cursor);
    if (isFirstPageCursor(cursor)) {
        var firstCursor = findWatchCommentInitialCursor(context.page.initialData || {});
        if (!firstCursor) return { comments: [], next: null };
        json = postContinuation(firstCursor, context.config);
    } else {
        json = postContinuation(cursor, context.config);
    }
    return {
        comments: buildCommentPageFromJson(json || {}),
        next: findCommentNextCursor(json || {})
    };
}

function fetchLiveChatPageFromContext(context, cursor) {
    var chatCursor = isFirstPageCursor(cursor)
        ? findWatchLiveChatInitialCursor(context.page.initialData || {})
        : cursor;
    var json;
    if (!chatCursor) return { comments: [], next: null };
    json = postLiveChatContinuation(chatCursor, context.config);
    return {
        comments: buildLiveChatPageFromJson(json || {}),
        next: null
    };
}

function buildVideoCardsFromPage(url) {
    var page = fetchInitialDataPage(url);
    return buildVideoCardsFromInitialData(page.initialData || {});
}

function fetchPagedCardsFromPage(url, pageCursor, fallbackApiUrl, options) {
    var page = fetchInitialDataPage(url);
    if (isFirstPageCursor(pageCursor)) {
        return buildPagedVideoCardsFromInitialData(page.initialData || {}, fallbackApiUrl, options);
    }
    var config = extractWebClientConfigFromHtml(page.html || "");
    var json = postContinuation(pageCursor, config);
    return buildPagedVideoCardsFromInitialData(json || {}, fallbackApiUrl, options);
}

function limitListItems(items, maxItems) {
    items = items || [];
    maxItems = Number(maxItems || 0);
    if (!maxItems || items.length <= maxItems) return items;
    return items.slice(0, maxItems);
}

function readHomePageCache() {
    var raw;
    var json;
    try {
        raw = getRuntimeCacheValue(HOME_PAGE_CACHE_KEY);
        json = safeJsonParse(raw);
        if (!json || !json.savedAt) return null;
        if ((Date.now() - Number(json.savedAt || 0)) > HOME_PAGE_CACHE_TTL_MS) {
            removeHomePageCache();
            return null;
        }
        if (!json.items || !json.items.length) return null;
        return json;
    } catch (e) {
        return null;
    }
}

function writeHomePageCache(cache) {
    var stored;
    var pageCursors = {};
    var key;
    if (!cache || !cache.items || !cache.items.length) return;
    for (key in (cache.pageCursors || {})) {
        if (!Object.prototype.hasOwnProperty.call(cache.pageCursors || {}, key)) continue;
        if (trimText(cache.pageCursors[key])) pageCursors[key] = trimText(cache.pageCursors[key]);
    }
    stored = {
        savedAt: Number(cache.savedAt || Date.now()),
        items: limitListItems(cache.items || [], HOME_PAGE_CACHE_MAX_ITEMS),
        next: trimText(cache.next || ""),
        nextPage: trimText(cache.nextPage || ""),
        pageCursors: pageCursors,
        firstPageServed: !!cache.firstPageServed,
        config: cache.config || {}
    };
    try {
        if (!setRuntimeCacheValue(HOME_PAGE_CACHE_KEY, JSON.stringify(stored))) removeHomePageCache();
    } catch (e) {
        removeHomePageCache();
    }
}

function removeHomePageCache() {
    removeRuntimeCacheValue(HOME_PAGE_CACHE_KEY);
}

function fetchHomePageDirect(options) {
    options = options || {};
    var page = fetchInitialDataPage(YT_BASE + "/");
    var firstPage = buildPagedVideoCardsFromInitialData(page.initialData || {}, "/youtubei/v1/browse", {});
    return {
        items: limitListItems(firstPage.items || [], HOME_PAGE_CACHE_MAX_ITEMS),
        next: null,
        config: extractWebClientConfigFromHtml(page.html || ""),
        chips: buildHomeChipItemsFromInitialData(page.initialData || {})
    };
}

function buildUtilityHomeItems(seen) {
    var items = [];
    if (!seen["Video đã xem"]) {
        seen["Video đã xem"] = true;
        items.push({
            title: "Video đã xem",
            input: buildFeedInput("history", ""),
            script: "gen.js"
        });
    }
    if (!seen["Đăng ký"]) {
        seen["Đăng ký"] = true;
        items.push({
            title: "Đăng ký",
            input: buildFeedInput("subscriptions", ""),
            script: "gen.js"
        });
    }
    return items;
}

function isAllHomeChipTitle(text) {
    text = trimText(text).toLowerCase();
    return text === "tất cả" || text === "tat ca" || text === "all";
}

function buildFallbackHomeChipItems() {
    return [
        { title: "Tất cả", input: buildFeedInput("home", ""), script: "gen.js" },
        { title: "Video đã xem", input: buildFeedInput("history", ""), script: "gen.js" },
        { title: "Đăng ký", input: buildFeedInput("subscriptions", ""), script: "gen.js" },
        { title: "Âm nhạc", input: buildFeedInput("search", "âm nhạc"), script: "gen.js" },
        { title: "Trò chơi", input: buildFeedInput("search", "trò chơi"), script: "gen.js" },
        { title: "Trực tiếp", input: buildFeedInput("search", "trực tiếp"), script: "gen.js" },
        { title: "Tin tức", input: buildFeedInput("search", "tin tức"), script: "gen.js" }
    ];
}

function buildHomeChipItemsFromInitialData(initialData) {
    var chips = collectRenderers(initialData || {}, "chipCloudChipRenderer");
    var items = [];
    var seen = {};
    var i;
    for (i = 0; i < chips.length; i++) {
        var chip = chips[i] || {};
        var text = getTextValue(chip.text);
        var token = chip.navigationEndpoint && chip.navigationEndpoint.continuationCommand
            ? trimText(chip.navigationEndpoint.continuationCommand.token || "")
            : "";
        if (!text || seen[text]) continue;
        if (chip.navigationEndpoint && chip.navigationEndpoint.showMoreDrawerCommand) continue;
        seen[text] = true;
        items.push({
            title: text,
            input: isAllHomeChipTitle(text) || !token ? buildFeedInput("home", "") : buildFeedInput("home-chip", token),
            script: "gen.js"
        });
        if (items.length === 1) {
            var utilityItems = buildUtilityHomeItems(seen);
            for (var j = 0; j < utilityItems.length; j++) items.push(utilityItems[j]);
        }
    }
    return items.length ? items : buildFallbackHomeChipItems();
}

function buildHomePageCacheFromPage(page) {
    var firstPage = buildPagedVideoCardsFromInitialData(page.initialData || {}, "/youtubei/v1/browse", {});
    var pageCursors = {};
    return {
        savedAt: Date.now(),
        items: limitListItems(firstPage.items || [], HOME_PAGE_CACHE_MAX_ITEMS),
        next: null,
        nextPage: null,
        pageCursors: pageCursors,
        firstPageServed: false,
        config: extractWebClientConfigFromHtml(page.html || ""),
        chips: buildHomeChipItemsFromInitialData(page.initialData || {})
    };
}

function refreshHomePageCache() {
    var page = fetchInitialDataPage(YT_BASE + "/");
    var cache = buildHomePageCacheFromPage(page);
    writeHomePageCache(cache);
    return cache;
}

function buildHomeChipItems() {
    removeHomePageCache();
    var cached = refreshHomePageCache();
    return cached && cached.chips && cached.chips.length ? cached.chips : buildFallbackHomeChipItems();
}

function buildChannelItemsFromPage(url) {
    var page = fetchInitialDataPage(url);
    return buildChannelItemsFromInitialData(page.initialData || {});
}

function fetchHomeCards(pageCursor, options) {
    options = options || {};
    var pagingOptions = options.disableNext ? { disableNext: true } : {};
    var cached = readHomePageCache();
    var config;
    var cursor;
    var json;
    var result;
    var currentPageNumber;
    var nextPageNumber;
    if (isFirstPageCursor(pageCursor)) {
        if (cached && cached.items && cached.items.length) {
            removeHomePageCache();
            return {
                items: cached.items,
                next: options.disableNext ? null : (cached.nextPage || cached.next || null)
            };
        }
        var direct = fetchHomePageDirect();
        return {
            items: direct.items || [],
            next: options.disableNext ? null : (direct.next || null)
        };
    }
    currentPageNumber = /^\d+$/.test(trimText(pageCursor)) ? Number(trimText(pageCursor)) : 0;
    cursor = currentPageNumber > 1
        ? (cached && cached.pageCursors ? trimText(cached.pageCursors[String(currentPageNumber)] || "") : "")
        : trimText(pageCursor);
    if (!cursor && currentPageNumber === 2) {
        var directForCursor = fetchHomePageDirect();
        cursor = trimText(directForCursor.next || "");
        config = directForCursor.config || null;
    }
    if (!cursor) return { items: [], next: null };
    config = config || (cached && cached.config && cached.config.apiKey ? cached.config : null);
    if (!config) {
        config = fetchHomePageDirect().config;
    }
    json = postContinuation(cursor, config);
    result = buildPagedVideoCardsFromInitialData(json || {}, "/youtubei/v1/browse", pagingOptions);
    if (result.items.length || !isSoftReloadHomeResponse(json)) {
        if (currentPageNumber > 1 && cached) {
            if (!cached.pageCursors) cached.pageCursors = {};
            nextPageNumber = currentPageNumber + 1;
            cached.pageCursors[String(nextPageNumber)] = result.next || "";
            writeHomePageCache(cached);
            result.next = result.next ? String(nextPageNumber) : null;
        }
        return result;
    }
    var retryJson = postContinuation(cursor, config);
    var retryResult = buildPagedVideoCardsFromInitialData(retryJson || {}, "/youtubei/v1/browse", pagingOptions);
    if (currentPageNumber > 1 && cached) {
        if (!cached.pageCursors) cached.pageCursors = {};
        nextPageNumber = currentPageNumber + 1;
        cached.pageCursors[String(nextPageNumber)] = retryResult.next || "";
        writeHomePageCache(cached);
        retryResult.next = retryResult.next ? String(nextPageNumber) : null;
    }
    return retryResult.items.length ? retryResult : result;
}

function fetchHomeChipCards(token, pageCursor) {
    if (!isFirstPageCursor(pageCursor)) {
        var chipCached = readHomePageCache();
        var chipConfig = chipCached && chipCached.config && chipCached.config.apiKey ? chipCached.config : fetchHomePageDirect().config;
        var chipJson = postContinuation(pageCursor, chipConfig);
        return buildPagedVideoCardsFromInitialData(chipJson || {}, "/youtubei/v1/browse", {});
    }
    if (!token) return fetchHomeCards("1", {});
    var cached = readHomePageCache();
    var config = cached && cached.config && cached.config.apiKey ? cached.config : null;
    if (!config) {
        cached = refreshHomePageCache();
        config = cached && cached.config ? cached.config : null;
    }
    var json = postBrowseContinuation(token, config);
    return buildPagedVideoCardsFromInitialData(json || {}, "/youtubei/v1/browse", {});
}

function fetchSubscriptionCards(pageCursor) {
    return fetchPagedCardsFromPage(YT_BASE + "/feed/subscriptions", pageCursor, "/youtubei/v1/browse", {
        disableNext: true
    });
}

function buildHistoryGenreItem() {
    return {
        title: "Video đã xem",
        input: buildFeedInput("history", ""),
        script: "gen.js"
    };
}

function fetchHistoryCards(pageCursor) {
    return fetchPagedCardsFromPage(YT_BASE + "/feed/history", pageCursor, "/youtubei/v1/browse", {});
}

function fetchSearchCards(query, pageCursor) {
    query = trimText(query);
    if (!query) return { items: [], next: null };
    return fetchPagedCardsFromPage(
        YT_BASE + "/results?search_query=" + encodeURIComponent(query),
        pageCursor,
        "/youtubei/v1/search",
        {}
    );
}

function fetchChannelVideoCards(url, pageCursor) {
    return fetchPagedCardsFromPage(normalizeChannelVideosUrl(url), pageCursor, "/youtubei/v1/browse", {
        selectedTabOnly: true
    });
}

function fetchSubscribedChannels() {
    return buildChannelItemsFromPage(YT_BASE + "/feed/channels");
}

function fetchText(url, options) {
    var response = fetch(url, options || {});
    var text = "";
    try {
        text = String(response.text() || "");
    } catch (e) { }
    return {
        status: response && typeof response.status !== "undefined" ? response.status : 0,
        ok: !!(response && response.ok),
        text: text
    };
}

function safeJsonParse(text) {
    try {
        return JSON.parse(String(text || ""));
    } catch (e) {
        return null;
    }
}

function fetchOEmbed(videoId) {
    var url = YT_OEMBED_BASE + "?url=" + encodeURIComponent(buildLocalizedYouTubeUrl(buildWatchUrl(videoId))) + "&format=json";
    var result = fetchText(url, {
        headers: buildPreferredWebHeaders()
    });
    return safeJsonParse(result.text) || {};
}

function fetchWatchContext(videoId) {
    var result = fetchText(buildLocalizedYouTubeUrl(buildWatchUrl(videoId)), {
        headers: buildPreferredWebHeaders()
    });
    return {
        status: result.status,
        ok: result.ok,
        html: result.text,
        apiKey: matchValue(result.text, /"INNERTUBE_API_KEY":"([^"]+)"/),
        visitorData: matchValue(result.text, /"VISITOR_DATA":"([^"]+)"/),
        player: extractInitialPlayerResponseFromHtml(result.text) || {}
    };
}

function fetchEmbedContext(videoId) {
    var result = fetchText(buildLocalizedYouTubeUrl(buildEmbedUrl(videoId)), {
        headers: buildPreferredWebHeaders()
    });
    return {
        status: result.status,
        ok: result.ok,
        html: result.text,
        apiKey: matchValue(result.text, /"INNERTUBE_API_KEY":"([^"]+)"/),
        visitorData: matchValue(result.text, /"VISITOR_DATA":"([^"]+)"/),
        player: extractInitialPlayerResponseFromHtml(result.text) || {}
    };
}

function buildPlayerClientContext(client) {
    var src = client && client.context ? client.context : {};
    var out = {};
    var key;
    for (key in src) {
        if (Object.prototype.hasOwnProperty.call(src, key)) out[key] = src[key];
    }
    if (!out.hl) out.hl = YT_PREFERRED_HL;
    if (!out.gl) out.gl = YT_PREFERRED_GL;
    if (!out.acceptLanguage) out.acceptLanguage = YT_PREFERRED_HL;
    if (typeof out.utcOffsetMinutes === "undefined") out.utcOffsetMinutes = 420;
    return out;
}

function postPlayer(videoId, contextInfo, client) {
    client = client || ANDROID_VR_CLIENT;
    var body = JSON.stringify({
        videoId: videoId,
        contentCheckOk: true,
        racyCheckOk: true,
        context: {
            client: buildPlayerClientContext(client)
        }
    });
    var response = fetch(
        YT_BASE + "/youtubei/v1/player?prettyPrint=false&key=" + contextInfo.apiKey,
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-YouTube-Client-Name": client.clientNum,
                "X-YouTube-Client-Version": client.clientVersion,
                "Origin": YT_BASE,
                "X-Goog-Visitor-Id": contextInfo.visitorData,
                "Accept-Language": YT_PREFERRED_HL + ",en;q=0.9,en-US;q=0.8",
                "User-Agent": client.userAgent
            },
            body: body
        }
    );
    var text = "";
    try {
        text = String(response.text() || "");
    } catch (e) { }
    return {
        status: response && typeof response.status !== "undefined" ? response.status : 0,
        ok: !!(response && response.ok),
        json: safeJsonParse(text) || {},
        text: text,
        clientName: trimText(client.name || client.clientName || "")
    };
}

function isPlayablePlayerResponse(response) {
    var json = response && response.json ? response.json : {};
    var playability = json && json.playabilityStatus ? trimText(json.playabilityStatus.status || "") : "";
    if (playability && playability !== "OK") return false;
    return !!(json && json.streamingData);
}

function chooseBestPlayerResponse(responses) {
    var i;
    var bestAudioResponse = null;
    var bestAudioCount = 1;
    var count;
    if (!responses || !responses.length) return null;
    for (i = 0; i < responses.length; i++) {
        if (!isPlayablePlayerResponse(responses[i])) continue;
        count = countDistinctMp4AudioLanguages(responses[i].json || {});
        if (count > bestAudioCount) {
            bestAudioCount = count;
            bestAudioResponse = responses[i];
        }
    }
    if (bestAudioResponse) return bestAudioResponse;
    for (i = 0; i < responses.length; i++) {
        if (isPlayablePlayerResponse(responses[i])) return responses[i];
    }
    for (i = 0; i < responses.length; i++) {
        if (responses[i] && responses[i].json && responses[i].json.playabilityStatus) return responses[i];
    }
    return responses[0];
}

function postPlayerWithFallbacks(videoId, contextInfo) {
    var responses = [];
    var i;
    for (i = 0; i < PLAYER_CLIENTS.length; i++) {
        responses.push(postPlayer(videoId, contextInfo, PLAYER_CLIENTS[i]));
        if (isPlayablePlayerResponse(responses[responses.length - 1]) && PLAYER_CLIENTS[i].name !== "ANDROID_VR") break;
    }
    return {
        chosen: chooseBestPlayerResponse(responses),
        attempts: responses
    };
}

function getCacheKey(videoId) {
    return CACHE_PREFIX + trimText(videoId);
}

function readCacheIndex() {
    var list;
    var out = [];
    var seen = {};
    var i;
    if (!ENABLE_STATE_CACHE) return [];
    if (typeof localStorage === "undefined" || !localStorage) return [];
    try {
        list = safeJsonParse(localStorage.getItem(CACHE_INDEX_KEY));
        if (!list || !list.length) return [];
        for (i = 0; i < list.length; i++) {
            var key = trimText(list[i]);
            if (!key || !startsWithText(key, CACHE_PREFIX) || seen[key]) continue;
            seen[key] = true;
            out.push(key);
        }
    } catch (e) { }
    return out;
}

function writeCacheIndex(list) {
    if (!ENABLE_STATE_CACHE) return;
    if (typeof localStorage === "undefined" || !localStorage) return;
    try {
        localStorage.setItem(CACHE_INDEX_KEY, JSON.stringify(list || []));
    } catch (e) { }
}

function removeCacheEntryByKey(key) {
    if (typeof localStorage === "undefined" || !localStorage) return;
    key = trimText(key);
    if (!key) return;
    try {
        localStorage.removeItem(key);
    } catch (e) { }
}

function pruneCacheEntries() {
    var now = Date.now();
    var index = readCacheIndex();
    var kept = [];
    var i;
    if (!ENABLE_STATE_CACHE) return [];
    if (typeof localStorage === "undefined" || !localStorage) return [];
    for (i = 0; i < index.length; i++) {
        var key = trimText(index[i]);
        var raw = "";
        var json = null;
        if (!key) continue;
        try {
            raw = localStorage.getItem(key);
            json = safeJsonParse(raw);
        } catch (e) {
            json = null;
        }
        if (!json || !json.savedAt || (now - Number(json.savedAt || 0)) > CACHE_TTL_MS) {
            removeCacheEntryByKey(key);
            continue;
        }
        if (kept.length >= CACHE_MAX_ITEMS) {
            removeCacheEntryByKey(key);
            continue;
        }
        kept.push(key);
    }
    writeCacheIndex(kept);
    return kept;
}

function touchCacheEntry(videoId) {
    if (!ENABLE_STATE_CACHE) return;
    var key = getCacheKey(videoId);
    var index = readCacheIndex();
    var next = [key];
    var i;
    for (i = 0; i < index.length; i++) {
        if (index[i] !== key) next.push(index[i]);
    }
    writeCacheIndex(next);
    pruneCacheEntries();
}

function getCachedVideoState(videoId) {
    if (!ENABLE_STATE_CACHE) return null;
    if (typeof localStorage === "undefined" || !localStorage) return null;
    try {
        var key = getCacheKey(videoId);
        var raw = localStorage.getItem(key);
        var json = safeJsonParse(raw);
        if (!json || !json.savedAt) return null;
        if ((Date.now() - Number(json.savedAt || 0)) > CACHE_TTL_MS) {
            removeCacheEntryByKey(key);
            pruneCacheEntries();
            return null;
        }
        touchCacheEntry(videoId);
        return json.data || null;
    } catch (e) {
        return null;
    }
}

function setCachedVideoState(videoId, data) {
    if (!ENABLE_STATE_CACHE) return;
    if (typeof localStorage === "undefined" || !localStorage) return;
    try {
        localStorage.setItem(getCacheKey(videoId), JSON.stringify({
            savedAt: Date.now(),
            data: data
        }));
        touchCacheEntry(videoId);
    } catch (e) { }
}

function summarizePlayerAttempts(attempts) {
    var out = [];
    var i;
    for (i = 0; i < (attempts || []).length; i++) {
        var item = attempts[i] || {};
        var playability = item.json && item.json.playabilityStatus ? trimText(item.json.playabilityStatus.status || "") : "";
        var reason = item.json && item.json.playabilityStatus ? trimText(item.json.playabilityStatus.reason || "") : "";
        out.push({
            clientName: trimText(item.clientName || ""),
            status: Number(item.status || 0),
            ok: !!item.ok,
            playability: playability,
            reason: reason
        });
    }
    return out;
}

function getVideoState(videoId, forceRefresh) {
    var cached = !forceRefresh ? getCachedVideoState(videoId) : null;
    if (cached) return cached;

    var oembed = fetchOEmbed(videoId);
    var watch = fetchWatchContext(videoId);
    var contextInfo = watch;
    if (!contextInfo.apiKey || !contextInfo.visitorData) {
        contextInfo = fetchEmbedContext(videoId);
    }
    var playerBundle = contextInfo.apiKey && contextInfo.visitorData ? postPlayerWithFallbacks(videoId, contextInfo) : {
        chosen: {
            status: 0,
            ok: false,
            json: {},
            text: "",
            clientName: ""
        },
        attempts: []
    };
    var playerRsp = playerBundle.chosen || {
        status: 0,
        ok: false,
        json: {},
        text: "",
        clientName: ""
    };
    var player = playerRsp.json || {};
    var videoDetails = player.videoDetails || {};
    var microformat = player.microformat && player.microformat.playerMicroformatRenderer
        ? player.microformat.playerMicroformatRenderer
        : {};

    var data = {
        videoId: videoId,
        oembed: oembed,
        watch: {
            status: watch.status,
            ok: watch.ok,
            apiKey: watch.apiKey,
            visitorData: watch.visitorData
        },
        embed: {
            status: contextInfo === watch ? 0 : contextInfo.status,
            ok: contextInfo === watch ? false : contextInfo.ok,
            apiKey: contextInfo === watch ? "" : contextInfo.apiKey,
            visitorData: contextInfo === watch ? "" : contextInfo.visitorData
        },
        playerStatus: playerRsp.status,
        playerOk: playerRsp.ok,
        playerClient: trimText(playerRsp.clientName || ""),
        playerAttempts: summarizePlayerAttempts(playerBundle.attempts),
        player: player,
        webPlayer: watch.player || {},
        embedPlayer: contextInfo === watch ? {} : (contextInfo.player || {}),
        videoDetails: videoDetails,
        microformat: microformat
    };
    setCachedVideoState(videoId, data);
    return data;
}

function pickThumbnail(state) {
    var thumbs = [];
    if (state && state.videoDetails && state.videoDetails.thumbnail && state.videoDetails.thumbnail.thumbnails) {
        thumbs = state.videoDetails.thumbnail.thumbnails;
    } else if (state && state.microformat && state.microformat.thumbnail && state.microformat.thumbnail.thumbnails) {
        thumbs = state.microformat.thumbnail.thumbnails;
    }
    if (thumbs && thumbs.length) return thumbs[thumbs.length - 1].url || "";
    if (state && state.oembed && state.oembed.thumbnail_url) return state.oembed.thumbnail_url;
    return buildThumbnailUrl(state && state.videoId ? state.videoId : "");
}

function pickTitle(state) {
    if (state && state.webPlayer && state.webPlayer.videoDetails && state.webPlayer.videoDetails.title) return state.webPlayer.videoDetails.title;
    if (state && state.videoDetails && state.videoDetails.title) return state.videoDetails.title;
    if (state && state.microformat && state.microformat.title && state.microformat.title.simpleText) return state.microformat.title.simpleText;
    if (state && state.oembed && state.oembed.title) return state.oembed.title;
    return "YouTube";
}

function pickAuthor(state) {
    if (state && state.videoDetails && state.videoDetails.author) return state.videoDetails.author;
    if (state && state.oembed && state.oembed.author_name) return state.oembed.author_name;
    return "YouTube";
}

function pickDescription(state) {
    var text = "";
    if (state && state.webPlayer && state.webPlayer.videoDetails && state.webPlayer.videoDetails.shortDescription) {
        text = state.webPlayer.videoDetails.shortDescription;
    } else if (state && state.videoDetails && state.videoDetails.shortDescription) {
        text = state.videoDetails.shortDescription;
    } else if (state && state.microformat && state.microformat.description && state.microformat.description.simpleText) {
        text = state.microformat.description.simpleText;
    }
    text = String(text || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    return text.replace(/\r\n|\r|\n/g, "<br>");
}

function formatDuration(seconds) {
    seconds = Number(seconds || 0);
    if (!seconds || seconds < 0) return "";
    var h = Math.floor(seconds / 3600);
    var m = Math.floor((seconds % 3600) / 60);
    var s = Math.floor(seconds % 60);
    var parts = [];
    if (h) parts.push(h + "h");
    if (m || h) parts.push(m + "m");
    parts.push(s + "s");
    return parts.join(" ");
}

function buildDetailLines(state) {
    var lines = [];
    var seconds = state && state.videoDetails ? state.videoDetails.lengthSeconds : "";
    var viewCount = state && state.videoDetails ? state.videoDetails.viewCount : "";
    var playability = state && state.player && state.player.playabilityStatus ? state.player.playabilityStatus.status || "" : "";
    var reason = state && state.player && state.player.playabilityStatus ? state.player.playabilityStatus.reason || "" : "";
    var playerClient = state && state.playerClient ? trimText(state.playerClient) : "";
    if (isLiveState(state)) lines.push("Loại: Đang trực tiếp");
    if (seconds) lines.push("Thời lượng: " + formatDuration(seconds));
    if (viewCount) lines.push("Lượt xem: " + viewCount);
    if (playerClient) lines.push("Client: " + playerClient);
    if (playability) lines.push("Trạng thái phát: " + playability);
    if (reason) lines.push("Lý do: " + reason);
    return lines.join("<br>");
}

function buildSearchCard(videoId) {
    var state = getVideoState(videoId);
    return {
        name: pickTitle(state),
        link: buildBookLink(videoId),
        cover: pickThumbnail(state),
        description: pickAuthor(state),
        tag: buildDurationTag(state && state.videoDetails ? state.videoDetails.lengthSeconds : "")
    };
}

function getContainerName(mimeType) {
    mimeType = trimText(mimeType);
    if (!mimeType) return "";
    var base = mimeType.split(";")[0];
    var parts = base.split("/");
    return parts.length > 1 ? parts[1] : base;
}

function getCodecName(mimeType) {
    var match = String(mimeType || "").match(/codecs="([^"]+)"/i);
    return match && match[1] ? match[1] : "";
}

function containsCodec(mimeType, name) {
    return String(getCodecName(mimeType || "") || "").toLowerCase().indexOf(String(name || "").toLowerCase()) >= 0;
}

function appendQueryParam(url, key, value) {
    url = trimText(url || "");
    if (!url) return "";
    if (new RegExp("([?&])" + key + "=", "i").test(url)) {
        return url.replace(new RegExp("([?&])" + key + "=[^&]*", "i"), "$1" + encodeURIComponent(key) + "=" + encodeURIComponent(value));
    }
    return url + (url.indexOf("?") >= 0 ? "&" : "?") + encodeURIComponent(key) + "=" + encodeURIComponent(value);
}

function appendQueryParams(url, params) {
    params = params || {};
    for (var key in params) {
        if (!Object.prototype.hasOwnProperty.call(params, key)) continue;
        if (params[key] == null || params[key] === "") continue;
        url = appendQueryParam(url, key, params[key]);
    }
    return url;
}

function isVietnameseLang(lang) {
    lang = trimText(lang || "").toLowerCase().replace("_", "-");
    return lang === "vi" || lang.indexOf("vi-") === 0 || lang.indexOf("vietnam") >= 0 || lang.indexOf("tiếng việt") >= 0;
}

function isChineseLang(lang) {
    lang = trimText(lang || "").toLowerCase().replace("_", "-");
    return lang === "zh" || lang.indexOf("zh-") === 0 || lang === "cmn" || lang.indexOf("cmn-") === 0 ||
        lang.indexOf("chinese") >= 0 || lang.indexOf("trung") >= 0 || lang.indexOf("中文") >= 0 || lang.indexOf("汉语") >= 0;
}

function isEnglishLang(lang) {
    lang = trimText(lang || "").toLowerCase().replace("_", "-");
    return lang === "en" || lang.indexOf("en-") === 0 || lang.indexOf("english") >= 0 || lang.indexOf("tiếng anh") >= 0;
}

function normalizeAudioLanguage(value) {
    value = trimText(value || "").toLowerCase().replace("_", "-");
    value = value.replace(/\.\d+$/, "");
    return value;
}

function getAudioTrackInfo(format) {
    var track = format && format.audioTrack ? format.audioTrack : {};
    var display = getTextValue(track.displayName) || trimText(track.displayName || track.name || format && format.displayName || "");
    var lang = normalizeAudioLanguage(track.id || track.languageCode || track.language || format && (format.language || format.lang) || "");
    if (!lang && isVietnameseLang(display)) lang = "vi";
    if (!lang && isChineseLang(display)) lang = "zh";
    return {
        language: lang,
        displayName: display,
        isDefault: track.audioIsDefault === true || trimText(track.audioIsDefault || "") === "true",
        isOriginal: /original|gốc|原始|原聲|原声/i.test(display)
    };
}

function isOriginalAudioFormat(format) {
    var info = getAudioTrackInfo(format);
    return !!(info.isDefault || info.isOriginal);
}

function getAudioPriority(format) {
    var info = getAudioTrackInfo(format);
    if (isVietnameseLang(info.language) || isVietnameseLang(info.displayName)) return 0;
    if (isChineseLang(info.language) || isChineseLang(info.displayName)) return 1;
    if (!(info.isDefault || info.isOriginal) && (isEnglishLang(info.language) || isEnglishLang(info.displayName))) return 2;
    if (info.isDefault || info.isOriginal) return 3;
    if (isEnglishLang(info.language) || isEnglishLang(info.displayName)) return 2;
    return 4;
}

function getAudioBucketKey(format) {
    var info = getAudioTrackInfo(format);
    if (isVietnameseLang(info.language) || isVietnameseLang(info.displayName)) return "vi";
    if (isChineseLang(info.language) || isChineseLang(info.displayName)) return "zh";
    if (!(info.isDefault || info.isOriginal) && (isEnglishLang(info.language) || isEnglishLang(info.displayName))) return "en";
    if (info.isDefault || info.isOriginal) return "original";
    if (isEnglishLang(info.language) || isEnglishLang(info.displayName)) return "en";
    return "other:" + (info.language || info.displayName || "unknown");
}

function getAudioTrackIdentity(format) {
    var track = format && format.audioTrack ? format.audioTrack : {};
    var info = getAudioTrackInfo(format);
    return [
        String(format && format.itag ? format.itag : ""),
        trimText(track.id || ""),
        trimText(info.language || ""),
        trimText(info.displayName || "")
    ].join("|");
}

function getAudioChoiceIdentity(choice) {
    choice = choice || {};
    return [
        String(choice.itag || ""),
        trimText(choice.audioTrackId || ""),
        trimText(choice.language || ""),
        trimText(choice.displayName || choice.label || "")
    ].join("|");
}

function audioFormatMatchesChoice(format, choice) {
    var track = format && format.audioTrack ? format.audioTrack : {};
    var info = getAudioTrackInfo(format);
    if (!format || !choice) return false;
    if (Number(format.itag || 0) !== Number(choice.itag || 0)) return false;
    if (choice.audioTrackId && trimText(track.id || "") === trimText(choice.audioTrackId || "")) return true;
    if (choice.language && trimText(info.language || "") === trimText(choice.language || "")) return true;
    if (choice.displayName && trimText(info.displayName || "") === trimText(choice.displayName || "")) return true;
    return !choice.audioTrackId && !choice.language && !choice.displayName;
}

function getAudioQualityRank(format) {
    var quality = trimText(format && format.audioQuality ? format.audioQuality : "").toUpperCase();
    if (quality.indexOf("MEDIUM") >= 0) return 0;
    if (quality.indexOf("LOW") >= 0) return 1;
    if (quality.indexOf("HIGH") >= 0) return 2;
    return 3;
}

function buildAudioDisplayLabel(format) {
    var info = getAudioTrackInfo(format);
    var name = trimText(info.displayName || info.language || "");
    var quality = getAudioFormatLabel(format);
    if (!name) name = info.isDefault || info.isOriginal ? "Gốc" : "Audio";
    return trimText(name + (quality ? (" · " + quality) : ""));
}

function buildYouTubeSubtitleTracks(player) {
    var out = [];
    var seen = {};
    var renderer = player && player.captions && player.captions.playerCaptionsTracklistRenderer
        ? player.captions.playerCaptionsTracklistRenderer
        : {};
    var tracks = renderer.captionTracks || [];
    for (var i = 0; i < tracks.length; i++) {
        var item = tracks[i] || {};
        var url = trimText(item.baseUrl || "");
        var lang = trimText(item.languageCode || item.vssId || "");
        var name = getTextValue(item.name) || lang || "Subtitle";
        if (!url) continue;
        url = appendQueryParam(url, "fmt", "vtt");
        if (seen[url]) continue;
        seen[url] = true;
        out.push({
            title: name,
            label: name,
            language: lang,
            lang: lang,
            data: url,
            url: url,
            type: "vtt",
            selected: isVietnameseLang(lang) || isVietnameseLang(name),
            source: "youtube.captionTracks"
        });
    }
    out.sort(function (a, b) {
        function priority(item) {
            var lang = trimText(item && item.language ? item.language : "");
            var title = trimText(item && item.title ? item.title : "");
            if (isVietnameseLang(lang) || isVietnameseLang(title)) return 0;
            if (isChineseLang(lang) || isChineseLang(title)) return 1;
            if (/^en(?:-|$)/i.test(lang) || /english|original|gốc/i.test(title)) return 2;
            return 3;
        }
        var ap = priority(a);
        var bp = priority(b);
        if (ap !== bp) return ap - bp;
        if (a.selected && !b.selected) return -1;
        if (!a.selected && b.selected) return 1;
        return 0;
    });
    return out.slice(0, 12);
}

function getTypeGroup(mimeType) {
    mimeType = trimText(mimeType);
    if (startsWithText(mimeType, "audio/")) return "audio";
    if (startsWithText(mimeType, "video/")) return "video";
    return "";
}

function getQualityNumber(format) {
    var label = format && format.qualityLabel ? String(format.qualityLabel) : "";
    var match = label.match(/(\d{3,4})p/i);
    return match && match[1] ? Number(match[1]) : 0;
}

function getFpsNumber(format) {
    return Number(format && format.fps ? format.fps : 0);
}

function getBitrateNumber(format) {
    return Number(format && format.bitrate ? format.bitrate : 0);
}

function normalizeAudioQualityLabel(value) {
    value = trimText(value).replace(/^AUDIO_QUALITY_/i, "").toUpperCase();
    if (value === "HIGH") return "cao";
    if (value === "MEDIUM") return "trung bình";
    if (value === "LOW") return "thấp";
    return trimText(value).toLowerCase();
}

function compareVideoFormats(a, b) {
    var q = getQualityNumber(b) - getQualityNumber(a);
    if (q) return q;
    var fps = getFpsNumber(b) - getFpsNumber(a);
    if (fps) return fps;
    return getBitrateNumber(b) - getBitrateNumber(a);
}

function compareAudioFormats(a, b) {
    return getBitrateNumber(b) - getBitrateNumber(a);
}

function buildTrackLabel(format, kind) {
    var label = [];
    var qualityLabel = trimText(format && format.qualityLabel ? format.qualityLabel : "");
    var audioQuality = trimText(format && format.audioQuality ? format.audioQuality : "");
    var container = getContainerName(format && format.mimeType ? format.mimeType : "");
    var codec = getCodecName(format && format.mimeType ? format.mimeType : "");
    var fps = getFpsNumber(format);

    if (qualityLabel) {
        label.push(qualityLabel + (fps ? ("@" + fps + "fps") : ""));
    } else if (audioQuality) {
        label.push(normalizeAudioQualityLabel(audioQuality));
    } else if (getBitrateNumber(format)) {
        label.push(Math.round(getBitrateNumber(format) / 1000) + "kbps");
    }

    if (kind === "progressive") label.push("có tiếng");
    if (kind === "video") label.push(format && format._audioFormat ? ("audio " + getAudioFormatLabel(format._audioFormat)) : "chỉ hình");
    if (kind === "audio") label.push("chỉ âm thanh");
    if (container) label.push(container);
    if (codec) label.push(codec);

    return label.join(" · ");
}

function findPlayerClientByName(name) {
    var target = trimText(name || "");
    var i;
    for (i = 0; i < PLAYER_CLIENTS.length; i++) {
        if (trimText(PLAYER_CLIENTS[i].name || PLAYER_CLIENTS[i].clientName || "") === target) {
            return PLAYER_CLIENTS[i];
        }
    }
    return ANDROID_VR_CLIENT;
}

function getAudioFormatLabel(format) {
    if (!format) return "";
    if (format.audioQuality) return normalizeAudioQualityLabel(format.audioQuality);
    if (getBitrateNumber(format)) return Math.round(getBitrateNumber(format) / 1000) + "kbps";
    return "Audio";
}

function readWatchMarkCache() {
    var json;
    if (typeof localStorage === "undefined" || !localStorage) return {};
    try {
        json = safeJsonParse(localStorage.getItem(WATCH_MARK_CACHE_KEY));
        return json && typeof json === "object" ? json : {};
    } catch (e) {
        return {};
    }
}

function writeWatchMarkCache(cache) {
    var now = Date.now();
    var kept = {};
    var list = [];
    var i;
    var key;
    if (typeof localStorage === "undefined" || !localStorage) return;
    cache = cache || {};
    for (key in cache) {
        if (!Object.prototype.hasOwnProperty.call(cache, key)) continue;
        if (!key || (now - Number(cache[key] || 0)) > WATCH_MARK_TTL_MS) continue;
        list.push({
            key: key,
            time: Number(cache[key] || 0)
        });
    }
    list.sort(function (a, b) {
        return b.time - a.time;
    });
    for (i = 0; i < list.length && i < WATCH_MARK_MAX_ITEMS; i++) {
        kept[list[i].key] = list[i].time;
    }
    try {
        localStorage.setItem(WATCH_MARK_CACHE_KEY, JSON.stringify(kept));
    } catch (e) { }
}

function wasWatchMarked(videoId) {
    var cache = readWatchMarkCache();
    var key = trimText(videoId || "");
    var time = Number(cache[key] || 0);
    if (!key || !time) return false;
    if ((Date.now() - time) > WATCH_MARK_TTL_MS) {
        delete cache[key];
        writeWatchMarkCache(cache);
        return false;
    }
    return true;
}

function setWatchMarked(videoId) {
    var key = trimText(videoId || "");
    var cache;
    if (!key) return;
    cache = readWatchMarkCache();
    cache[key] = Date.now();
    writeWatchMarkCache(cache);
}

function generateClientPlaybackNonce() {
    var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-";
    var out = "";
    var i;
    for (i = 0; i < 16; i++) {
        out += alphabet.charAt(Math.floor(Math.random() * alphabet.length));
    }
    return out;
}

function sendYouTubeStatsUrl(url, videoId) {
    var response;
    url = trimText(url || "");
    if (!url) return false;
    try {
        response = fetch(url, {
            headers: {
                "Accept": "*/*",
                "Referer": buildWatchUrl(videoId),
                "User-Agent": WEB_DESKTOP_USER_AGENT
            }
        });
        return !!(response && (response.ok || Number(response.status || 0) === 204 || Number(response.status || 0) === 0));
    } catch (e) {
        return false;
    }
}

function markWatchHistoryFromState(state, force) {
    var videoId = trimText(state && state.videoId ? state.videoId : "");
    var player = state && state.player ? state.player : {};
    var webPlayer = state && state.webPlayer ? state.webPlayer : {};
    var embedPlayer = state && state.embedPlayer ? state.embedPlayer : {};
    var tracking = webPlayer && webPlayer.playbackTracking ? webPlayer.playbackTracking :
        (embedPlayer && embedPlayer.playbackTracking ? embedPlayer.playbackTracking :
            (player && player.playbackTracking ? player.playbackTracking : {}));
    var playbackBase = tracking && tracking.videostatsPlaybackUrl ? trimText(tracking.videostatsPlaybackUrl.baseUrl || "") : "";
    var watchtimeBase = tracking && tracking.videostatsWatchtimeUrl ? trimText(tracking.videostatsWatchtimeUrl.baseUrl || "") : "";
    var details = state && state.videoDetails ? state.videoDetails : (player.videoDetails || {});
    var length = Number(details && details.lengthSeconds ? details.lengthSeconds : 0);
    var end = length > 1 ? Math.min(5, Math.max(1, length - 1)) : 5;
    var cpn;
    var playbackOk = false;
    var watchtimeOk = false;
    if (!videoId || (!playbackBase && !watchtimeBase)) return false;
    if (!force && wasWatchMarked(videoId)) return true;
    cpn = generateClientPlaybackNonce();
    if (playbackBase) {
        playbackOk = sendYouTubeStatsUrl(appendQueryParams(playbackBase, {
            ver: "2",
            cpn: cpn,
            cmt: "0",
            rt: "0"
        }), videoId);
    }
    if (watchtimeBase) {
        watchtimeOk = sendYouTubeStatsUrl(appendQueryParams(watchtimeBase, {
            ver: "2",
            cpn: cpn,
            cmt: String(end),
            st: "0",
            et: String(end),
            rt: String(end),
            rti: String(end)
        }), videoId);
    }
    if (playbackOk || watchtimeOk) {
        setWatchMarked(videoId);
        return true;
    }
    return false;
}

function markWatchHistoryByVideoId(videoId, force) {
    var state;
    videoId = trimText(videoId || "");
    if (!videoId || (!force && wasWatchMarked(videoId))) return false;
    try {
        state = getVideoState(videoId, true);
        return markWatchHistoryFromState(state, force);
    } catch (e) {
        return false;
    }
}

function isMp4AudioFormat(format) {
    var mime = trimText(format && format.mimeType ? format.mimeType : "").toLowerCase();
    return getTypeGroup(mime) === "audio" && mime.indexOf("audio/mp4") === 0 && containsCodec(mime, "mp4a");
}

function isMp4AvcVideoFormat(format) {
    var mime = trimText(format && format.mimeType ? format.mimeType : "").toLowerCase();
    return getTypeGroup(mime) === "video" && mime.indexOf("video/mp4") === 0 && containsCodec(mime, "avc1");
}

function isProgressiveMp4AvcAudioFormat(format) {
    var mime = trimText(format && format.mimeType ? format.mimeType : "").toLowerCase();
    return isMp4AvcVideoFormat(format) && containsCodec(mime, "mp4a");
}

function getVideoTrackKey(format) {
    var quality = trimText(format && format.qualityLabel ? format.qualityLabel : "");
    var fps = getFpsNumber(format);
    if (quality) return quality + "@" + fps;
    return String(format && format.itag ? format.itag : "");
}

function pickBestAudioFormat(formats) {
    var preferred = null;
    var fallback = null;
    formats = formats || [];
    for (var i = 0; i < formats.length; i++) {
        if (!formats[i] || !formats[i].url) continue;
        if (!fallback) fallback = formats[i];
        if (!isMp4AudioFormat(formats[i])) continue;
        if (!preferred || getBitrateNumber(formats[i]) > getBitrateNumber(preferred)) preferred = formats[i];
    }
    return preferred || fallback;
}

function countDistinctMp4AudioLanguages(playerJson) {
    var streamingData = playerJson && playerJson.streamingData ? playerJson.streamingData : {};
    var adaptive = streamingData.adaptiveFormats || [];
    var seen = {};
    var count = 0;
    var i;
    for (i = 0; i < adaptive.length; i++) {
        if (!isMp4AudioFormat(adaptive[i])) continue;
        var key = getAudioBucketKey(adaptive[i]);
        if (seen[key]) continue;
        seen[key] = true;
        count++;
    }
    return count;
}

function comparePreferredAudioFormats(a, b) {
    var pa = getAudioPriority(a);
    var pb = getAudioPriority(b);
    var qa;
    var qb;
    if (pa !== pb) return pa - pb;
    qa = getAudioQualityRank(a);
    qb = getAudioQualityRank(b);
    if (qa !== qb) return qa - qb;
    return getBitrateNumber(b) - getBitrateNumber(a);
}

function selectPreferredAudioFormats(formats, maxItems) {
    var candidates = [];
    var buckets = {};
    var bucketOrder = ["vi", "zh", "en", "original"];
    var seenBucket = {};
    var out = [];
    var seen = {};
    var i;
    var key;
    formats = formats || [];
    maxItems = Number(maxItems || 6);
    for (i = 0; i < formats.length; i++) {
        if (!formats[i] || !formats[i].url || !isMp4AudioFormat(formats[i])) continue;
        candidates.push(formats[i]);
        key = getAudioBucketKey(formats[i]);
        if (!buckets[key]) buckets[key] = [];
        buckets[key].push(formats[i]);
        if (!seenBucket[key]) {
            seenBucket[key] = true;
            if (key !== "vi" && key !== "zh" && key !== "en" && key !== "original") bucketOrder.push(key);
        }
    }
    function pushFormat(format) {
        var id;
        if (!format || !format.url) return;
        id = getAudioTrackIdentity(format) || trimText(format.url || "");
        if (!id || seen[id] || out.length >= maxItems) return;
        seen[id] = true;
        out.push(format);
    }
    function bestByRank(list, rank) {
        var best = null;
        var j;
        list = list || [];
        for (j = 0; j < list.length; j++) {
            if (getAudioQualityRank(list[j]) !== rank) continue;
            if (!best || getBitrateNumber(list[j]) > getBitrateNumber(best)) best = list[j];
        }
        return best;
    }
    function bestPrimary(list) {
        var sorted = (list || []).slice().sort(comparePreferredAudioFormats);
        return bestByRank(sorted, 0) || bestByRank(sorted, 1) || sorted[0] || null;
    }
    for (i = 0; i < bucketOrder.length && out.length < maxItems; i++) {
        var list = buckets[bucketOrder[i]] || [];
        if (!list.length) continue;
        pushFormat(bestPrimary(list));
    }
    for (i = 0; i < bucketOrder.length && out.length < maxItems; i++) {
        var sortedList = (buckets[bucketOrder[i]] || []).slice().sort(comparePreferredAudioFormats);
        for (var j = 0; j < sortedList.length && out.length < maxItems; j++) pushFormat(sortedList[j]);
    }
    candidates = candidates.slice().sort(comparePreferredAudioFormats);
    for (i = 0; i < candidates.length && out.length < maxItems; i++) {
        pushFormat(candidates[i]);
    }
    return out.length ? out : candidates.slice(0, maxItems);
}

function isVietnameseAudioPayload(item) {
    item = item || {};
    return isVietnameseLang(item.language || "") || isVietnameseLang(item.label || "") || isVietnameseLang(item.displayName || "");
}

function cloneAudioPayloadAsBackup(item) {
    var out = {};
    var key;
    item = item || {};
    for (key in item) out[key] = item[key];
    out.label = trimText(item.label || "Audio");
    if (!/dự phòng|du phong/i.test(out.label)) out.label += " · dự phòng";
    return out;
}

function withVietnameseBackupAudioChoices(choices, maxItems) {
    var out = [];
    var inserted = false;
    var i;
    choices = choices || [];
    maxItems = Number(maxItems || 6);
    for (i = 0; i < choices.length && out.length < maxItems; i++) {
        out.push(choices[i]);
        if (!inserted && isVietnameseAudioPayload(choices[i]) && out.length < maxItems) {
            out.push(cloneAudioPayloadAsBackup(choices[i]));
            inserted = true;
        }
    }
    return out.slice(0, maxItems);
}

function buildAudioChoicePayloads(formats) {
    var out = [];
    var seen = {};
    var i;
    var format;
    var key;
    formats = selectPreferredAudioFormats(formats || [], 6);
    for (i = 0; i < formats.length; i++) {
        format = formats[i];
        if (!format || !format.url || !isMp4AudioFormat(format)) continue;
        key = getAudioTrackIdentity(format) || trimText(format.mimeType || "") + "|" + getBitrateNumber(format);
        if (seen[key]) continue;
        seen[key] = true;
        var info = getAudioTrackInfo(format);
        var track = format.audioTrack || {};
        out.push({
            itag: format.itag || "",
            audioTrackId: trimText(track.id || ""),
            displayName: trimText(info.displayName || ""),
            mimeType: trimText(format.mimeType || "audio/mp4"),
            label: buildAudioDisplayLabel(format),
            bitrate: getBitrateNumber(format),
            language: info.language || ""
        });
    }
    return withVietnameseBackupAudioChoices(out, 6);
}

function buildResolvedAudioChoicePayloads(formats) {
    var choices = buildAudioChoicePayloads(formats);
    var out = [];
    var i;
    var j;
    var format;
    formats = formats || [];
    for (i = 0; i < choices.length; i++) {
        format = null;
        for (j = 0; j < formats.length; j++) {
            if (!formats[j] || !formats[j].url || !audioFormatMatchesChoice(formats[j], choices[i])) continue;
            format = formats[j];
            break;
        }
        if (!format || !format.url) continue;
        out.push({
            url: trimText(format.url || ""),
            data: trimText(format.url || ""),
            itag: choices[i].itag,
            audioTrackId: choices[i].audioTrackId || "",
            displayName: choices[i].displayName || "",
            mimeType: choices[i].mimeType,
            type: choices[i].mimeType,
            label: choices[i].label,
            bitrate: choices[i].bitrate,
            language: choices[i].language || ""
        });
    }
    return out;
}

function resolveFreshAudioFormats(playerJson, payload) {
    var streamingData = playerJson && playerJson.streamingData ? playerJson.streamingData : {};
    var adaptive = streamingData.adaptiveFormats || [];
    var choices = payload && payload.audioChoices ? payload.audioChoices : [];
    var out = [];
    var seen = {};
    var i;
    var fresh;
    var fallback;
    if (choices && choices.length) {
        for (i = 0; i < choices.length; i++) {
            fresh = null;
            for (var j = 0; j < adaptive.length; j++) {
                if (!adaptive[j] || !adaptive[j].url || !isMp4AudioFormat(adaptive[j])) continue;
                if (audioFormatMatchesChoice(adaptive[j], choices[i])) {
                    fresh = adaptive[j];
                    break;
                }
            }
            if (!fresh || !fresh.url || !isMp4AudioFormat(fresh)) continue;
            var freshKey = getAudioTrackIdentity(fresh);
            if (seen[freshKey]) continue;
            seen[freshKey] = true;
            out.push(fresh);
        }
    }
    if (!out.length) {
        for (i = 0; i < adaptive.length; i++) {
            if (!adaptive[i] || !adaptive[i].url || !isMp4AudioFormat(adaptive[i])) continue;
            var audioKey = getAudioTrackIdentity(adaptive[i]);
            if (seen[audioKey]) continue;
            seen[audioKey] = true;
            out.push(adaptive[i]);
        }
        out = selectPreferredAudioFormats(out, 6);
    } else {
        return out;
    }
    fallback = findFreshStreamingFormat(playerJson, payload && payload.audioItag);
    if (fallback && fallback.url && isMp4AudioFormat(fallback) && out.length) {
        for (i = 0; i < out.length; i++) {
            if (Number(out[i].itag || 0) === Number(fallback.itag || 0)) {
                out.splice(i, 1);
                break;
            }
        }
        out.unshift(fallback);
    }
    return out;
}

function buildTrackItem(format, kind, videoId, audioFormat, subtitles, audioFormats) {
    var clientName = trimText(format && format._playerClient ? format._playerClient : "");
    var client = findPlayerClientByName(clientName);
    var payload;
    if (kind === "video" && audioFormat) format._audioFormat = audioFormat;
    audioFormats = audioFormats || (audioFormat ? [audioFormat] : []);
    payload = {
        resolver: "youtube-direct",
        url: format.url,
        videoId: videoId,
        itag: format && format.itag ? format.itag : "",
        kind: trimText(kind || ""),
        playerClient: trimText(client.name || client.clientName || clientName),
        mimeType: format.mimeType || "",
        audioItag: audioFormat && audioFormat.itag ? audioFormat.itag : "",
        audioMimeType: audioFormat && audioFormat.mimeType ? audioFormat.mimeType : "",
        audioLabel: audioFormat ? getAudioFormatLabel(audioFormat) : "",
        audioChoices: kind === "video" ? buildAudioChoicePayloads(audioFormats) : [],
        referer: YT_BASE + "/",
        userAgent: trimText(client.userAgent || "")
    };
    if (subtitles && subtitles.length) {
        payload.subtitles = subtitles;
        payload.subtitleTracks = subtitles;
    }
    return {
        title: buildTrackLabel(format, kind),
        data: buildTrackPayload(payload)
    };
}

function buildHlsMasterTrackItem(url, videoId, title, userAgent, clientName, subtitles) {
    var payload = {
        resolver: "youtube-hls-master",
        url: trimText(url || ""),
        videoId: videoId,
        hlsClient: trimText(clientName || "IOS"),
        mimeType: "application/vnd.apple.mpegurl",
        referer: YT_BASE + "/",
        userAgent: trimText(userAgent || IOS_CLIENT.userAgent)
    };
    if (subtitles && subtitles.length) {
        payload.subtitles = subtitles;
        payload.subtitleTracks = subtitles;
    }
    return {
        title: trimText(title || "HLS tự động"),
        data: buildTrackPayload(payload)
    };
}

function base64EncodeAscii(text) {
    var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    var out = "";
    var i = 0;
    text = String(text || "");
    while (i < text.length) {
        var c1 = text.charCodeAt(i++) & 255;
        var c2 = i < text.length ? (text.charCodeAt(i++) & 255) : NaN;
        var c3 = i < text.length ? (text.charCodeAt(i++) & 255) : NaN;
        out += chars.charAt(c1 >> 2);
        out += chars.charAt(((c1 & 3) << 4) | (isNaN(c2) ? 0 : (c2 >> 4)));
        out += isNaN(c2) ? "=" : chars.charAt(((c2 & 15) << 2) | (isNaN(c3) ? 0 : (c3 >> 6)));
        out += isNaN(c3) ? "=" : chars.charAt(c3 & 63);
    }
    return out;
}

function buildHlsDataUri(text) {
    return "data:application/vnd.apple.mpegurl;base64," + base64EncodeAscii(text);
}

function buildHlsTrackLabel(entry) {
    var label = [];
    var resolution = trimText(entry && entry.resolution ? entry.resolution : "");
    var fps = Number(entry && entry.fps ? entry.fps : 0);
    var prefix = trimText(entry && entry.prefix ? entry.prefix : "");
    if (prefix) label.push(prefix);
    if (resolution) label.push(resolution + (fps ? ("@" + fps + "fps") : ""));
    label.push(entry && entry.audioChoices && entry.audioChoices.length ? "HLS kèm audio" : "HLS");
    return label.join(" · ");
}

function buildHlsTrackItem(entry, videoId, subtitles) {
    var payload = {
        resolver: "youtube-hls-variant",
        url: trimText(entry.url || ""),
        videoId: videoId,
        hlsClient: trimText(entry.hlsClient || "IOS"),
        resolution: trimText(entry.resolution || ""),
        fps: Math.round(Number(entry.fps || 0)),
        mimeType: "application/vnd.apple.mpegurl",
        referer: YT_BASE + "/",
        userAgent: trimText(entry.userAgent || IOS_CLIENT.userAgent)
    };
    if (entry.audioChoices && entry.audioChoices.length) {
        payload.audioChoices = entry.audioChoices;
        payload.audioUrl = trimText(entry.audioChoices[0].data || entry.audioChoices[0].url || "");
        payload.audioMimeType = trimText(entry.audioChoices[0].mimeType || entry.audioChoices[0].type || "application/vnd.apple.mpegurl");
        payload.audioLabel = trimText(entry.audioChoices[0].label || "Audio");
    }
    if (subtitles && subtitles.length) {
        payload.subtitles = subtitles;
        payload.subtitleTracks = subtitles;
    }
    return {
        title: buildHlsTrackLabel(entry),
        data: buildTrackPayload(payload)
    };
}

function isLiveState(state) {
    var videoDetails = state && state.videoDetails ? state.videoDetails : {};
    var microformat = state && state.microformat ? state.microformat : {};
    var liveDetails = microformat && microformat.liveBroadcastDetails ? microformat.liveBroadcastDetails : {};
    var player = state && state.player ? state.player : {};
    var playabilityStatus = player && player.playabilityStatus ? player.playabilityStatus : {};
    var streamingData = player && player.streamingData ? player.streamingData : {};
    var adaptive = streamingData && streamingData.adaptiveFormats ? streamingData.adaptiveFormats : [];
    var i;
    if (liveDetails && (liveDetails.isLiveNow === true || trimText(liveDetails.isLiveNow) === "true")) return true;
    if (playabilityStatus && playabilityStatus.liveStreamability) return true;
    if (videoDetails && videoDetails.isLiveContent) return true;
    if (trimText(streamingData.hlsManifestUrl || "") && adaptive.length) {
        for (i = 0; i < adaptive.length; i++) {
            if (adaptive[i] && Number(adaptive[i].targetDurationSec || 0) > 0) return true;
        }
    }
    return false;
}

function getStateHlsManifestInfo(state) {
    var streamingData = state && state.player && state.player.streamingData ? state.player.streamingData : {};
    var manifestUrl = trimText(streamingData.hlsManifestUrl || "");
    var client = findPlayerClientByName(state && state.playerClient ? state.playerClient : "");
    if (!manifestUrl) return null;
    return {
        url: manifestUrl,
        clientName: trimText(client && (client.name || client.clientName) ? (client.name || client.clientName) : ""),
        userAgent: trimText(client && client.userAgent ? client.userAgent : IOS_CLIENT.userAgent)
    };
}

function getLiveTracks(state) {
    var manifest = getStateHlsManifestInfo(state);
    var iosTracks;
    if (manifest && manifest.url) {
        var manifestRsp = fetchText(manifest.url, {
            headers: {
                "Referer": YT_BASE + "/",
                "User-Agent": manifest.userAgent
            }
        });
        var text = trimText(manifestRsp.text || "");
        var subtitles = buildYouTubeSubtitleTracks(state && state.player ? state.player : {});
        var tracks = [
            buildSafeHlsMasterTrackItem(
                manifest.url,
                state && state.videoId ? state.videoId : "",
                text,
                "Trực tiếp · HLS tự động",
                manifest.userAgent,
                manifest.clientName,
                subtitles
            )
        ];
        if (text) {
            tracks = tracks.concat(buildHlsVariantTrackItemsFromText(manifest.url, text, state, {
                prefix: "Trực tiếp",
                userAgent: manifest.userAgent,
                clientName: manifest.clientName
            }, subtitles));
        }
        return sortHlsTrackItems(tracks);
    }
    iosTracks = fetchIosHlsTracks(state, {
        includeMaster: true,
        probeChild: false,
        prefix: "Trực tiếp"
    });
    if (iosTracks.length) {
        iosTracks[0].title = /HLS tự động/i.test(String(iosTracks[0].title || ""))
            ? "Trực tiếp · HLS tự động"
            : "Trực tiếp · HLS";
        return [iosTracks[0]];
    }
    return [];
}

function parseHlsAttributes(line) {
    var attrs = {};
    var text = String(line || "");
    var index = text.indexOf(":");
    if (index >= 0) text = text.slice(index + 1);
    var pattern = /([A-Z0-9-]+)=("[^"]*"|[^,]+)/g;
    var match;
    while ((match = pattern.exec(text))) {
        var value = String(match[2] || "");
        if (value.length >= 2 && value.charAt(0) === "\"" && value.charAt(value.length - 1) === "\"") {
            value = value.slice(1, -1);
        }
        attrs[match[1]] = value;
    }
    return attrs;
}

function buildResolutionLabel(value) {
    var match = String(value || "").match(/(\d+)x(\d+)/);
    if (!match) return "";
    return trimText(match[2]) + "p";
}

function getHlsMasterVariants(masterUrl, text) {
    var lines = String(text || "").split(/\r?\n/);
    var variants = [];
    var i;
    for (i = 0; i < lines.length; i++) {
        var line = trimText(lines[i]);
        if (!startsWithText(line, "#EXT-X-STREAM-INF:")) continue;
        variants.push({
            line: line,
            attrs: parseHlsAttributes(line),
            url: resolveRelativeUrl(masterUrl, trimText(lines[i + 1] || ""))
        });
    }
    return variants;
}

function getHlsAudioEntries(masterUrl, text) {
    var lines = String(text || "").split(/\r?\n/);
    var entries = [];
    var i;
    for (i = 0; i < lines.length; i++) {
        var line = trimText(lines[i]);
        var attrs;
        var uri;
        if (!startsWithText(line, "#EXT-X-MEDIA:")) continue;
        attrs = parseHlsAttributes(line);
        if (trimText(attrs["TYPE"] || "").toUpperCase() !== "AUDIO") continue;
        uri = trimText(attrs["URI"] || "");
        if (!uri) continue;
        entries.push({
            line: line,
            attrs: attrs,
            url: resolveRelativeUrl(masterUrl, uri)
        });
    }
    return entries;
}

function getHlsAudioTrackInfo(entry) {
    var attrs = entry && entry.attrs ? entry.attrs : {};
    var name = trimText(attrs["NAME"] || attrs["LANGUAGE"] || "");
    var lang = normalizeAudioLanguage(attrs["LANGUAGE"] || "");
    return {
        language: lang,
        displayName: name,
        isDefault: trimText(attrs["DEFAULT"] || "").toUpperCase() === "YES",
        isOriginal: /original|gốc|原始|原聲|原声/i.test(name)
    };
}

function getHlsAudioPriority(entry) {
    var info = getHlsAudioTrackInfo(entry);
    if (isVietnameseLang(info.language) || isVietnameseLang(info.displayName)) return 0;
    if (isChineseLang(info.language) || isChineseLang(info.displayName)) return 1;
    if (!(info.isDefault || info.isOriginal) && (isEnglishLang(info.language) || isEnglishLang(info.displayName))) return 2;
    if (info.isDefault || info.isOriginal) return 3;
    if (isEnglishLang(info.language) || isEnglishLang(info.displayName)) return 2;
    return 4;
}

function getHlsAudioBucketKey(entry) {
    var info = getHlsAudioTrackInfo(entry);
    if (isVietnameseLang(info.language) || isVietnameseLang(info.displayName)) return "vi";
    if (isChineseLang(info.language) || isChineseLang(info.displayName)) return "zh";
    if (!(info.isDefault || info.isOriginal) && (isEnglishLang(info.language) || isEnglishLang(info.displayName))) return "en";
    if (info.isDefault || info.isOriginal) return "original";
    if (isEnglishLang(info.language) || isEnglishLang(info.displayName)) return "en";
    return "other:" + (info.language || info.displayName || "unknown");
}

function getHlsAudioQualityRank(entry) {
    var attrs = entry && entry.attrs ? entry.attrs : {};
    var groupId = trimText(attrs["GROUP-ID"] || "");
    var name = trimText(attrs["NAME"] || "");
    var text = (groupId + " " + name).toLowerCase();
    if (text.indexOf("medium") >= 0 || text.indexOf("trung") >= 0 || /(^|[^0-9])140([^0-9]|$)/.test(text) || /(^|[^0-9])234([^0-9]|$)/.test(text)) return 0;
    if (text.indexOf("low") >= 0 || text.indexOf("thấp") >= 0 || /(^|[^0-9])139([^0-9]|$)/.test(text) || /(^|[^0-9])233([^0-9]|$)/.test(text)) return 1;
    return 2;
}

function compareHlsAudioEntries(a, b) {
    var pa = getHlsAudioPriority(a);
    var pb = getHlsAudioPriority(b);
    var qa;
    var qb;
    if (pa !== pb) return pa - pb;
    qa = getHlsAudioQualityRank(a);
    qb = getHlsAudioQualityRank(b);
    if (qa !== qb) return qa - qb;
    return trimText((a && a.attrs ? a.attrs["NAME"] : "") || "").localeCompare(trimText((b && b.attrs ? b.attrs["NAME"] : "") || ""));
}

function selectPreferredHlsAudioEntries(entries, maxItems) {
    var buckets = {};
    var bucketOrder = ["vi", "zh", "en", "original"];
    var seenBucket = {};
    var out = [];
    var seen = {};
    var i;
    var key;
    entries = entries || [];
    maxItems = Number(maxItems || 6);
    for (i = 0; i < entries.length; i++) {
        if (!entries[i] || !entries[i].url) continue;
        key = getHlsAudioBucketKey(entries[i]);
        if (!buckets[key]) buckets[key] = [];
        buckets[key].push(entries[i]);
        if (!seenBucket[key]) {
            seenBucket[key] = true;
            if (key !== "vi" && key !== "zh" && key !== "en" && key !== "original") bucketOrder.push(key);
        }
    }
    function pushEntry(entry) {
        var id;
        if (!entry || !entry.url || out.length >= maxItems) return;
        id = trimText(entry.url || "");
        if (!id || seen[id]) return;
        seen[id] = true;
        out.push(entry);
    }
    function bestByRank(list, rank) {
        var sorted = (list || []).slice().sort(compareHlsAudioEntries);
        var j;
        for (j = 0; j < sorted.length; j++) {
            if (getHlsAudioQualityRank(sorted[j]) === rank) return sorted[j];
        }
        return null;
    }
    function bestPrimary(list) {
        var sorted = (list || []).slice().sort(compareHlsAudioEntries);
        return bestByRank(sorted, 0) || bestByRank(sorted, 1) || sorted[0] || null;
    }
    for (i = 0; i < bucketOrder.length && out.length < maxItems; i++) {
        var list = buckets[bucketOrder[i]] || [];
        if (!list.length) continue;
        pushEntry(bestPrimary(list));
    }
    for (i = 0; i < bucketOrder.length && out.length < maxItems; i++) {
        var sortedList = (buckets[bucketOrder[i]] || []).slice().sort(compareHlsAudioEntries);
        for (var j = 0; j < sortedList.length && out.length < maxItems; j++) pushEntry(sortedList[j]);
    }
    entries = entries.slice().sort(compareHlsAudioEntries);
    for (i = 0; i < entries.length && out.length < maxItems; i++) pushEntry(entries[i]);
    return out;
}

function buildHlsAudioChoicePayloads(entries) {
    var out = [];
    var i;
    entries = selectPreferredHlsAudioEntries(entries || [], 6);
    for (i = 0; i < entries.length; i++) {
        var info = getHlsAudioTrackInfo(entries[i]);
        var name = trimText(info.displayName || info.language || "Audio");
        var quality = getHlsAudioQualityRank(entries[i]) === 0 ? "trung bình" : (getHlsAudioQualityRank(entries[i]) === 1 ? "thấp" : "");
        out.push({
            url: trimText(entries[i].url || ""),
            data: trimText(entries[i].url || ""),
            mimeType: "application/vnd.apple.mpegurl",
            type: "application/vnd.apple.mpegurl",
            label: trimText(name + (quality ? (" · " + quality) : "")),
            language: info.language || ""
        });
    }
    return withVietnameseBackupAudioChoices(out, 6);
}

function getHlsAudioChoicesForVariant(masterUrl, text, attrs) {
    var groupId = trimText(attrs && attrs["AUDIO"] ? attrs["AUDIO"] : "");
    var entries = getHlsAudioEntries(masterUrl, text);
    var filtered = [];
    var i;
    for (i = 0; i < entries.length; i++) {
        if (groupId && trimText(entries[i].attrs && entries[i].attrs["GROUP-ID"] || "") !== groupId) continue;
        filtered.push(entries[i]);
    }
    if (!filtered.length && groupId) filtered = entries;
    return buildHlsAudioChoicePayloads(filtered);
}

function isUnsafeHlsMaster(masterUrl, text) {
    var variants = getHlsMasterVariants(masterUrl, text);
    var seen = {};
    var i;
    if (variants.length > 15) return true;
    for (i = 0; i < variants.length; i++) {
        var attrs = variants[i].attrs || {};
        var key = trimText(attrs["CODECS"] || "") + "|" +
            trimText(attrs["RESOLUTION"] || "") + "|" +
            trimText(attrs["FRAME-RATE"] || "") + "|" +
            trimText(attrs["AUDIO"] || "");
        if (seen[key]) return true;
        seen[key] = true;
    }
    return false;
}

function buildSanitizedHlsMasterText(masterUrl, text) {
    var lines = String(text || "").split(/\r?\n/);
    var variants = getHlsMasterVariants(masterUrl, text);
    var audioLines = [];
    var usedAudio = {};
    var kept = [];
    var out = ["#EXTM3U"];
    var hasIndependent = false;
    var i;
    for (i = 0; i < lines.length; i++) {
        var line = trimText(lines[i]);
        if (line === "#EXT-X-INDEPENDENT-SEGMENTS") hasIndependent = true;
        if (startsWithText(line, "#EXT-X-MEDIA:")) audioLines.push({
            line: line,
            attrs: parseHlsAttributes(line)
        });
    }
    for (i = 0; i < variants.length; i++) {
        var attrs = variants[i].attrs || {};
        var codecs = trimText(attrs["CODECS"] || "").toLowerCase();
        if (codecs.indexOf("avc1") < 0 || codecs.indexOf("mp4a") < 0) continue;
        if (!variants[i].url) continue;
        kept.push(variants[i]);
        if (attrs["AUDIO"]) usedAudio[trimText(attrs["AUDIO"])] = true;
    }
    if (!kept.length) return "";
    if (hasIndependent) out.push("#EXT-X-INDEPENDENT-SEGMENTS");
    for (i = 0; i < audioLines.length; i++) {
        var groupId = trimText(audioLines[i].attrs["GROUP-ID"] || "");
        if (!groupId || usedAudio[groupId]) out.push(audioLines[i].line);
    }
    for (i = 0; i < kept.length; i++) {
        out.push(kept[i].line);
        out.push(kept[i].url);
    }
    return out.join("\n") + "\n";
}

function buildSafeHlsMasterTrackItem(manifestUrl, videoId, text, title, userAgent, clientName, subtitles) {
    var url = trimText(manifestUrl || "");
    var safeText;
    if (url && text && isUnsafeHlsMaster(url, text)) {
        safeText = buildSanitizedHlsMasterText(url, text);
        if (safeText) url = buildHlsDataUri(safeText);
    }
    return buildHlsMasterTrackItem(url, videoId, title, userAgent, clientName, subtitles);
}

function sortHlsTrackItems(tracks) {
    tracks = tracks || [];
    tracks.sort(function (a, b) {
        var ah = /HLS tự động/i.test(String(a.title || ""));
        var bh = /HLS tự động/i.test(String(b.title || ""));
        if (ah && !bh) return -1;
        if (!ah && bh) return 1;
        var am = String(a.title || "").match(/(\d+)p(?:@(\d+)fps)?/i);
        var bm = String(b.title || "").match(/(\d+)p(?:@(\d+)fps)?/i);
        var aq = am && am[1] ? Number(am[1]) : 0;
        var bq = bm && bm[1] ? Number(bm[1]) : 0;
        if (bq !== aq) return bq - aq;
        var af = am && am[2] ? Number(am[2]) : 0;
        var bf = bm && bm[2] ? Number(bm[2]) : 0;
        return bf - af;
    });
    return tracks;
}

function buildHlsVariantTrackItemsFromText(manifestUrl, text, state, options, subtitles) {
    var variants = getHlsMasterVariants(manifestUrl, text);
    var tracks = [];
    var seen = {};
    var i;
    options = options || {};
    for (i = 0; i < variants.length; i++) {
        var attrs = variants[i].attrs || {};
        var url = variants[i].url;
        var codecs = trimText(attrs["CODECS"] || "");
        var key;
        if (!url || startsWithText(url, "#")) continue;
        if (codecs.toLowerCase().indexOf("avc1") < 0 || codecs.toLowerCase().indexOf("mp4a") < 0) continue;
        key = trimText(attrs["RESOLUTION"] || "") + "|" + trimText(attrs["FRAME-RATE"] || "") + "|" + trimText(attrs["AUDIO"] || "");
        if (seen[key]) continue;
        seen[key] = true;
        tracks.push(buildHlsTrackItem({
            url: url,
            resolution: buildResolutionLabel(attrs["RESOLUTION"] || ""),
            fps: Math.round(Number(attrs["FRAME-RATE"] || 0)),
            audioChoices: getHlsAudioChoicesForVariant(manifestUrl, text, attrs),
            prefix: trimText(options.prefix || ""),
            userAgent: trimText(options.userAgent || IOS_CLIENT.userAgent),
            hlsClient: trimText(options.clientName || "IOS")
        }, state && state.videoId ? state.videoId : "", subtitles));
    }
    return sortHlsTrackItems(tracks);
}

function getFirstHlsMediaUrl(playlistUrl, text) {
    var lines = String(text || "").split(/\r?\n/);
    var i;
    for (i = 0; i < lines.length; i++) {
        var line = trimText(lines[i]);
        if (!line || startsWithText(line, "#")) continue;
        return resolveRelativeUrl(playlistUrl, line);
    }
    return "";
}

function isHlsMediaPlaylistUsable(playlistUrl) {
    var playlistRsp;
    var segmentUrl;
    var segmentRsp;
    try {
        playlistRsp = fetchText(playlistUrl, {
            headers: {
                "Referer": YT_BASE + "/",
                "User-Agent": IOS_CLIENT.userAgent
            }
        });
        if (!playlistRsp.ok || !playlistRsp.text) return false;
        segmentUrl = getFirstHlsMediaUrl(playlistUrl, playlistRsp.text);
        if (!segmentUrl) return false;
        segmentRsp = fetch(segmentUrl, {
            headers: {
                "Referer": YT_BASE + "/",
                "User-Agent": IOS_CLIENT.userAgent,
                "Range": "bytes=0-0"
            }
        });
        return !!(segmentRsp && (Number(segmentRsp.status || 0) === 200 || Number(segmentRsp.status || 0) === 206));
    } catch (e) {
        return false;
    }
}

function cloneResolvedTrackPayload(payload, url, mimeType, userAgent, audioFormat, audioFormats) {
    var out = {};
    var key;
    payload = payload || {};
    for (key in payload) out[key] = payload[key];
    out.url = trimText(url || "");
    if (mimeType) out.mimeType = trimText(mimeType || "");
    if (audioFormats && audioFormats.length) {
        out.audioChoices = buildResolvedAudioChoicePayloads(audioFormats);
        audioFormat = out.audioChoices.length ? out.audioChoices[0] : audioFormat;
    }
    if (audioFormat && audioFormat.url) {
        out.audioUrl = trimText(audioFormat.url || "");
        out.audioItag = audioFormat.itag || out.audioItag || "";
        out.audioMimeType = trimText(audioFormat.mimeType || out.audioMimeType || "audio/mp4");
        out.audioLabel = trimText(out.audioLabel || getAudioFormatLabel(audioFormat));
    } else if (audioFormat && audioFormat.data) {
        out.audioUrl = trimText(audioFormat.data || "");
        out.audioItag = audioFormat.itag || out.audioItag || "";
        out.audioMimeType = trimText(audioFormat.mimeType || audioFormat.type || out.audioMimeType || "audio/mp4");
        out.audioLabel = trimText(out.audioLabel || audioFormat.label || "Audio");
    }
    out.referer = YT_BASE + "/";
    out.userAgent = trimText(userAgent || out.userAgent || "");
    out.resolvedAt = Date.now();
    return out;
}

function attachResolvedAudioChoices(payload, choices) {
    payload = payload || {};
    choices = choices || [];
    if (!choices.length) return payload;
    payload.audioChoices = choices;
    payload.audioUrl = trimText(choices[0].data || choices[0].url || "");
    payload.audioItag = choices[0].itag || payload.audioItag || "";
    payload.audioMimeType = trimText(choices[0].mimeType || choices[0].type || payload.audioMimeType || "application/vnd.apple.mpegurl");
    payload.audioLabel = trimText(choices[0].label || payload.audioLabel || "Audio");
    return payload;
}

function attachSubtitleTracks(payload, subtitles) {
    payload = payload || {};
    if (subtitles && subtitles.length) {
        payload.subtitles = subtitles;
        payload.subtitleTracks = subtitles;
    }
    return payload;
}

function getFreshPlaybackContext(videoId) {
    var contextInfo = fetchWatchContext(videoId);
    if (!contextInfo.apiKey || !contextInfo.visitorData) {
        contextInfo = fetchEmbedContext(videoId);
    }
    if (!contextInfo.apiKey || !contextInfo.visitorData) return null;
    return contextInfo;
}

function findFreshStreamingFormat(playerJson, itag) {
    var streamingData = playerJson && playerJson.streamingData ? playerJson.streamingData : {};
    var lists = [streamingData.formats || [], streamingData.adaptiveFormats || []];
    var i;
    var j;
    itag = Number(itag || 0);
    if (!itag) return null;
    for (i = 0; i < lists.length; i++) {
        for (j = 0; j < lists[i].length; j++) {
            if (Number(lists[i][j] && lists[i][j].itag || 0) === itag && trimText(lists[i][j].url || "")) {
                return lists[i][j];
            }
        }
    }
    return null;
}

function resolveFreshDirectTrackPayload(payload) {
    var videoId = trimText(payload && payload.videoId ? payload.videoId : "");
    var contextInfo;
    var client;
    var playerRsp;
    var format;
    var audioFormat = null;
    var audioFormats = [];
    var streamingData;
    if (!videoId || !payload || !payload.itag) return null;
    contextInfo = getFreshPlaybackContext(videoId);
    if (!contextInfo) return null;
    client = findPlayerClientByName(payload.playerClient || "");
    playerRsp = postPlayer(videoId, contextInfo, client);
    format = findFreshStreamingFormat(playerRsp && playerRsp.json ? playerRsp.json : {}, payload.itag);
    if (!format || !format.url) return null;
    if (trimText(payload.kind || "") === "video") {
        audioFormats = resolveFreshAudioFormats(playerRsp && playerRsp.json ? playerRsp.json : {}, payload);
        audioFormat = audioFormats.length ? audioFormats[0] : null;
        if (!audioFormat || !audioFormat.url) {
            streamingData = playerRsp && playerRsp.json && playerRsp.json.streamingData ? playerRsp.json.streamingData : {};
            audioFormat = pickBestAudioFormat(streamingData.adaptiveFormats || []);
            audioFormats = audioFormat ? [audioFormat] : [];
        }
    }
    return attachSubtitleTracks(
        cloneResolvedTrackPayload(payload, format.url, format.mimeType || payload.mimeType || "", client.userAgent, audioFormat, audioFormats),
        buildYouTubeSubtitleTracks(playerRsp && playerRsp.json ? playerRsp.json : {})
    );
}

function getFreshHlsManifestInfo(videoId, clientName) {
    var contextInfo;
    var client;
    var playerRsp;
    var manifestUrl = "";
    var text = "";
    videoId = trimText(videoId || "");
    if (!videoId) return null;
    contextInfo = getFreshPlaybackContext(videoId);
    if (!contextInfo) return null;
    client = clientName ? findPlayerClientByName(clientName) : IOS_CLIENT;
    playerRsp = postPlayer(videoId, contextInfo, client);
    manifestUrl = trimText(playerRsp && playerRsp.json && playerRsp.json.streamingData ? playerRsp.json.streamingData.hlsManifestUrl || "" : "");
    if (!manifestUrl && trimText(clientName || "") !== "IOS") {
        client = IOS_CLIENT;
        playerRsp = postPlayer(videoId, contextInfo, client);
        manifestUrl = trimText(playerRsp && playerRsp.json && playerRsp.json.streamingData ? playerRsp.json.streamingData.hlsManifestUrl || "" : "");
    }
    if (!manifestUrl) return null;
    try {
        text = trimText(fetchText(manifestUrl, {
            headers: {
                "Referer": YT_BASE + "/",
                "User-Agent": trimText(client.userAgent || IOS_CLIENT.userAgent)
            }
        }).text || "");
    } catch (e) {
        text = "";
    }
    return {
        url: manifestUrl,
        text: text,
        clientName: trimText(client.name || client.clientName || ""),
        userAgent: trimText(client.userAgent || IOS_CLIENT.userAgent),
        subtitles: buildYouTubeSubtitleTracks(playerRsp && playerRsp.json ? playerRsp.json : {})
    };
}

function findFreshHlsVariant(manifestUrl, text, resolution, fps) {
    var variants = getHlsMasterVariants(manifestUrl, text);
    var fallback = null;
    var i;
    var item;
    var attrs;
    var codecs;
    var itemResolution;
    var itemFps;
    resolution = trimText(resolution || "");
    fps = Number(fps || 0);
    for (i = 0; i < variants.length; i++) {
        item = variants[i] || {};
        attrs = item.attrs || {};
        codecs = trimText(attrs["CODECS"] || "").toLowerCase();
        if (codecs.indexOf("avc1") < 0 || codecs.indexOf("mp4a") < 0) continue;
        itemResolution = buildResolutionLabel(attrs["RESOLUTION"] || "");
        itemFps = Math.round(Number(attrs["FRAME-RATE"] || 0));
        if (resolution && itemResolution !== resolution) continue;
        if (!fallback) fallback = item;
        if (!fps || !itemFps || itemFps === fps) return item;
    }
    return fallback;
}

function resolveFreshHlsVariantTrackPayload(payload) {
    var info = getFreshHlsManifestInfo(payload && payload.videoId ? payload.videoId : "", payload && payload.hlsClient ? payload.hlsClient : "IOS");
    var variant;
    var resolved;
    if (!info || !info.text) return null;
    variant = findFreshHlsVariant(info.url, info.text, payload.resolution || "", payload.fps || 0);
    if (!variant || !variant.url) return null;
    resolved = cloneResolvedTrackPayload(payload, variant.url, "application/vnd.apple.mpegurl", info.userAgent);
    attachResolvedAudioChoices(resolved, getHlsAudioChoicesForVariant(info.url, info.text, variant.attrs || {}));
    return attachSubtitleTracks(
        resolved,
        info.subtitles || []
    );
}

function resolveFreshHlsMasterTrackPayload(payload) {
    var info = getFreshHlsManifestInfo(payload && payload.videoId ? payload.videoId : "", payload && payload.hlsClient ? payload.hlsClient : "IOS");
    var url;
    var safeText;
    if (!info || !info.url) return null;
    url = info.url;
    if (info.text && isUnsafeHlsMaster(info.url, info.text)) {
        safeText = buildSanitizedHlsMasterText(info.url, info.text);
        if (safeText) url = buildHlsDataUri(safeText);
    }
    return attachSubtitleTracks(
        cloneResolvedTrackPayload(payload, url, "application/vnd.apple.mpegurl", info.userAgent),
        info.subtitles || []
    );
}

function resolveFreshTrackPayload(payload) {
    var resolver = trimText(payload && payload.resolver ? payload.resolver : "");
    var resolved = null;
    if (resolver === "youtube-direct") resolved = resolveFreshDirectTrackPayload(payload);
    else if (resolver === "youtube-hls-variant") resolved = resolveFreshHlsVariantTrackPayload(payload);
    else if (resolver === "youtube-hls-master") resolved = resolveFreshHlsMasterTrackPayload(payload);
    return resolved || payload || {};
}

function fetchIosHlsTracks(state, options) {
    var contextInfo = null;
    var playerRsp;
    var manifestUrl = "";
    var manifestRsp;
    var text;
    var tracks = [];
    var i;
    var subtitles = [];
    options = options || {};
    if (!state || !state.videoId) return [];
    if (state.watch && state.watch.apiKey && state.watch.visitorData) {
        contextInfo = {
            apiKey: state.watch.apiKey,
            visitorData: state.watch.visitorData
        };
    } else if (state.embed && state.embed.apiKey && state.embed.visitorData) {
        contextInfo = {
            apiKey: state.embed.apiKey,
            visitorData: state.embed.visitorData
        };
    }
    if (!contextInfo) return [];
    playerRsp = postPlayer(state.videoId, contextInfo, IOS_CLIENT);
    manifestUrl = trimText(playerRsp && playerRsp.json && playerRsp.json.streamingData ? playerRsp.json.streamingData.hlsManifestUrl || "" : "");
    if (!manifestUrl) return [];
    manifestRsp = fetchText(manifestUrl, {
        headers: {
            "Referer": YT_BASE + "/",
            "User-Agent": IOS_CLIENT.userAgent
        }
    });
    text = trimText(manifestRsp.text || "");
    subtitles = buildYouTubeSubtitleTracks(playerRsp && playerRsp.json ? playerRsp.json : {});
    if (options.includeMaster) {
        tracks.push(buildSafeHlsMasterTrackItem(manifestUrl, state.videoId, text, "HLS tự động", IOS_CLIENT.userAgent, "IOS", subtitles));
    }
    if (!text) return options.includeMaster ? tracks : [];
    tracks = tracks.concat(buildHlsVariantTrackItemsFromText(manifestUrl, text, state, {
        prefix: trimText(options.prefix || ""),
        userAgent: IOS_CLIENT.userAgent,
        clientName: "IOS"
    }, subtitles));
    sortHlsTrackItems(tracks);
    if (options.probeChild !== false && tracks.length) {
        var firstPayload = null;
        for (i = 0; i < tracks.length; i++) {
            if (/HLS tự động/i.test(String(tracks[i].title || ""))) continue;
            firstPayload = safeJsonParse(tracks[i].data || "");
            break;
        }
        if (!firstPayload || !isHlsMediaPlaylistUsable(firstPayload.url || "")) return [];
    }
    return tracks;
}

function getDirectTracks(state) {
    var tracks = [];
    var seen = {};
    var seenVideoKey = {};
    var streamingData = state && state.player && state.player.streamingData ? state.player.streamingData : {};
    var progressive = streamingData.formats || [];
    var adaptive = streamingData.adaptiveFormats || [];
    var videoId = state && state.videoId ? state.videoId : "";
    var i;
    var key;

    progressive.sort(compareVideoFormats);
    for (i = 0; i < progressive.length; i++) {
        if (!progressive[i] || !progressive[i].url || seen["p:" + progressive[i].itag]) continue;
        if (!isProgressiveMp4AvcAudioFormat(progressive[i])) continue;
        progressive[i]._playerClient = trimText(state && state.playerClient ? state.playerClient : "");
        seen["p:" + progressive[i].itag] = true;
        tracks.push(buildTrackItem(progressive[i], "progressive", videoId));
    }

    var videoOnly = [];
    var audioOnly = [];
    for (i = 0; i < adaptive.length; i++) {
        if (!adaptive[i] || !adaptive[i].url) continue;
        adaptive[i]._playerClient = trimText(state && state.playerClient ? state.playerClient : "");
        if (isMp4AvcVideoFormat(adaptive[i]) && !seen["v:" + adaptive[i].itag]) {
            seen["v:" + adaptive[i].itag] = true;
            videoOnly.push(adaptive[i]);
        }
        if (isMp4AudioFormat(adaptive[i])) {
            var audioKey = getAudioTrackIdentity(adaptive[i]);
            if (!seen["au:" + audioKey]) {
                seen["au:" + audioKey] = true;
                audioOnly.push(adaptive[i]);
            }
        }
    }

    videoOnly.sort(compareVideoFormats);
    var selectedAudio = selectPreferredAudioFormats(audioOnly, 6);
    var bestAudio = selectedAudio.length ? selectedAudio[0] : pickBestAudioFormat(audioOnly);

    for (i = 0; i < videoOnly.length; i++) {
        key = getVideoTrackKey(videoOnly[i]);
        if (key && seenVideoKey[key]) continue;
        seenVideoKey[key] = true;
        tracks.push(buildTrackItem(videoOnly[i], "video", videoId, bestAudio, null, selectedAudio));
    }

    return tracks;
}

function getProgressiveSoundTracks(tracks) {
    var out = [];
    var i;
    tracks = tracks || [];
    for (i = 0; i < tracks.length; i++) {
        if (/có tiếng/i.test(String(tracks[i] && tracks[i].title || ""))) out.push(tracks[i]);
    }
    return out;
}

function getFirstSoundDirectTrack(tracks) {
    var i;
    tracks = tracks || [];
    for (i = 0; i < tracks.length; i++) {
        if (/có tiếng/i.test(String(tracks[i] && tracks[i].title || ""))) return tracks[i];
    }
    return null;
}

function shouldPreferHlsFirstState(state) {
    var attempts = state && state.playerAttempts ? state.playerAttempts : [];
    var chosenClient = trimText(state && state.playerClient ? state.playerClient : "");
    var vrOk = false;
    var vrBad = false;
    var androidOk = false;
    var i;
    if (isLiveState(state)) return true;
    if (chosenClient !== "ANDROID") return false;
    for (i = 0; i < attempts.length; i++) {
        var item = attempts[i] || {};
        var clientName = trimText(item.clientName || "");
        var playability = trimText(item.playability || "");
        if (clientName === "ANDROID_VR") {
            if (playability === "OK") vrOk = true;
            else if (playability) vrBad = true;
        }
        if (clientName === "ANDROID" && playability === "OK") androidOk = true;
    }
    return androidOk && vrBad && !vrOk;
}

function isMultilingualAudioState(state) {
    return countDistinctMp4AudioLanguages(state && state.player ? state.player : {}) > 1;
}

function getPreferredTracks(state) {
    if (isLiveState(state)) {
        var liveTracks = getLiveTracks(state);
        if (liveTracks.length) return liveTracks;
    }

    var direct = getDirectTracks(state);
    var playerClient = trimText(state && state.playerClient ? state.playerClient : "");
    var preferHls = shouldPreferHlsFirstState(state);
    var needsHlsAudio = isKidsState(state) || isMultilingualAudioState(state);

    if (needsHlsAudio) {
        var soundTrack = getFirstSoundDirectTrack(direct);
        var safeDirect = [];
        var hls = fetchIosHlsTracks(state, {
            includeMaster: false,
            probeChild: isKidsState(state) ? false : !preferHls
        });
        if (soundTrack) safeDirect.push(soundTrack);
        else if (direct.length) safeDirect.push(direct[0]);
        if (hls.length) return safeDirect.concat(hls);
        return safeDirect.length ? safeDirect : direct;
    }

    if (playerClient === "ANDROID_VR") return direct;
    if (direct.length) return direct;

    return fetchIosHlsTracks(state, {
        includeMaster: true,
        probeChild: false
    });
}
