load("shared.js");

function execute(url) {
    var videoId = parseEpisodeLink(url) || getActiveVideoId(url);
    var state = getVideoState(videoId, true);
    var playability = state && state.player && state.player.playabilityStatus ? state.player.playabilityStatus.status || "" : "";
    if (!state.player || !state.player.streamingData) {
        return Response.error("Không lấy được dữ liệu phát từ YouTube");
    }
    if (playability && playability !== "OK") {
        return Response.error("YouTube báo không phát được: " + playability + (state.player.playabilityStatus.reason ? " - " + state.player.playabilityStatus.reason : ""));
    }
    try {
        markWatchHistoryFromState(state, false);
    } catch (e) {}
    var tracks = getPreferredTracks(state);
    if (!tracks.length) return Response.error("Không tìm thấy track phát trực tiếp");
    return Response.success(tracks);
}
