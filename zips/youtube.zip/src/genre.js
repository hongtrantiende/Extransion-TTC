load("shared.js");

function execute() {
    var items = [buildHistoryGenreItem()];
    var channels = fetchSubscribedChannels();
    for (var i = 0; i < channels.length; i++) items.push(channels[i]);
    return Response.success(items, null);
}
