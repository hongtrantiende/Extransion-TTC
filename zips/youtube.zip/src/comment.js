load("shared.js");

function execute(input, page) {
    var videoId = parseBookLink(input) || parseEpisodeLink(input) || getActiveVideoId(input);
    var result = fetchCommentPage(videoId, page || "1");
    if (result.next) return Response.success(result.comments, result.next);
    return Response.success(result.comments);
}
