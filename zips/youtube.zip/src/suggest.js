load("shared.js");

function execute(input, page) {
    var videoId = parseBookLink(input) || parseEpisodeLink(input) || getActiveVideoId(input);
    var result = fetchSuggestPage(videoId, page || "1");
    if (result.next) return Response.success(result.items, result.next);
    return Response.success(result.items);
}
