load("shared.js");

function execute(url) {
    var playlistId = extractPlaylistId(url);
    if (playlistId) return Response.success(buildPlaylistDetail(url));
    var videoId = parseBookLink(url) || extractVideoId(url);
    if (!videoId) return Response.error("Không nhận diện được video YouTube, vui lòng tải lại hoặc mở lại link.");
    var state = getVideoState(videoId);
    return Response.success({
        bookId: videoId,
        name: pickTitle(state),
        cover: pickThumbnail(state),
        host: YT_BASE,
        author: pickAuthor(state),
        description: pickDescription(state),
        detail: buildDetailLines(state),
        ongoing: false,
        type: "video",
        suggests: [{
            title: "Gợi ý tiếp theo",
            input: buildWatchUrl(videoId),
            script: "suggest.js"
        }],
        comments: buildDetailCommentTabs(state)
    });
}
