function execute(key, page) {
    page = page || "1";
    let fetchUrl = "https://m.qidian.com/so/" + encodeURIComponent(key) + ".html?pageNum=" + page;

    let response = fetch(fetchUrl, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36"
        }
    });

    if (!response.ok) return Response.error("Search failed");

    let doc = response.html();
    let data = [];

    doc.select(".y-list__item a").forEach(function(el) {
        let name = el.select("h2").text();
        let link = el.attr("href");
        
        let cover = el.select("img").attr("data-src") || el.select("img").attr("src");
        if (cover && cover.startsWith("//")) cover = "https:" + cover;

        let description = "";
        let descEl = el.select("p").first();
        if (descEl) {
            description = descEl.text().replace("简介：", "").trim();
        }

        let author = "";
        let kind = "";
        let subTitleEl = el.select("p").last();
        if (subTitleEl && subTitleEl !== descEl) {
            let parts = subTitleEl.text().split(/[·\s\•]+/);
            if (parts.length > 0) {
                author = parts[0].trim();
                kind = parts.slice(1).join(", ").trim();
            }
        }

        if (link && !link.startsWith("http")) {
            link = "https://m.qidian.com" + link;
        }

        let bookId = "";
        let chMatch = link ? link.match(/\/chapter\/(\d+)/) : null;
        let bkMatch = link ? link.match(/\/book\/(\d+)/) : null;
        if (chMatch) {
            bookId = chMatch[1];
        } else if (bkMatch) {
            bookId = bkMatch[1];
        }

        if (bookId) {
            link = "https://m.qidian.com/book/" + bookId;
        }

        if (name && link) {
            data.push({
                name: name,
                link: link,
                cover: cover || "",
                description: description || "",
                author: author || "",
                kind: kind || "",
                host: "https://m.qidian.com"
            });
        }
    });

    return Response.success(data);
}
