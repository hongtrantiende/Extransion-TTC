function execute(url, page) {
    page = page || "1";
    let data = [];

    // 1. Fetch static page first to populate native cookie jar
    let response = fetch(url, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36"
        }
    });

    if (!response.ok) return Response.error("Failed to load list");

    // 2. Read cookies from localCookie global object
    let csrfToken = "";
    let cookieStr = "";
    try {
        cookieStr = localCookie.getCookie("https://m.qidian.com") || localCookie.getCookie("https://qidian.com") || "";
    } catch(e) {}
    
    if (cookieStr) {
        let match = cookieStr.match(/_csrfToken=([^;]+)/);
        if (match) {
            csrfToken = match[1];
        }
    }

    let apiPath = "";
    if (url.includes("/hotsales/")) apiPath = "hotsaleslist";
    else if (url.includes("/yuepiao/")) apiPath = "yuepiaolist";
    else if (url.includes("/rec/")) apiPath = "reclist";
    else if (url.includes("/newbook/")) apiPath = "newbooklist";
    else if (url.includes("/readindex/")) apiPath = "readindexlist";
    else if (url.includes("/update/")) apiPath = "updatelist";
    else if (url.includes("/sign/")) apiPath = "signlist";
    else if (url.includes("/newauthor/")) apiPath = "newauthorlist";
    else if (url.includes("/newfans/")) apiPath = "newfanslist";

    if (apiPath && csrfToken) {
        let apiUrl = "https://m.qidian.com/majax/rank/" + apiPath + "?gender=male&pageNum=" + page + "&_csrfToken=" + csrfToken;
        let apiRes = fetch(apiUrl, {
            headers: {
                "User-Agent": "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36",
                "Cookie": cookieStr,
                "Referer": url
            }
        });

        if (apiRes.ok) {
            let json = apiRes.json();
            if (json && json.code === 0 && json.data && json.data.records) {
                json.data.records.forEach(function(item) {
                    let name = item.bName;
                    let bid = item.bid;
                    let link = "https://m.qidian.com/book/" + bid;
                    let cover = "https://bookcover.yuewen.com/qdbimg/349573/" + bid + "/180";
                    let author = item.bAuth || "";
                    let description = item.desc || "";
                    let kind = item.cat || "";
                    if (item.subCat) kind += ", " + item.subCat;
                    if (item.cnt) kind += ", " + item.cnt;

                    if (name && bid) {
                        data.push({
                            name: name,
                            link: link,
                            cover: cover,
                            description: description,
                            author: author,
                            kind: kind,
                            host: "https://m.qidian.com"
                        });
                    }
                });
            }
        }
    }

    let nextPage = null;
    if (data.length > 0) {
        nextPage = String(parseInt(page) + 1);
    }

    return Response.success(data, nextPage);
}
