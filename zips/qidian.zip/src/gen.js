function execute(url, page) {
    page = page || "1";
    let data = [];

    if (page === "1") {
        // For page 1, fetch and parse the static HTML page directly
        let response = fetch(url, {
            headers: {
                "User-Agent": "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36"
            }
        });

        if (!response.ok) return Response.error("Failed to load list");

        let doc = response.html();
        let items = doc.select(".y-list__item a");
        
        items.forEach(function(el) {
            let name = el.select("h2").text();
            let link = el.attr("href");
            
            let cover = el.select("img").attr("data-src") || el.select("img").attr("src");
            if (cover && cover.startsWith("//")) cover = "https:" + cover;

            let description = "";
            let descEl = el.select("p").first();
            if (descEl) {
                description = descEl.text().replace("简介：", "").trim();
            }

            let author = "";
            let kind = "";
            let subTitleEl = el.select("p").last();
            if (subTitleEl && subTitleEl !== descEl) {
                let parts = subTitleEl.text().split(/[·\s\•]+/);
                if (parts.length > 0) {
                    author = parts[0].trim();
                    kind = parts.slice(1).join(", ").trim();
                }
            }

            if (link && !link.startsWith("http")) {
                link = "https://m.qidian.com" + link;
            }

            let bookId = "";
            let chMatch = link ? link.match(/\/chapter\/(\d+)/) : null;
            let bkMatch = link ? link.match(/\/book\/(\d+)/) : null;
            if (chMatch) {
                bookId = chMatch[1];
            } else if (bkMatch) {
                bookId = bkMatch[1];
            }

            if (bookId) {
                link = "https://m.qidian.com/book/" + bookId;
            }

            if (name && link) {
                data.push({
                    name: name,
                    link: link,
                    cover: cover || "",
                    description: description || "",
                    author: author || "",
                    kind: kind || "",
                    host: "https://m.qidian.com"
                });
            }
        });
    } else {
        // For page > 1, fetch static page to get _csrfToken from Set-Cookie header
        let response = fetch(url, {
            headers: {
                "User-Agent": "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36"
            }
        });

        if (!response.ok) return Response.error("Failed to load list");

        let csrfToken = "";
        let cookieHeader = response.header("Set-Cookie");
        if (cookieHeader) {
            let match = cookieHeader.match(/_csrfToken=([^;]+)/);
            if (match) csrfToken = match[1];
        }
        if (!csrfToken) {
            let setCookies = response.headers("Set-Cookie");
            if (setCookies) {
                for (let i = 0; i < setCookies.size(); i++) {
                    let cookie = setCookies.get(i);
                    let match = cookie.match(/_csrfToken=([^;]+)/);
                    if (match) {
                        csrfToken = match[1];
                        break;
                    }
                }
            }
        }

        let apiPath = "";
        if (url.includes("/hotsales/")) apiPath = "hotsaleslist";
        else if (url.includes("/yuepiao/")) apiPath = "yuepiaolist";
        else if (url.includes("/rec/")) apiPath = "reclist";
        else if (url.includes("/newbook/")) apiPath = "newbooklist";
        else if (url.includes("/readindex/")) apiPath = "readindexlist";
        else if (url.includes("/update/")) apiPath = "updatelist";
        else if (url.includes("/sign/")) apiPath = "signlist";
        else if (url.includes("/newauthor/")) apiPath = "newauthorlist";
        else if (url.includes("/newfans/")) apiPath = "newfanslist";

        if (apiPath && csrfToken) {
            let apiUrl = "https://m.qidian.com/majax/rank/" + apiPath + "?gender=male&pageNum=" + page + "&_csrfToken=" + csrfToken;
            let apiRes = fetch(apiUrl, {
                headers: {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36",
                    "Cookie": "_csrfToken=" + csrfToken,
                    "Referer": url
                }
            });

            if (apiRes.ok) {
                let json = apiRes.json();
                if (json && json.code === 0 && json.data && json.data.records) {
                    json.data.records.forEach(function(item) {
                        let name = item.bName;
                        let bid = item.bid;
                        let link = "https://m.qidian.com/book/" + bid;
                        let cover = "https://bookcover.yuewen.com/qdbimg/349573/" + bid + "/180";
                        let author = item.bAuth || "";
                        let description = item.desc || "";
                        let kind = item.cat || "";
                        if (item.subCat) kind += ", " + item.subCat;
                        if (item.cnt) kind += ", " + item.cnt;

                        if (name && bid) {
                            data.push({
                                name: name,
                                link: link,
                                cover: cover,
                                description: description,
                                author: author,
                                kind: kind,
                                host: "https://m.qidian.com"
                            });
                        }
                    });
                }
            }
        }
    }

    let nextPage = null;
    if (data.length > 0) {
        nextPage = String(parseInt(page) + 1);
    }

    return Response.success(data, nextPage);
}
