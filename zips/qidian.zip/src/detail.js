function execute(url) {
    let response = fetch(url, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36"
        }
    });

    if (!response.ok) return Response.error("Failed to load details");

    let doc = response.html();

    let name = doc.select("meta[property$=title]").attr("content") || doc.select("meta[property=og:title]").attr("content") || doc.select(".detail__header-detail__title").text();
    let author = doc.select("meta[property$=author]").attr("content") || doc.select("meta[property=og:novel:author]").attr("content") || doc.select(".detail__header-detail__author a").text();
    let cover = doc.select("meta[property$=image]").attr("content") || doc.select("meta[property=og:image]").attr("content");
    let description = doc.select("meta[property$=description]").attr("content") || doc.select("meta[property=og:description]").attr("content");

    let kinds = [];
    doc.select("meta[property~=category|status|update_time]").forEach(function(el) {
        let content = el.attr("content");
        if (content) kinds.push(content);
    });

    if (cover && cover.startsWith("//")) cover = "https:" + cover;

    if (description) {
        description = description.replace(/最新章节.*$/, "").trim();
    }

    return Response.success({
        name: name || "Qidian Novel",
        author: author || "Unknown",
        cover: cover || "",
        description: description || "",
        kind: kinds.join(", "),
        detail: "作者: " + author,
        host: "https://m.qidian.com"
    });
}
