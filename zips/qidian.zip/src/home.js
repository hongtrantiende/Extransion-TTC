function execute() {
    return Response.success([
        { title: "月票榜", input: "https://m.qidian.com/rank/yuepiao/", script: "gen.js" },
        { title: "畅销榜", input: "https://m.qidian.com/rank/hotsales/", script: "gen.js" },
        { title: "推荐榜", input: "https://m.qidian.com/rank/rec/", script: "gen.js" },
        { title: "新书榜", input: "https://m.qidian.com/rank/newbook/", script: "gen.js" },
        { title: "阅读榜", input: "https://m.qidian.com/rank/readindex/", script: "gen.js" },
        { title: "更新榜", input: "https://m.qidian.com/rank/update/", script: "gen.js" }
    ]);
}
