function execute(url) {
    let tocUrl = url;
    if (tocUrl.endsWith("/")) tocUrl = tocUrl.slice(0, -1);
    if (!tocUrl.endsWith("/catalog")) {
        tocUrl += "/catalog";
    }

    let response = fetch(tocUrl, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36"
        }
    });

    if (!response.ok) return Response.error("Failed to load table of contents");

    let doc = response.html();
    let data = [];

    doc.select(".y-list__item a").forEach(function(el) {
        let name = el.select("h2, h3").text();
        if (!name) name = el.text();
        
        let link = el.attr("href");
        if (link) {
            if (link.startsWith("//")) {
                link = "https:" + link;
            } else if (!link.startsWith("http")) {
                link = "https://m.qidian.com" + link;
            }
        }

        if (name && link) {
            data.push({
                name: name.replace("在线阅读", "").trim(),
                url: link
            });
        }
    });

    return Response.success(data);
}
