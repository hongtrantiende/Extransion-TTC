function execute(url) {
    let response = fetch(url, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36"
        }
    });

    if (!response.ok) return Response.error("Failed to load chapter content");

    let doc = response.html();
    let paragraphs = [];

    doc.select(".content p").forEach(function(el) {
        let text = el.text().trim();
        if (text) {
            paragraphs.push(text);
        }
    });

    if (paragraphs.length === 0) {
        let metaDesc = doc.select("meta[name=description]").attr("content");
        if (metaDesc) {
            let cleanDesc = metaDesc.replace(/^.*?内容摘要:/, "").trim();
            if (cleanDesc) {
                paragraphs.push(cleanDesc);
            }
        }
    }

    return Response.success(paragraphs.join("\n\n"));
}
