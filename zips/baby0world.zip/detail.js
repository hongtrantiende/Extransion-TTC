function execute(url) {
    var response = fetch(url, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Referer": "https://baby0world.com/"
        }
    });
    
    if (!response.ok) {
        return Response.error("Lỗi kết nối");
    }
    
    var doc = Html.parse(response.text());
    var name = doc.select(".bookName").text().trim();
    if (!name) {
        name = doc.select(".bookText h1").text().trim();
    }
    
    var cover = doc.select(".bookImage img").first().attr("src");
    if (cover && cover.indexOf("//") === 0) {
        cover = "https:" + cover;
    }
    
    var authorText = doc.select(".bookAuthor").text().trim();
    if (!authorText) {
        authorText = doc.select(".author").text().trim();
    }
    var author = authorText.replace("作者：", "").replace("作者:", "").trim();
    
    var desc = doc.select("#bookDesc .bookDescText").text().trim();
    if (!desc) {
        desc = doc.select(".bookDesc").text().trim();
    }
    
    return Response.success({
        name: name,
        cover: cover,
        description: desc,
        author: author || "碎番茄故事匯",
        host: "https://baby0world.com",
        url: url
    });
}
