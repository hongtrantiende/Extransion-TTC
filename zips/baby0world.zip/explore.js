function execute(input, page) {
    var url = input;
    var pageInt = parseInt(page) || 1;
    url = url + (url.indexOf("?") > -1 ? "&" : "?") + "pi=" + pageInt + "&ps=20&isvip=-1";
    
    var response = fetch(url, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Referer": "https://baby0world.com/library"
        }
    });
    
    if (!response.ok) {
        return Response.error("Lỗi kết nối: " + response.status);
    }
    
    var text = response.text();
    var data = JSON.parse(text);
    var books = data.data || [];
    var list = [];
    
    for (var i = 0; i < books.length; i++) {
        var book = books[i];
        var cover = book.cover || "";
        if (cover && cover.indexOf("//") === 0) {
            cover = "https:" + cover;
        }
        list.push({
            name: book.name,
            link: "https://baby0world.com" + book.url,
            cover: cover,
            description: book.intro || book.sharetext || "",
            author: book.authorname || "碎番茄故事匯",
            host: "https://baby0world.com"
        });
    }
    
    return Response.success(list);
}
