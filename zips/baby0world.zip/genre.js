function execute() {
    return Response.success([
        { title: "Tất cả", input: "https://baby0world.com/api/booklist?sort=5", script: "explore.js" },
        { title: "Mới nhất", input: "https://baby0world.com/api/booklist?sort=0", script: "explore.js" },
        { title: "Xem nhiều", input: "https://baby0world.com/api/booklist?sort=1", script: "explore.js" }
    ]);
}
