function execute() {
    return Response.success([
        { title: "Tất cả", input: "https://baby0world.com/api/booklist?sort=5", script: "explore.js" },
        { title: "Mới nhất", input: "https://baby0world.com/api/booklist?sort=0", script: "explore.js" },
        { title: "Xem nhiều", input: "https://baby0world.com/api/booklist?sort=1", script: "explore.js" },
        { title: "Dài nhất", input: "https://baby0world.com/api/booklist?sort=2", script: "explore.js" },
        { title: "Cổ đại (Premium)", input: "https://baby0world.com/api/booklist?pcateid=3&cateid=22&sort=5", script: "explore.js" },
        { title: "Hiện đại (Premium)", input: "https://baby0world.com/api/booklist?pcateid=3&cateid=30&sort=5", script: "explore.js" },
        { title: "Huyền học (Premium)", input: "https://baby0world.com/api/booklist?pcateid=3&cateid=31&sort=5", script: "explore.js" },
        { title: "Xuyên không (Premium)", input: "https://baby0world.com/api/booklist?pcateid=3&cateid=26&sort=5", script: "explore.js" },
        { title: "Võ hiệp (Premium)", input: "https://baby0world.com/api/booklist?pcateid=3&cateid=29&sort=5", script: "explore.js" },
        { title: "Mạt thế (Premium)", input: "https://baby0world.com/api/booklist?pcateid=3&cateid=25&sort=5", script: "explore.js" },
        { title: "Dân quốc (Premium)", input: "https://baby0world.com/api/booklist?pcateid=3&cateid=27&sort=5", script: "explore.js" },
        { title: "Cổ đại (VIP)", input: "https://baby0world.com/api/booklist?pcateid=89&cateid=90&sort=5", script: "explore.js" },
        { title: "Hiện đại (VIP)", input: "https://baby0world.com/api/booklist?pcateid=89&cateid=91&sort=5", script: "explore.js" }
    ]);
}
