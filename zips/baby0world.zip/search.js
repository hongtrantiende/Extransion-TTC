function execute(keyword, page) {
    var pageInt = parseInt(page) || 1;
    var url = "https://baby0world.com/search?query=" + encodeURIComponent(keyword);
    if (pageInt > 1) {
        url = url + "&pi=" + pageInt;
    }
    
    var response = fetch(url, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Referer": "https://baby0world.com/"
        }
    });
    
    if (!response.ok) {
        return Response.error("Lỗi kết nối");
    }
    
    var doc = Html.parse(response.text());
    var items = doc.select(".bookItemInfo");
    var list = [];
    
    for (var i = 0; i < items.size(); i++) {
        var item = items.get(i);
        var a = item.select(".bookItemImg a").first();
        if (!a) continue;
        var href = a.attr("href");
        var cover = a.select("img").first().attr("src");
        if (cover && cover.indexOf("//") === 0) {
            cover = "https:" + cover;
        }
        
        var name = item.select(".bookItemDetail h4 a").text().trim();
        var authorText = item.select(".bookItemAuthor").text().trim();
        var author = authorText.replace("作者：", "").replace("作者:", "").trim();
        var desc = item.select(".bookItemDesc").text().trim();
        
        list.push({
            name: name,
            link: "https://baby0world.com" + href,
            cover: cover,
            description: desc,
            author: author || "碎番茄故事匯",
            host: "https://baby0world.com"
        });
    }
    
    return Response.success(list);
}
