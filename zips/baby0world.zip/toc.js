function execute(url) {
    var match = url.match(/\/book\/(\d+)/);
    if (!match) {
        return Response.error("URL không hợp lệ");
    }
    var bookId = match[1];
    
    var response = fetch("https://baby0world.com/api/bookchapterlist", {
        method: "POST",
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Referer": url,
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: "bookid=" + bookId
    });
    
    if (!response.ok) {
        return Response.error("Lỗi kết nối: " + response.status);
    }
    
    var data = JSON.parse(response.text());
    var chapters = data.data || [];
    var list = [];
    
    for (var i = 0; i < chapters.length; i++) {
        var ch = chapters[i];
        var name = ch.name || "";
        var chId = ch.id;
        list.push({
            name: name,
            url: "https://baby0world.com/book/chapter/" + chId
        });
    }
    
    return Response.success(list);
}
