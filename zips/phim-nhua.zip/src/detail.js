load('config.js');

function execute(url) {
    url = normalizeUrl(url);

    var res = fetch(url, { headers: { 'User-Agent': UserAgent.chrome() } });
    if (!res.ok) return Response.error('Cannot load: ' + res.status);

    var doc = res.html();

    // Name from meta og:title
    var name = '';
    var ogTitle = doc.select('meta[property=og\\:title]').first();
    if (ogTitle) {
        name = cleanText(ogTitle.attr('content') || '');
        name = name.replace(/\s*\|\s*Phim Nh.+$/, '').trim();
    }
    if (!name) {
        var h1 = doc.select('h1').first();
        if (h1) {
            name = cleanText(h1.text());
            name = name.replace(/^Xem phim\s+/i, '').trim();
        }
    }

    // Cover from og:image
    var cover = '';
    var ogImg = doc.select('meta[property=og\\:image]').first();
    if (ogImg) cover = absoluteUrl(ogImg.attr('content') || '');
    if (!cover) {
        var imgEl = doc.select('img[alt*=poster i]').first();
        if (!imgEl) imgEl = doc.select('.card__cover img').first();
        if (!imgEl) imgEl = doc.select('img[src*=uploads]').first();
        if (imgEl) cover = absoluteUrl(imgEl.attr('src') || '');
    }

    // Description from og:description or h2.video-description
    var description = '';
    var ogDesc = doc.select('meta[property=og\\:description]').first();
    if (ogDesc) description = cleanText(ogDesc.attr('content') || '');
    if (!description) {
        var descEl = doc.select('h2.video-description').first();
        if (descEl) description = cleanText(descEl.text());
    }

    // Parse <li> items for info
    var genres = [];
    var details = [];

    doc.select('li').forEach(function(li) {
        var span = li.select('span').first();
        if (!span) return;
        var label = cleanText(span.text());
        var full = cleanText(li.text());

        // Genre / The loai
        if (/the loai|th.lo.i/i.test(label)) {
            li.select('a').forEach(function(a) {
                var g = cleanText(a.text());
                if (g) genres.push(g);
            });
            if (genres.length > 0) details.push('The loai: ' + genres.join(', '));
        }
        // Director / Dao dien
        else if (/dao dien|director/i.test(label)) {
            var val = full.replace(label, '').replace(/^[:\s]+/, '');
            details.push('Dao dien: ' + val);
        }
        // Year / Nam
        else if (/nam|year/i.test(label)) {
            var val = full.replace(label, '').replace(/^[:\s]+/, '');
            details.push('Nam: ' + val);
        }
        // Subtitle / Phu de
        else if (/phu de|sub/i.test(label)) {
            var sub = cleanText(li.select('.text-success').text() || li.text());
            if (/co/i.test(sub)) details.push('Vietsub');
        }
        // Dubbing / Thuyet minh
        else if (/thuyet minh|dub/i.test(label)) {
            var dub = cleanText(li.select('.text-danger').text() || li.text());
            if (/co/i.test(dub)) details.push('Thuyet minh');
        }
    });

    // ongoing check
    var ongoing = doc.select('a[href*=phim-bo]').size() > 0;

    return Response.success({
        name: name,
        cover: cover,
        author: 'Phim Nhua',
        description: description,
        detail: details.join('<br>'),
        ongoing: ongoing,
        genres: genres,
        format: 'series',
        host: BASE_URL
    });
}