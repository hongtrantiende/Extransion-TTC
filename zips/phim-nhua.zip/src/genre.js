load('config.js');

function execute() {
    var theloai = [
        { name: "Hành động", url: BASE_URL + "/the-loai/action" },
        { name: "Tâm lý", url: BASE_URL + "/the-loai/drama" },
        { name: "Kinh dị", url: BASE_URL + "/the-loai/horror" },
        { name: "Lãng mạn", url: BASE_URL + "/the-loai/romance" },
        { name: "Phiêu lưu", url: BASE_URL + "/the-loai/adventure" },
        { name: "Kỳ ảo", url: BASE_URL + "/the-loai/fantasy" },
        { name: "Thần bí", url: BASE_URL + "/the-loai/mystery" },
        { name: "Giả tưởng", url: BASE_URL + "/the-loai/sci-fi" },
        { name: "Rùng rợn", url: BASE_URL + "/the-loai/thriller" },
        { name: "Chiến tranh", url: BASE_URL + "/the-loai/war" },
        { name: "Hoạt hình", url: BASE_URL + "/the-loai/animation" },
        { name: "Hài hước", url: BASE_URL + "/the-loai/comedy" },
        { name: "Hình sự", url: BASE_URL + "/the-loai/crime" },
        { name: "Phim lẻ", url: BASE_URL + "/the-loai/phim-le" },
        { name: "Phim bộ", url: BASE_URL + "/the-loai/phim-bo" },
    ];

    var quocgia = [
        { name: "Việt Nam", url: BASE_URL + "/quoc-gia/viet-nam" },
        { name: "Trung Quốc", url: BASE_URL + "/quoc-gia/trung-quoc" },
        { name: "Hàn Quốc", url: BASE_URL + "/quoc-gia/han-quoc" },
        { name: "Âu Mỹ", url: BASE_URL + "/quoc-gia/au-my" },
        { name: "Nhật Bản", url: BASE_URL + "/quoc-gia/nhat-ban" },
        { name: "Thái Lan", url: BASE_URL + "/quoc-gia/thai-lan" },
        { name: "Hồng Kông", url: BASE_URL + "/quoc-gia/hong-kong" },
        { name: "Đài Loan", url: BASE_URL + "/quoc-gia/dai-loan" },
        { name: "Ấn Độ", url: BASE_URL + "/quoc-gia/an-do" },
        { name: "Anh", url: BASE_URL + "/quoc-gia/anh" },
        { name: "Pháp", url: BASE_URL + "/quoc-gia/phap" },
        { name: "Đức", url: BASE_URL + "/quoc-gia/duc" },
    ];

    var result = [];

    for (var i = 0; i < theloai.length; i++) {
        result.push({
            title: "Thể loại: " + theloai[i].name,
            input: theloai[i].url,
            script: "gen.js"
        });
    }

    for (var i = 0; i < quocgia.length; i++) {
        result.push({
            title: "Quốc gia: " + quocgia[i].name,
            input: quocgia[i].url,
            script: "gen.js"
        });
    }

    return Response.success(result);
}