var BASE_URL = "https://phimnhua.online";
try { if (CONFIG_URL) BASE_URL = CONFIG_URL; } catch (e) {}

function normalizeUrl(url) {
    url = (url || "") + "";
    return url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

function absoluteUrl(url) {
    url = (url || "") + "";
    if (!url) return "";
    if (url.indexOf("//") === 0) return "https:" + url;
    if (url.indexOf("http") === 0) return url;
    return url.indexOf("/") === 0 ? BASE_URL + url : BASE_URL + "/" + url;
}

function cleanText(text) {
    return (text || "").replace(/\s+/g, " ").trim();
}