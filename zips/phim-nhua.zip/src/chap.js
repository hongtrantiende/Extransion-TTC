load('config.js');

function execute(url) {
    // url is m3u8 stream URL (from toc.js data-url)
    return Response.success([
        { title: 'Server 1', data: url }
    ]);
}