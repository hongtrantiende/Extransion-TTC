load('config.js');

function execute() {
    return Response.success([
        { title: "Phim mới cập nhật", input: BASE_URL + "/", script: "gen.js" },
        { title: "Phim bộ", input: BASE_URL + "/the-loai/phim-bo", script: "gen.js" },
        { title: "Phim lẻ", input: BASE_URL + "/the-loai/phim-le", script: "gen.js" },
        { title: "Thể loại: Hành động", input: BASE_URL + "/the-loai/action", script: "gen.js" },
        { title: "Thể loại: Tâm lý", input: BASE_URL + "/the-loai/drama", script: "gen.js" },
        { title: "Thể loại: Kinh dị", input: BASE_URL + "/the-loai/horror", script: "gen.js" },
        { title: "Thể loại: Hài hước", input: BASE_URL + "/the-loai/comedy", script: "gen.js" },
        { title: "Thể loại: Giả tưởng", input: BASE_URL + "/the-loai/sci-fi", script: "gen.js" },
        { title: "Thể loại: Hoạt hình", input: BASE_URL + "/the-loai/animation", script: "gen.js" },
        { title: "Quốc gia: Việt Nam", input: BASE_URL + "/quoc-gia/viet-nam", script: "gen.js" },
        { title: "Quốc gia: Trung Quốc", input: BASE_URL + "/quoc-gia/trung-quoc", script: "gen.js" },
        { title: "Quốc gia: Hàn Quốc", input: BASE_URL + "/quoc-gia/han-quoc", script: "gen.js" },
        { title: "Quốc gia: Âu Mỹ", input: BASE_URL + "/quoc-gia/au-my", script: "gen.js" },
        { title: "Quốc gia: Nhật Bản", input: BASE_URL + "/quoc-gia/nhat-ban", script: "gen.js" },
    ]);
}