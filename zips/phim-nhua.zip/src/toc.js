load('config.js');

function execute(url) {
    url = normalizeUrl(url);

    var res = fetch(url, { headers: { 'User-Agent': UserAgent.chrome() } });
    if (!res.ok) return Response.error('Cannot load: ' + res.status);

    var html = res.text();
    var result = [];

    // Try series episodes: buttons with data-url attribute
    var btnRegex = /<button[^>]*data-url="([^"]+)"[^>]*>([^<]+)<\/button>/gi;
    var m;
    var seen = {};
    while ((m = btnRegex.exec(html)) !== null) {
        var epUrl = m[1];
        var epName = cleanText(m[2]);
        if (epUrl && epName && !seen[epUrl]) {
            seen[epUrl] = true;
            result.push({
                name: epName,
                url: epUrl,
                host: BASE_URL
            });
        }
    }

    // Fallback: single movie with var source = '...m3u8'
    if (result.length === 0) {
        var srcMatch = html.match(/var\s+source\s*=\s*'([^']+)'/) ||
                       html.match(/"src"\s*:\s*"([^"]+\.m3u8[^"]*)"/i) || 
                       html.match(/iosSrc\s*=\s*"([^"]+\.m3u8[^"]*)"/i) || 
                       html.match(/(https?:\\?\/\\?\/[^"'\s]+\.m3u8[^"'\s]*)/i);
        if (srcMatch && srcMatch[1]) {
            result.push({
                name: 'Full',
                url: srcMatch[1].replace(/\\/g, ''),
                host: BASE_URL
            });
        }
    }

    if (result.length === 0) return Response.error('No episodes found.');
    return Response.success(result);
}