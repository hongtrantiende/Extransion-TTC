function execute(url) {
    // 1. Parse type parameter
    var typeMatch = url.match(/[?&]type=([^&]+)/);
    var type = typeMatch ? typeMatch[1] : "pro";
    
    var cleanUrl = url.split("?")[0];
    
    // 2. Fetch the episode page
    var response = fetch(cleanUrl, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }
    });
    
    if (!response.ok) {
        return Response.error("Lỗi kết nối trang phim");
    }
    
    var html = response.text();
    var doc = Html.parse(html);
    
    // 3. Extract player data-attributes
    var a = doc.select("a[href='" + cleanUrl + "']").first();
    if (!a) {
        a = doc.select(".halim-episode.active a").first() || doc.select("ul.halim-list-eps a").first();
    }
    
    var postId, ep, sv;
    if (a) {
        postId = a.attr("data-post-id");
        ep = a.attr("data-ep");
        sv = a.attr("data-sv") || "1";
    } else {
        // Fallback to regex
        var idMatch = html.match(/data-post-id="(\d+)"/);
        postId = idMatch ? idMatch[1] : null;
        
        var epMatch = html.match(/data-ep="([^"]+)"/);
        ep = epMatch ? epMatch[1] : null;
        
        var svMatch = html.match(/data-sv="(\d+)"/);
        sv = svMatch ? svMatch[1] : "1";
    }
    
    if (!postId || !ep) {
        return Response.error("Không tìm thấy thông tin tập phim");
    }
    
    // 4. Fetch player html via WordPress player.php Ajax
    var playerUrl = "https://hhtq.ee/player/player.php?action=dox_ajax_player&post_id=" + postId + "&chapter_st=" + ep + "&type=" + type + "&sv=" + sv;
    var playerRes = fetch(playerUrl, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Referer": cleanUrl,
            "X-Requested-With": "XMLHttpRequest"
        }
    });
    
    if (!playerRes.ok) {
        return Response.error("Lỗi kết nối máy chủ phát");
    }
    
    var playerHtml = playerRes.text();
    
    // 5. Extract iframe embed src
    var iframeMatch = playerHtml.match(/<iframe[^>]*src="([^"]+)"/i);
    if (!iframeMatch) {
        iframeMatch = playerHtml.match(/src="([^"]+)"/i);
    }
    
    if (!iframeMatch) {
        return Response.error("Không tìm thấy khung phát video");
    }
    
    var iframeUrl = iframeMatch[1];
    
    // Replace html entity quotes if any
    iframeUrl = iframeUrl.replace(/&amp;/g, "&");
    
    return Response.success(iframeUrl);
}
