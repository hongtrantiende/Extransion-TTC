function execute(url) {
    var response = fetch(url, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }
    });
    
    if (!response.ok) {
        return Response.error("Lỗi kết nối");
    }
    
    var html = response.text();
    var doc = Html.parse(html);
    
    var name = doc.select(".entry-title").first().text() || doc.select("h1").first().text();
    var cover = doc.select(".wp-post-image").first().attr("src") || doc.select("meta[property='og:image']").attr("content");
    
    var descEl = doc.select(".entry-content");
    var desc = descEl.text() || doc.select(".video-item").text() || doc.select("p").first().text();
    
    return Response.success({
        name: name.trim(),
        cover: cover,
        description: desc.trim(),
        author: "HHTQ"
    });
}
