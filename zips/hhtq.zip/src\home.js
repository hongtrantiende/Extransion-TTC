function execute() {
    var kinds = [
        {
            title: "Mới Cập Nhật",
            name: "Mới Cập Nhật",
            input: "https://hhtq.ee/moi-cap-nhat/page/"
        },
        {
            title: "Tu Tiên",
            name: "Tu Tiên",
            input: "https://hhtq.ee/tu-tien/page/"
        },
        {
            title: "Hiện Đại",
            name: "Hiện Đại",
            input: "https://hhtq.ee/hien-dai/page/"
        },
        {
            title: "Kiếm Hiệp",
            name: "Kiếm Hiệp",
            input: "https://hhtq.ee/kiem-hiep/page/"
        },
        {
            title: "Cổ Trang",
            name: "Cổ Trang",
            input: "https://hhtq.ee/co-trang/page/"
        },
        {
            title: "Đô Thị",
            name: "Đô Thị",
            input: "https://hhtq.ee/do-thi/page/"
        },
        {
            title: "Trùng Sinh",
            name: "Trùng Sinh",
            input: "https://hhtq.ee/trung-sinh/page/"
        },
        {
            title: "Hài Hước",
            name: "Hài Hước",
            input: "https://hhtq.ee/hai-huoc/page/"
        },
        {
            title: "Tiên Hiệp",
            name: "Tiên Hiệp",
            input: "https://hhtq.ee/tien-hiep/page/"
        },
        {
            title: "Hoàn Thành",
            name: "Hoàn Thành",
            input: "https://hhtq.ee/hoan-thanh/page/"
        }
    ];
    return Response.success(kinds);
}
