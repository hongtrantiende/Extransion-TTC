function execute(url) {
    var response = fetch(url, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }
    });
    
    if (!response.ok) {
        return Response.error("Lỗi kết nối");
    }
    
    var html = response.text();
    var doc = Html.parse(html);
    var epLinks = doc.select("ul.halim-list-eps a");
    var list = [];
    
    var servers = [
        { id: "vip4k", name: "VIP 4K" },
        { id: "pro", name: "Pro" },
        { id: "vip4ktm", name: "Thuyết Minh VIP 4K" },
        { id: "pro_tm", name: "Thuyết Minh Pro" },
        { id: "tiktik", name: "Dự phòng 1" },
        { id: "tiktm", name: "TM Dự phòng 1" }
    ];
    
    for (var i = 0; i < epLinks.size(); i++) {
        var a = epLinks.get(i);
        var epTitle = a.text().trim();
        var epUrl = a.attr("href");
        
        for (var j = 0; j < servers.length; j++) {
            var sv = servers[j];
            list.push({
                name: epTitle + " [" + sv.name + "]",
                url: epUrl + "?type=" + sv.id
            });
        }
    }
    
    return Response.success(list);
}
