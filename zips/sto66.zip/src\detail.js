load('config.js');

function execute(url) {
    let response = fetch(url, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36",
            "Referer": BASE_URL + "/"
        }
    });

    if (response.ok) {
        let doc = response.html();
        
        let name = doc.select(".booktitle").text().trim();
        let author = doc.select(".booktag a.red").first().text().replace("作者：", "").trim();
        
        // Sửa selector ảnh bìa thành img.thumbnail
        let cover = doc.select("img.thumbnail").first().attr("src");
        if (cover && !cover.startsWith("http")) {
            cover = BASE_URL + cover;
        }

        let intro = doc.select(".bookintro").text().trim();
        
        let genres = [];
        doc.select(".booktag a.blue").forEach(e => {
            genres.push({
                title: e.text().trim(),
                input: e.attr("href"),
                script: "gen.js"
            });
        });

        // Sửa selector link mục lục thông minh
        let tocUrl = url; // Mặc định là trang chi tiết truyện
        let allLinks = doc.select("#allchapter a");
        for (let i = 0; i < allLinks.size(); i++) {
            let href = allLinks.get(i).attr("href");
            let text = allLinks.get(i).text();
            // Nếu link chứa "查看全部章节" hoặc có dạng /chapter/xxx.html (không chứa slash thứ hai sau chapter/)
            if (text.indexOf("全部") >= 0 || (href.indexOf("/chapter/") >= 0 && href.split("/").length === 3)) {
                tocUrl = href;
                break;
            }
        }
        if (tocUrl && !tocUrl.startsWith("http")) {
            tocUrl = BASE_URL + tocUrl;
        }

        return Response.success({
            name: name,
            cover: cover,
            author: author,
            description: intro,
            detail: "Tác giả: " + author,
            ongoing: doc.html().indexOf("连载") > 0,
            genres: genres,
            host: BASE_URL,
            tocUrl: tocUrl
        });
    }
    return null;
}
