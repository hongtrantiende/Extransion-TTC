load('config.js');

function execute(url) {
    let response = fetch(url, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36",
            "Referer": BASE_URL + "/"
        }
    });

    if (response.ok) {
        let doc = response.html();
        
        doc.select("script").remove();
        doc.select("style").remove();
        doc.select("iframe").remove();
        
        let contentHtml = doc.select("#content").html();
        
        let text = contentHtml
            .replace(/<br\s*\/?>/gi, "\n")
            .replace(/<p[^>]*>/gi, "")
            .replace(/<\/p>/gi, "\n")
            .replace(/<[^>]+>/g, "")
            .replace(/&nbsp;/g, " ")
            .replace(/&amp;/g, "&")
            .replace(/&lt;/g, "<")
            .replace(/&gt;/g, ">")
            .trim();

        return Response.success(text);
    }
    return null;
}
