load('config.js');

function execute(url) {
    let response = fetch(url, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36",
            "Referer": BASE_URL + "/"
        }
    });

    if (response.ok) {
        let doc = response.html();
        
        let name = doc.select(".booktitle").text().trim();
        let author = doc.select(".booktag a.red").first().text().replace("作者：", "").trim();
        let cover = doc.select(".bookcover img").first().attr("src");
        if (cover && !cover.startsWith("http")) {
            cover = BASE_URL + cover;
        }

        let intro = doc.select(".bookintro").text().trim();
        
        // Lấy danh sách thể loại
        let genres = [];
        doc.select(".booktag a.blue").forEach(e => {
            genres.push({
                title: e.text().trim(),
                input: e.attr("href"),
                script: "gen.js"
            });
        });

        // Link mục lục
        let tocUrl = doc.select("#allchapter a:contains(查看全部章节)").attr("href");
        if (tocUrl) {
            if (!tocUrl.startsWith("http")) {
                tocUrl = BASE_URL + tocUrl;
            }
        } else {
            tocUrl = url; // toc chính là trang detail
        }

        return Response.success({
            name: name,
            cover: cover,
            author: author,
            description: intro,
            detail: "Tác giả: " + author,
            ongoing: doc.html().indexOf("连载") > 0,
            genres: genres,
            host: BASE_URL,
            tocUrl: tocUrl
        });
    }
    return null;
}
