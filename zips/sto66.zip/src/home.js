load('config.js');
function execute() {
    return Response.success([
        {title: "思兔书库", input: BASE_URL + "/library.html", script: "gen.js"}
    ]);
}
