load('config.js');

function execute(key, page) {
    if (!page) page = '1';
    
    let url = BASE_URL + "/search/" + encodeURIComponent(key);
    if (parseInt(page) > 1) {
        url += "/" + page;
    }
    url += ".html";

    let response = fetch(url, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36",
            "Referer": BASE_URL + "/"
        }
    });

    if (response.ok) {
        let doc = response.html();
        let novelList = [];
        
        doc.select(".bookbox").forEach(e => {
            let nameEl = e.select(".bookname a").first();
            let name = nameEl.text().trim();
            let link = nameEl.attr("href");
            
            let author = e.select(".author").first().text().replace("作者：", "").trim();
            
            // Sửa selector ảnh bìa thành thẻ img đầu tiên trong bookbox
            let cover = e.select("img").first().attr("src");
            if (cover && !cover.startsWith("http")) {
                cover = BASE_URL + cover;
            }
            
            let description = e.select(".update").text().replace("简介：", "").trim();

            novelList.push({
                name: name,
                link: link,
                description: author + (description ? " | " + description : ""),
                cover: cover,
                host: BASE_URL
            });
        });

        let next = "";
        let activePage = doc.select(".pagination li.active, .pages li.active").text();
        if (activePage) {
            let nextEl = doc.select(".pagination li.active + li a, .pages li.active + li a").first();
            if (nextEl.length > 0) {
                next = (parseInt(page) + 1).toString();
            }
        }

        return Response.success(novelList, next);
    }
    return Response.success([]);
}
