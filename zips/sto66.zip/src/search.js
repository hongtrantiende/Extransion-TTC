load('config.js');

function execute(key, page) {
    if (!page) page = '1';
    
    // Tạo url tìm kiếm: https://www.sto66.com/search/{key}/{page}.html (nếu page > 1)
    let url = BASE_URL + "/search/" + encodeURIComponent(key);
    if (parseInt(page) > 1) {
        url += "/" + page;
    }
    url += ".html";

    let response = fetch(url, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36",
            "Referer": BASE_URL + "/"
        }
    });

    if (response.ok) {
        let doc = response.html();
        let novelList = [];
        
        // Legado bookList: //*[contains(@class, 'bookbox')]
        doc.select(".bookbox").forEach(e => {
            let nameEl = e.select(".bookname a").first();
            let name = nameEl.text().trim();
            let link = nameEl.attr("href");
            
            // Lấy tác giả
            let author = e.select(".author").first().text().replace("作者：", "").trim();
            
            // Lấy ảnh bìa
            let cover = e.select(".bookcover img").first().attr("src");
            if (cover && !cover.startsWith("http")) {
                cover = BASE_URL + cover;
            }
            
            // Lấy giới thiệu ngắn
            let description = e.select(".update").text().replace("简介：", "").trim();

            novelList.push({
                name: name,
                link: link,
                description: author + (description ? " | " + description : ""),
                cover: cover,
                host: BASE_URL
            });
        });

        // Xác định trang tiếp theo
        let next = "";
        let activePage = doc.select(".pagination li.active, .pages li.active").text();
        if (activePage) {
            let nextEl = doc.select(".pagination li.active + li a, .pages li.active + li a").first();
            if (nextEl.length > 0) {
                next = (parseInt(page) + 1).toString();
            }
        }

        return Response.success(novelList, next);
    }
    return Response.success([]);
}
