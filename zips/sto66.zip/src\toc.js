load('config.js');

function execute(url) {
    let response = fetch(url, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36",
            "Referer": BASE_URL + "/"
        }
    });

    if (response.ok) {
        let doc = response.html();
        let list = [];
        
        doc.select("#allchapter dd a").forEach(e => {
            let href = e.attr("href");
            let name = e.text().trim();
            // Bỏ qua link xem tất cả chương
            if (name.indexOf("全部") >= 0 || (href.indexOf("/chapter/") >= 0 && href.split("/").length <= 3)) {
                return;
            }
            list.push({
                name: name,
                url: href,
                host: BASE_URL
            });
        });

        return Response.success(list);
    }
    return null;
}
