load('config.js');

function execute(url) {
    let tocUrl = url.replace("/book/", "/chapter/");
    let response = fetch(tocUrl, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36",
            "Referer": BASE_URL + "/"
        }
    });

    if (response.ok) {
        let doc = response.html();
        let list = [];
        
        doc.select("#allchapter dd a").forEach(e => {
            list.push({
                name: e.text().trim(),
                url: e.attr("href"),
                host: BASE_URL
            });
        });

        return Response.success(list);
    }
    return null;
}
