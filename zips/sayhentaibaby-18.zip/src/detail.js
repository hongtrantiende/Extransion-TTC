load("config.js");

function execute(url) {
    var detailUrl = url.indexOf("http") === 0 ? url : resolveUrl(url);
    var doc = null;
    var res = fetchRetry(detailUrl);
    if (res && res.ok) {
        doc = res.html();
    }
    if (!doc) {
        var browser = Engine.newBrowser();
        try {
            doc = browser.launch(detailUrl, 12000);
        } catch (e) {
            doc = null;
        }
        try { browser.close(); } catch (e2) {}
    }
    if (!doc) return Response.error("Khong doc duoc noi dung");

    // Title
    var titleEl = selFirst(doc, "h1.entry-title, h1, .entry-title, .post-title h1");
    var name = "";
    if (titleEl) name = titleEl.text().trim();
    if (!name) {
        var titleMeta = selFirst(doc, "meta[property='og:title']");
        name = titleMeta ? (titleMeta.attr("content") || "").trim() : "";
    }

    // Cover
    var coverMeta = selFirst(doc, "meta[property='og:image']");
    var cover = coverMeta ? coverMeta.attr("content") : "";
    if (!cover) {
        var coverImg = selFirst(doc, "img[data-src]");
        cover = coverImg ? (coverImg.attr("data-src") || "") : "";
        if (cover && cover.indexOf("http") !== 0) cover = resolveUrl(cover);
    }

    // Author
    var authorEl = selFirst(doc, "a[rel='author'], .author-content, .author a, .thong-tin a[href*='author']");
    var author = authorEl ? authorEl.text().trim() : "";
    if (!author) {
        var authorMeta = selFirst(doc, "meta[property='article:author'], meta[name='author']");
        author = authorMeta ? (authorMeta.attr("content") || "").trim() : "";
    }
    if (!author) author = "SayHentaiBaby";

    // Genres - a[rel='category tag'] trong div.thong-tin
    var genreEls = doc.select("div.thong-tin a[rel='category tag']");
    var genres = [];
    var seenG = {};
    for (var i = 0; i < genreEls.size(); i++) {
        var gEl = genreEls.get(i);
        var g = gEl.text().trim();
        var gHref = gEl.attr("href") || "";
        if (g && !seenG[g]) {
            var gUrl = gHref.indexOf("http") === 0 ? gHref : resolveUrl(gHref);
            genres.push({ title: g, input: gUrl + "?order_by=update_time&sort=desc", script: "genrecontent.js" });
            seenG[g] = true;
        }
    }

    // Status - span sau span có text 'Tr'
    var status = "";
    var thongTin = selFirst(doc, "div.thong-tin");
    if (thongTin) {
        var spans = thongTin.select("span");
        for (var j = 0; j < spans.size(); j++) {
            var spanText = spans.get(j).text();
            if (spanText.indexOf("Tr\u1ea1ng Th\u00e1i") >= 0) {
                // span tiếp theo chứa giá trị
                if (j + 1 < spans.size()) {
                    status = spans.get(j + 1).text().trim();
                }
                break;
            }
        }
    }

    // Description - p trong article.item-content
    var descEl = selFirst(doc, "article.item-content p, div.item-content p");
    var description = descEl ? descEl.text().trim() : "";

    return Response.success({
        name: name,
        cover: cover,
        host: HOST,
        author: author,
        description: description,
        detail: status,
        ongoing: status.indexOf("ho\u00e0n") < 0,
        genres: genres,
        suggests: [],
        comments: []
    });
}
