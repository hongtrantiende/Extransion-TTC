load('config.js');

function execute(url) {
    var bookId = extractBookId(url);
    if (!bookId) return Response.error('Không tìm thấy Book ID');

    var rawBookId = bookId;
    if (/[a-zA-Z]/.test(bookId) && bookId.length > 10) {
        try {
            rawBookId = Base64.decode(bookId);
        } catch(e) {}
    }

    var apiUrl = 'https://fanqienovel.com/api/reader/directory/detail?bookId=' + rawBookId;
    var response = fetchWithUA(apiUrl);
    
    if (response.ok) {
        var json = SafeJson(response);
        var chapters = [];
        
        if (json && json.data && json.data.chapterListWithVolume) {
            var volumes = json.data.chapterListWithVolume;
            volumes.forEach(function(volume) {
                if (Array.isArray(volume)) {
                    volume.forEach(function(item) {
                        var itemId = item.itemId || item.item_id;
                        if (itemId) {
                            chapters.push({
                                name: decodeText(item.title || item.name || ""),
                                url: BASE_URL + "/content?item_id=" + itemId + "&book_id=" + bookId + "&source=番茄&tab=小说",
                                host: BASE_URL
                            });
                        }
                    });
                }
            });
        }

        if (chapters.length === 0) {
            return Response.error("Mục lục trống hoặc không thể phân tích.");
        }

        return Response.success(chapters);
    }

    return Response.error("Không thể tải mục lục (HTTP " + response.status + ")");
}
