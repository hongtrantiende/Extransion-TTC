load('config.js');

function execute(url) {
    var itemIdMatch = url.match(/item_id=([^&]+)/);
    var bookIdMatch = url.match(/book_id=([^&]+)/);

    var itemId = itemIdMatch ? itemIdMatch[1] : null;
    var bookId = bookIdMatch ? bookIdMatch[1] : null;

    if (!itemId) {
        // Fallback for direct original links if provided
        var m = url.match(/(\d+)/);
        itemId = m ? m[1] : null;
    }

    if (!itemId) {
        return Response.error("Không tìm thấy ID chương trong URL: " + url);
    }

    var SERVERS = [
        "https://v4.czyl.cf",
        "https://v5.czyl.cf",
        "https://v2.czyl.cf",
        "https://api.langge.cf"
    ];

    var startIdx = 0;
    try {
        var savedIdx = localStorage.getItem("dahuilang_server_idx");
        if (savedIdx !== null) {
            startIdx = parseInt(savedIdx, 10);
        }
    } catch (err) {}
    if (isNaN(startIdx) || startIdx < 0 || startIdx >= SERVERS.length) {
        startIdx = 0;
    }

    var body = {
        item_id: itemId,
        book_id: bookId || "",
        source: "番茄",
        tab: "小说",
        version: '5.3.2',
        html: "",
        variable: JSON.stringify({ custom: "" })
    };

    var lastErr = "";
    var qtCookie = getQtCookie();

    for (var attempt = 0; attempt < SERVERS.length; attempt++) {
        var currentIdx = (startIdx + attempt) % SERVERS.length;
        var baseServer = SERVERS[currentIdx];

        try {
            var fakeIp = (Math.floor(Math.random() * 254) + 1) + "." +
                         Math.floor(Math.random() * 255) + "." +
                         Math.floor(Math.random() * 255) + "." +
                         Math.floor(Math.random() * 255);

            var headers = {
                "Content-Type": "application/json",
                "User-Agent": MOBILE_UA,
                "X-Forwarded-For": fakeIp,
                "X-Real-IP": fakeIp,
                "Client-IP": fakeIp
            };
            if (qtCookie) {
                headers["cookie"] = qtCookie;
            }

            var response = fetch(baseServer + "/content?review=1", {
                method: "POST",
                headers: headers,
                body: JSON.stringify(body)
            });

            if (response.ok) {
                var json = SafeJson(response);
                var content = "";

                if (json) {
                    if (json.data && (json.data.content || json.data.text)) {
                        content = json.data.content || json.data.text;
                    } else if (json.content || json.text) {
                        content = json.content || json.text;
                    }
                }

                if (content) {
                    // Kiểm tra xem có bị giới hạn hay không
                    if (content.indexOf('书源版本过低') !== -1
                        || content.indexOf('点击登录') !== -1
                        || content.indexOf('免登录访问次数已达上限') !== -1
                        || content.indexOf('登录后刷新') !== -1) {
                        
                        lastErr = "Server " + baseServer + " bị giới hạn lượt đọc.";
                        continue;
                    }

                    // Thành công! Lưu index server hoạt động
                    try {
                        localStorage.setItem("dahuilang_server_idx", currentIdx);
                    } catch (err) {}

                    return Response.success(decodeText(content));
                }
            }
            lastErr = "Lỗi HTTP " + response.status + " từ server " + baseServer;
        } catch (e) {
            lastErr = "Lỗi kết nối server " + baseServer + ": " + e.message;
        }
    }

    // Nếu tất cả server đều bị giới hạn, hiển thị hướng dẫn đăng nhập
    var guideText = "⚠️ BẠN ĐÃ ĐỌC HẾT CÁC LƯỢT MIỄN PHÍ HÔM NAY (trên cả 4 server Sói Xám).\n\n"
        + "1. Mở TRÌNH DUYỆT ngay trong app vBook.\n"
        + "2. Truy cập địa chỉ: https://v2.czyl.cf/login\n"
        + "3. ĐĂNG NHẬP tài khoản SÓI XÁM (hoặc đổi mạng/VPN/4G để reset IP).\n"
        + "4. Quay lại app và LÀM MỚI CHƯƠNG để đọc tiếp.";
    return Response.success(guideText);
}

