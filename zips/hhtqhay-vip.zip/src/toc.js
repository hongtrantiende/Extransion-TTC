load('config.js');

function execute(input) {
    let url = input.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    let response = fetch(url);
    
    if (response.ok) {
        let doc = response.html();
        let episodeList = [];
        let servers = doc.select(".halim-server");
        servers.forEach(server=> {
            if (servers.length > 1) {
                episodeList.push({
                    name: server.select(".halim-server-name").text().trim(),
                    type: "section"
                });
            }

            let episodes = server.select(".halim-list-eps a");
            episodes.forEach(episode => {
                let name = episode.text().trim();
                let link = episode.attr("href");
                episodeList.push({
                    name: "Tập " + name,
                    url: link,
                    host: BASE_URL
                });
            });
        });

        return Response.success(episodeList);
    }
    return null;
}
