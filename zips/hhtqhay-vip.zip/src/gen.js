load('config.js');

function execute(input, page) {
    if (!page) page = '1';
    let url = input.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL)
    if (url.endsWith("/")) {
        url = url.slice(0, -1);
    }
    url += "/page/" + page + "/";
    let response = fetch(url);
    
    if (response.ok) {
        let doc = response.html();
        let videoList = [];
        
        let videos = doc.select(".halim-item");
        videos.forEach(video => {
            let name = video.select("h2").text().trim();
            let link = video.select("a").first().attr("href");
            let cover = video.select("img").attr("data-src").trim() || video.select("img").attr("src").trim();
            let tag = video.select(".episode").text().trim();
            videoList.push({
                name: name,
                link: link,
                cover: cover,
                tag: tag,
                host: BASE_URL
            });
        });
        
        let next = null;
        let nextBtn = doc.select(".rotate-right");
        if (nextBtn.size() > 0) {
            next = (parseInt(page) + 1).toString();
        }

        return Response.success(videoList, next);
    }
    
    return null;
}