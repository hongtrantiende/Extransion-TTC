load('config.js');

function execute() {
    return Response.success([
        { title: "Mới cập nhật", input: BASE_URL + "/moi-cap-nhat", script: "gen.js" },
        { title: "Đang chiếu", input: BASE_URL + "/dang-chieu", script: "gen.js" },
        { title: "Hoàn thành", input: BASE_URL + "/hoan-thanh", script: "gen.js" },
        { title: "Xem nhiều", input: BASE_URL + "/xem-nhieu", script: "gen.js" }
    ]);
}
