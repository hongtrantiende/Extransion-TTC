const BASE_URL = "https://hhtqhay.vip";

try {
    if (typeof config_url !== "undefined") {
        BASE_URL = config_url;
    }
} catch (error) {}