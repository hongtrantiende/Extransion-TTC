load('config.js');

function execute(input) {
    let url = input.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    let response = fetch(url);
    
    if (response.ok) {
        let doc = response.html();
        let name = doc.select("h1").text().trim();
        let cover = doc.select("img.movie-thumb").attr("src");
        // let author = "HHTQHAY.VIP";
        let description = doc.select(".item-content").html();
        let ongoing = doc.select(".more-info span").first().text().includes("?");
        let format = "series";

        // let detail = [];
        // detail = detail.join("<br>");
        
        let genres = [];
        doc.select(".more-info a").forEach(genre => {
            genres.push({
                title: genre.text(),
                input: genre.attr("href"),
                script: "gen.js"
            });
        });

        return Response.success({
            name: name,
            cover: cover,
            // author: author,
            ongoing: ongoing,
            // detail: detail,
            description: description,
            genres: genres,
            format: format,
            host: BASE_URL
        });
    }

    return null;
}
