load('config.js');

function execute() {
    return Response.success([
        { title: "Hoạt hình Trung Quốc", input: BASE_URL + "/hoat-hinh-trung-quoc", script: "gen.js" },
        { title: "Hoạt hình 3D", input: BASE_URL + "/hhtq-3d", script: "gen.js" },
        { title: "Hoạt hình 2D", input: BASE_URL + "/hhtq-2d", script: "gen.js" },
    ]);
}
