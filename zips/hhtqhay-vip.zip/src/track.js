load('config.js');

function execute(input) {
    if (input.includes(".m3u8") || input.includes(".mp4")) {
        return Response.success({
            data: input,
            type: "native",
            headers: {
                "User-Agent": UserAgent.chrome(),
                "Origin": BASE_URL,
            },
            timeSkip: [],
            host: BASE_URL
        });
    }
    else {
        return Response.success({
            data: input,
            type: "auto",
            headers: {},
            timeSkip: [],
            host: BASE_URL
        });
    }
}
