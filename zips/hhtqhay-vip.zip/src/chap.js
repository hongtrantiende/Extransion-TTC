load('config.js');

function execute(input) {
    let url = input.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    
    let response = fetch(url);
    if (response.ok) {
        let text = response.text();
        let tracks = [];

        let action = "halim_ajax_player";
        let nonce = text.match(/ajax_player.*?nonce":"([^"]+)"/)[1];
        let episode= text.match(/episode:\s*(\d+)/)[1];
        let server= text.match(/server:\s*(\d+)/)[1];
        let postId = text.match(/post_id:\s*(\d+)/)[1];

        let apiUrl = BASE_URL + "/wp-admin/admin-ajax.php";
        let playerResponse = fetch(apiUrl, {
            method: "POST",
            headers: {
                "User-Agent": UserAgent.chrome(),
                "Origin": BASE_URL,
                "Content-Type": "application/x-www-form-urlencoded",
                "X-Requested-With": "XMLHttpRequest",
            },
            body: "action=" + action + "&nonce=" + nonce + "&episode=" + episode + "&server=" + server + "&postid=" + postId,
        });

        if (playerResponse.ok) {
            let playerText = playerResponse.text();

            let sourceMatch = playerText.match(/sources:\s*\[.*?"file"\s*:\s*"([^"]+)".*?"label"\s*:\s*"([^"]+)"/);
            let videoUrl = sourceMatch[1] + "";
            let label = sourceMatch[2] + "";

            let testUrl = videoUrl.replace(/\\\//g, "/");
            let testResponse = fetch(testUrl, { 
                method: "GET",
                headers: { "Range": "bytes=0-1" }
            });
            if (!testResponse.ok) {
                action = "halim_play_listsv";
                console.log("fallback to halim_play_listsv");
                let fallbackResponse = fetch(apiUrl, {
                    method: "POST",
                    headers: {
                        "User-Agent": UserAgent.chrome(),
                        "Origin": BASE_URL,
                        "Content-Type": "application/x-www-form-urlencoded",
                        "X-Requested-With": "XMLHttpRequest",
                    },
                    body: "action=" + action + "&nonce=" + nonce + "&episode=" + episode + "&server=" + server + "&postid=" + postId + "&ep_link=1",
                });

                if (fallbackResponse.ok) {
                    let fallbackText = fallbackResponse.text();
                    let fallbackMatch = fallbackText.match(/sources:\s*\[.*?"file"\s*:\s*"([^"]+)".*?"label"\s*:\s*"([^"]+)"/);
                    if (fallbackMatch) {
                        videoUrl = fallbackMatch[1] + "";
                        label = fallbackMatch[2] + "";
                    }
                }
            }

            if (videoUrl) {
                tracks.push({
                    title: label,
                    data: videoUrl.replace(/\\\//g, "/"),
                });
            }
        }

        if (tracks.length == 0) {
            tracks.push({
                title: "Auto",
                data: url,
            });
        }

        return Response.success(tracks);
    }
    
    return null;
}
