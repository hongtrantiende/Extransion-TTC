const BASE_URL = "https://hhtq.hair";

function normalizeUrl(url) {
    url = url || BASE_URL;
    return url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

function parseCards(doc, selector) {
    let list = [];
    doc.select(selector).forEach(e => {
        let name = e.select(".film-poster a").attr("title");
        if (!name) name = e.select(".film-name a").text();
        
        let link = e.select(".film-poster a").attr("href");
        if (!link) link = e.select(".film-name a").attr("href");
        
        let img = e.select(".film-poster img").first();
        let cover = img.attr("data-src") || img.attr("src");
        
        let tag = e.select(".film-poster .tick-rate").text();
        if (!tag) tag = e.select(".film-poster .tick").first().text();

        list.push({
            name: name,
            link: link,
            description: tag,
            cover: cover,
            tag: tag,
            host: BASE_URL,
        });
    });
    return list;
}

function getNextPage(doc, page) {
    let next = "";
    let nextPage = (parseInt(page, 10) || 1) + 1;
    doc.select(".page-numbers a.page-numbers, .pagination a").forEach(e => {
        let href = e.attr("href");
        let text = e.text();
        if (!next && (text === nextPage.toString() || href.indexOf("/page/" + nextPage) >= 0)) {
            next = nextPage.toString();
        }
    });
    return next;
}
