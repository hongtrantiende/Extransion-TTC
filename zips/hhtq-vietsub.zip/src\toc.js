load('config.js');

function execute(url) {
    url = normalizeUrl(url);

    // === Cấu trúc MỚI (2025+) ===
    // Trang /movie/{slug}/ không còn danh sách tập.
    // Phải fetch trang /xem-phim/{slug}/tap-1-sv-1/ để lấy list.
    // Cấu trúc: div.tab-pane#tab-N → .donphuongdocma → a.ep-item
    let slug = '';
    let movieMatch = url.match(/\/movie\/([^\/]+)\/?/);
    if (movieMatch) slug = movieMatch[1];

    // Nếu URL là trang watch thì lấy slug từ đó
    if (!slug) {
        let watchMatch = url.match(/\/xem-phim\/([^\/]+)\//);
        if (watchMatch) slug = watchMatch[1];
    }

    let list = [];

    if (slug) {
        // Fetch trang watch episode đầu tiên
        let watchUrl = BASE_URL + '/xem-phim/' + slug + '/tap-1-sv-1/';
        let watchResp = fetch(watchUrl);
        if (watchResp && watchResp.ok) {
            let doc = watchResp.html();

            // Mỗi tab-pane là 1 server: #tab-1, #tab-2 ...
            doc.select('.tab-content .tab-pane').forEach(pane => {
                let tabId = pane.attr('id');
                if (!tabId || tabId === 'top-viewed-day') return; // bỏ qua tab không phải server

                // Tên server từ nav tab button
                let tabBtn = doc.select("a[href='#" + tabId + "']").first();
                let serverName = tabBtn ? (tabBtn.attr('title') || tabBtn.text().trim()) : tabId;

                // Danh sách tập trong donphuongdocma hoặc ep-item
                let epItems = pane.select('.donphuongdocma a, a.ep-item, a.ssl-item');
                if (epItems.size() === 0) return;

                // Section header cho server
                list.push({ name: serverName, type: 'section' });

                // Sắp xếp tập từ 1 → mới nhất (web thường hiển thị ngược)
                let eps = [];
                epItems.forEach(a => {
                    let href = a.attr('href');
                    let order = a.select('.ssli-order').text().trim();
                    let name = order || a.text().trim();
                    if (href) eps.push({ name: 'Tập ' + name, url: href, host: BASE_URL });
                });
                for (let i = eps.length - 1; i >= 0; i--) {
                    list.push(eps[i]);
                }
            });
        }
    }

    // === Fallback: cấu trúc CŨ (.halim-server) ===
    if (list.length === 0) {
        let response = fetch(url);
        if (!response || !response.ok) return null;
        let doc = response.html();

        let servers = doc.select('.halim-server');
        let hasMultiple = servers.size() > 1;
        servers.forEach(server => {
            let serverName = server.select('.halim-server-name').text();
            if (hasMultiple && serverName) {
                list.push({ name: serverName, type: 'section' });
            }
            let eps = server.select('.halim-list-eps li');
            for (let i = eps.size() - 1; i >= 0; i--) {
                let e = eps.get(i);
                let a = e.select('a').first();
                let span = e.select('span').first();
                let href = (a ? a.attr('href') : '') || (span ? span.attr('data-href') : '');
                let name = (span ? span.text() : '') || (a ? a.text() : '');
                if (href) list.push({ name: name, url: href, host: BASE_URL });
            }
        });
    }

    return list.length > 0 ? Response.success(list) : null;
}
