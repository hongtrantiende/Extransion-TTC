load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();
        
        let genres = [];
        doc.select(".anisc-info a.genre").forEach(e => {
            genres.push({
                title: e.text().trim(),
                input: e.attr("href"),
                script: "gen.js"
            });
        });

        let suggests = [];
        parseCards(doc, ".flw-item").forEach(e => {
            suggests.push({
                title: e.name,
                input: e.link,
                script: "detail.js"
            });
        });

        let detail = [];
        doc.select(".anisc-info .item").forEach(e => {
            let head = e.select(".item-head").text().replace(":", "").trim();
            let val = e.select(".name").text().trim() || e.select("a").text().trim();
            if (head && val) {
                detail.push(head + ": " + val);
            }
        });

        let ongoing = true;
        doc.select(".anisc-info .item").forEach(e => {
            let head = e.select(".item-head").text();
            if (head.indexOf("Trạng thái") >= 0) {
                let status = e.select(".name").text().toLowerCase();
                if (status.indexOf("hoàn") >= 0 || status.indexOf("completed") >= 0) {
                    ongoing = false;
                }
            }
        });

        let description = doc.select(".film-description .text").html() || doc.select(".film-description").html() || "";

        // Lấy link xem phim đầu tiên có /xem-phim/ làm tocUrl
        let tocUrl = "";
        doc.select("a").forEach(e => {
            let href = e.attr("href");
            if (href && href.indexOf("/xem-phim/") >= 0 && !tocUrl) {
                tocUrl = href;
            }
        });

        return Response.success({
            name: doc.select("h2.film-name").text().trim(),
            cover: doc.select(".film-poster-img").first().attr("src"),
            author: "HHTQ Vietsub",
            description: description.trim(),
            detail: detail.join("<br>"),
            ongoing: ongoing,
            genres: genres,
            suggests: suggests,
            format: "series",
            host: BASE_URL
        });
    }
    return null;
}
