function execute(url) {
    let currentUrl = url;
    let fullContent = "";

    while (currentUrl) {
        let response = fetch(currentUrl);
        if (!response.ok) break;

        let doc = response.html();
        let contentEl = doc.select("#chaptercontent");
        if (!contentEl) break;

        contentEl.select("script, style, ins, a, .ads").remove();
        
        let text = contentEl.html();
        text = text
            .replace(/<br\s*\/?>/gi, "\n")
            .replace(/&nbsp;/g, " ")
            .replace(/&amp;/g, "&")
            .replace(/&lt;/g, "<")
            .replace(/&gt;/g, ">")
            .replace(/&quot;/g, '"')
            .replace(/&#39;/g, "'")
            .trim();

        fullContent += text + "\n";

        let nextLink = null;
        doc.select("a").forEach(function(el) {
            let linkText = el.text();
            if (linkText.includes("下一页") && !linkText.includes("下一章")) {
                nextLink = el.attr("href");
            }
        });

        if (nextLink && !nextLink.startsWith("http")) {
            if (nextLink.startsWith("/")) {
                nextLink = "https://m.douyinxs.com" + nextLink;
            } else {
                let base = currentUrl.substring(0, currentUrl.lastIndexOf("/"));
                nextLink = base + "/" + nextLink;
            }
        }

        if (nextLink && nextLink !== currentUrl) {
            currentUrl = nextLink;
        } else {
            currentUrl = null;
        }
    }

    if (!fullContent.trim()) return Response.error("Failed to load chapter content");
    return Response.success(fullContent.trim());
}
