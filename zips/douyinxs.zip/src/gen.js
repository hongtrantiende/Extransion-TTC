function execute(url, page) {
    page = page || "1";
    let fetchUrl = url;
    if (!fetchUrl.endsWith("/")) fetchUrl += "/";
    fetchUrl += page + "/";

    let response = fetch(fetchUrl);
    if (!response.ok) return Response.error("Failed to load list");

    let doc = response.html();
    let data = [];

    doc.select("#main .hot_sale").forEach(function(el) {
        let name = el.select(".title").text();
        let link = el.select("a").first().attr("href");
        let author = el.select(".author").text().replace(/（.*）/, "").trim();
        let description = el.select(".review").text().replace("简介：", "").trim();

        if (link && !link.startsWith("http")) link = "https://m.douyinxs.com" + link;

        let bookId = "";
        let match = link ? link.match(/\/bqg\/(\d+)\/?/) : null;
        if (match) {
            bookId = match[1];
        }

        let cover = "";
        if (bookId) {
            let id = parseInt(bookId);
            let coverId = Math.floor(id / 6) - 1;
            let subDir = Math.floor(coverId / 1000);
            cover = "https://img.douyinxs.com/" + subDir + "/" + coverId + "/" + coverId + "s.jpg";
        }

        if (name && link) {
            data.push({
                name: name,
                link: link,
                cover: cover,
                description: description || "",
                author: author || "",
                host: "https://m.douyinxs.com"
            });
        }
    });

    let nextPage = null;
    if (data.length > 0) {
        nextPage = String(parseInt(page) + 1);
    }

    return Response.success(data, nextPage);
}
