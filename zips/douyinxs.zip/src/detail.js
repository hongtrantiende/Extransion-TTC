function execute(url) {
    let response = fetch(url);
    if (!response.ok) return Response.error("Failed to load details");

    let doc = response.html();
    
    let name = doc.select(".channelHeader .title").text();
    if (!name) name = doc.select(".synopsisArea_detail h2").text();
    
    let author = doc.select(".synopsisArea_detail .author").text().replace("作者：", "").trim();
    if (!author) {
        let firstP = doc.select(".synopsisArea_detail p").first();
        author = firstP ? firstP.text().replace("作者：", "").trim() : "";
    }

    let cover = doc.select(".synopsisArea_detail img").attr("src");
    if (cover && cover.startsWith("//")) cover = "https:" + cover;

    let description = doc.select(".review").text().replace("简介：", "").trim();

    return Response.success({
        name: name,
        author: author,
        cover: cover || "",
        description: description || "",
        detail: "作者: " + author,
        host: "https://m.douyinxs.com"
    });
}
