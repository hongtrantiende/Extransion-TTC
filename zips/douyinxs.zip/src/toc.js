function execute(url) {
    let response = fetch(url);
    if (!response.ok) return Response.error("Failed to load table of contents");

    let doc = response.html();
    let pages = [];
    
    let options = doc.select("#indexselect option");
    
    if (options.size() > 0 && !url.match(/_\d+\/?$/)) {
        options.forEach(function(opt) {
            let pageUrl = opt.attr("value");
            if (pageUrl) {
                pageUrl = pageUrl.replace(/https?:\/\/[^\/]+/, "https://m.douyinxs.com");
                pages.push(pageUrl);
            }
        });
    } else {
        pages.push(url);
    }

    let data = [];
    let seenUrls = {};

    pages.forEach(function(pageUrl) {
        let pRes = (pageUrl === url) ? response : fetch(pageUrl);
        if (!pRes.ok) return;

        let pDoc = pRes.html();
        
        pDoc.select(".directoryArea:not(#chapterlist) p a").forEach(function(el) {
            let name = el.text();
            let link = el.attr("href");

            if (link && !link.startsWith("http")) {
                link = "https://m.douyinxs.com" + link;
            }

            if (name && link && !seenUrls[link]) {
                seenUrls[link] = true;
                data.push({
                    name: name,
                    url: link
                });
            }
        });
    });

    return Response.success(data);
}
