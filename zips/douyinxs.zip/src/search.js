function execute(key, page) {
    let response = fetch("https://m.douyinxs.com/search/", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36"
        },
        body: "searchkey=" + encodeURIComponent(key)
    });

    if (!response.ok) return Response.error("Search failed");

    let doc = response.html();
    let data = [];

    doc.select(".bookbox").forEach(function(el) {
        let name = el.select("h4 a").text();
        let link = el.select("h4 a").attr("href");
        let cover = el.select(".bookimg img").attr("src");
        
        let author = "";
        let authorEl = el.select(".author").first();
        if (authorEl) {
            author = authorEl.text().replace("作者：", "").trim();
        }

        let description = el.select(".review").text().replace("简介：", "").trim();

        if (link && !link.startsWith("http")) link = "https://m.douyinxs.com" + link;
        if (cover && cover.startsWith("//")) cover = "https:" + cover;

        if (name && link) {
            data.push({
                name: name,
                link: link,
                cover: cover || "",
                description: description || "",
                author: author || "",
                host: "https://m.douyinxs.com"
            });
        }
    });

    return Response.success(data);
}
