function execute(url) {
    let response = fetch(url);
    if (!response.ok) return Response.error("Failed to load pages");

    let doc = response.html();
    let options = doc.select("#indexselect option");
    let pages = [];

    if (options.size() > 0) {
        options.forEach(function(opt) {
            let pageUrl = opt.attr("value");
            if (pageUrl) {
                pageUrl = pageUrl.replace(/https?:\/\/[^\/]+/, "https://m.douyinxs.com");
                pages.push(pageUrl);
            }
        });
    } else {
        pages.push(url);
    }

    return Response.success(pages);
}
