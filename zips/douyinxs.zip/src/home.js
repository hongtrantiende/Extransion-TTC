function execute() {
    return Response.success([
        { title: "全部书库", input: "https://m.douyinxs.com/fenlei/", script: "gen.js" },
        { title: "玄奇", input: "https://m.douyinxs.com/fenlei/1/", script: "gen.js" },
        { title: "高武", input: "https://m.douyinxs.com/fenlei/2/", script: "gen.js" },
        { title: "修仙", input: "https://m.douyinxs.com/fenlei/3/", script: "gen.js" },
        { title: "都市", input: "https://m.douyinxs.com/fenlei/4/", script: "gen.js" },
        { title: "历史", input: "https://m.douyinxs.com/fenlei/6/", script: "gen.js" },
        { title: "全部完本", input: "https://m.douyinxs.com/quanben/fenlei/", script: "gen.js" }
    ]);
}
