load('config.js');

// chap.js v2 — AnimeHay / MotChill
// RSC payload cũ: { server, name, slug, type: "m3u8", link: "https://..." }
// RSC payload mới (sau khi site đổi): link chỉ là slug (tap-1), không phải URL
// Fix: nếu link không phải HTTP URL → build full chapter URL từ slug → trả embed

function execute(url) {
    if (!url) return Response.success([]);

    url = normalizeUrl(url);
    var response = fetchPage(url);
    if (!response.ok) return Response.success([]);

    var html = response.text();

    // Tìm episode slug từ URL: /phim/{movie-slug}/tap-01 → tap-01
    var epSlugMatch = url.match(/\/(?:tap-|episode-)([^\/?#]+)/i)
        || url.match(/\/([a-z0-9-]+-\d+)\/?(?:\?|$|#)/i);
    var epSlug = epSlugMatch ? epSlugMatch[0].replace(/^\//, '') : '';

    // Movie slug: /phim/{movie-slug}/tap-XX → movie-slug
    var movieSlugMatch = url.match(/\/phim\/([^\/]+)\//);
    var movieSlug = movieSlugMatch ? movieSlugMatch[1] : '';

    var servers = [];
    var seen = {};

    // Pattern chính: "server":"...","name":"...","slug":"tap-01","type":"m3u8","link":"..."
    var pattern = /\"server\"\s*:\s*\"([^\"]+)\"\s*,\s*\"name\"\s*:\s*\"([^\"]+)\"\s*,\s*\"slug\"\s*:\s*\"([^\"]+)\"\s*,\s*\"type\"\s*:\s*\"([^\"]+)\"\s*,\s*\"link\"\s*:\s*\"([^\"]+)\"/g;
    var match;

    while ((match = pattern.exec(html)) !== null) {
        var serverName = match[1];
        var epName = match[2];
        var slug = match[3];
        var type = match[4];
        var link = match[5].replace(/\\\//g, '/');

        // Lọc theo slug tập hiện tại
        var slugMatch = epSlug && slug.indexOf(epSlug) >= 0 || !epSlug;
        if (!slugMatch) continue;

        var key = serverName + '_' + type;
        if (seen[key]) continue;
        seen[key] = true;

        // Kiểm tra link có phải HTTP URL không
        var isDirectUrl = link.indexOf('http://') === 0 || link.indexOf('https://') === 0;

        if (type === 'm3u8' && isDirectUrl) {
            // Direct m3u8 stream — phát trực tiếp qua ExoPlayer
            servers.push({
                title: serverName + ' (M3U8)',
                data: JSON.stringify({
                    url: link,
                    type: 'native',
                    referer: DEFAULT_REFERER
                })
            });
        } else if (type === 'embed' && isDirectUrl) {
            // Embed player URL
            servers.push({
                title: serverName + ' (Embed)',
                data: JSON.stringify({
                    url: link,
                    type: 'auto',
                    referer: DEFAULT_REFERER
                })
            });
        } else {
            // link chỉ là slug (format mới) → build full chapter page URL
            // hoặc là slug tập → dùng URL tập phim đầy đủ làm embed source
            var chapUrl = url; // Dùng URL tập hiện tại
            if (movieSlug && (link === slug || link.length < 20)) {
                chapUrl = DEFAULT_REFERER + 'phim/' + movieSlug + '/' + (link || slug);
            }
            var displayType = (type === 'm3u8') ? 'M3U8' : 'Embed';
            servers.push({
                title: serverName + ' (' + displayType + ')',
                data: JSON.stringify({
                    url: chapUrl,
                    type: 'auto',
                    referer: DEFAULT_REFERER
                })
            });
        }
    }

    // Fallback: escaped pattern (RSC escaped JSON trong __next_f.push)
    if (servers.length === 0) {
        var escPattern = /\\?"server\\?"\s*:\s*\\?"([^"\\]+)\\?"\s*,\s*\\?"name\\?"\s*:\s*\\?"([^"\\]+)\\?"\s*,\s*\\?"slug\\?"\s*:\s*\\?"([^"\\]+)\\?"\s*,\s*\\?"type\\?"\s*:\s*\\?"([^"\\]+)\\?"\s*,\s*\\?"link\\?"\s*:\s*\\?"([^"\\]+)\\?"/g;
        while ((match = escPattern.exec(html)) !== null) {
            var sName = match[1];
            var eSlug = match[3];
            var eType = match[4];
            var eLink = match[5].replace(/\\\//g, '/');

            var slugOk = epSlug ? (eSlug.indexOf(epSlug) >= 0) : true;
            if (!slugOk) continue;

            var eKey = sName + '_' + eType;
            if (seen[eKey]) continue;
            seen[eKey] = true;

            var eDirect = eLink.indexOf('http') === 0;

            if (eType === 'm3u8' && eDirect) {
                servers.push({
                    title: sName + ' (M3U8)',
                    data: JSON.stringify({ url: eLink, type: 'native', referer: DEFAULT_REFERER })
                });
            } else {
                var eChapUrl = url;
                if (movieSlug && !eDirect) {
                    eChapUrl = DEFAULT_REFERER + 'phim/' + movieSlug + '/' + (eLink || eSlug);
                }
                servers.push({
                    title: sName + ' (Embed)',
                    data: JSON.stringify({ url: eChapUrl, type: 'auto', referer: DEFAULT_REFERER })
                });
            }
        }
    }

    // Fallback cuối: nếu không tìm thấy gì → load cả trang episode làm WebView embed
    if (servers.length === 0 && url.indexOf('http') === 0) {
        servers.push({
            title: 'Xem trên trang web',
            data: JSON.stringify({
                url: url,
                type: 'auto',
                referer: DEFAULT_REFERER
            })
        });
    }

    return Response.success(servers);
}
