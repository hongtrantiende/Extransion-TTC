load("config.js");

function execute(input) {
    let url = input.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL)
    if (url.endsWith("/")) {
        url += "/";
    }
    let response = fetch(url);

    if (response.ok) {
        let html = response.html();
        let storyList = [];

        let stories = html.select("a.flex.items-center");
        stories.forEach(function(story) {
            console.log(story.html());
            let name = story.select("div.text-txt-primary").text().trim();
            let link = encodeURI(story.attr("href"));
            let cover = story.select("img").first().attr("src");
            let description = story.select("span.text-xs").first().text().trim();
            if (name && link) {
                storyList.push({
                    name: name,
                    link: link,
                    cover: cover,
                    description: description,
                    host: BASE_URL

                });
            }
        });

        return Response.success(storyList);
    }

    return Response.error("Không thể tải danh sách truyện.");
}