load("config.js");

function execute(input) {
    let url = input.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    // if (!url.endsWith("/")) {
    //     url += "/";
    // }
    let response = fetch(url);

    if (response.ok) {
        let html = response.html();
        let chapterList = [];
        
        let chapters = html.select("div.divide-y a");
        chapters.forEach(function(chapter) {
            let chapterName = chapter.select("span").first().text().replace("Chap", "Chapter").replace("Ch.", "Chapter").trim();
            let chapterLink = encodeURI(chapter.attr("href"));
            chapterList.push({
                name: chapterName,
                url: chapterLink,
                // /truyen-hentai/em-muon-đuoc-len-đinh/chap-1en
                host: BASE_URL
            });
        });

        chapterList.reverse();
        return Response.success(chapterList);
    }
    
    return Response.error("Không thể tải danh sách chương.");
}