load("config.js");

function execute(input) {
    let url = input.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    // if (!url.endsWith("/")) {
    //     url += "/";
    // }
    let response = fetch(url);

    if (response.ok) {
        let text = response.text();
        let data = [];

        let imgLinks = text.match(/https?:\/\/[^"]+\/manga-images\/[^"]+\.(?:jpg|webp|png|jpeg)/g);

        if (imgLinks) {
            imgLinks.forEach(function(link) {
                data.push({
                    link: link,
                    fallback: []
                });
            });
        }

        if (data.length > 0) {
            // console.log("Số lượng ảnh tìm thấy: " + data.length);
            return Response.success(data);
        }
    }

    return Response.error("Không thể tải nội dung chương.");
}
