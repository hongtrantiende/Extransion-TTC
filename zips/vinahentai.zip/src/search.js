load("config.js");

function execute(key, page) {
    if (!page) page = "1";
    let url = BASE_URL + "/search?q=" + encodeURIComponent(key) + "&page=" + page;
    let response = fetch(url);

    if (response.ok) {
        let html = response.html();
        let storyList = [];
        let stories = html.select("a.border-bd-default");
        stories.forEach(function(story) {
            let name = story.select("h2").text().trim();
            let link = encodeURI(story.attr("href"));
            let cover = story.select("img").first().attr("src");
            let description = story.select("p").last().text().trim();
            if (name && link) {
                storyList.push({
                    name: name,
                    link: link,
                    cover: cover,
                    description: description,
                    host: BASE_URL

                });
            }
        });

        let next = null;
        if (storyList.length > 0) {
            next = (parseInt(page) + 1).toString();
        }

        return Response.success(storyList, next);
    }
    
    return Response.error("Không tìm thấy kết quả.");
}
