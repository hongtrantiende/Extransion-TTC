load("config.js");

function execute(input) {
    let nameStory = getParam(input, "nameStory");
    let url = input.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL).replace(/[?&]nameStory=[^&]+/, "");
    if (url.endsWith("/")) {
        url += "/";
    }
    let response = fetch(url);

    if (response.ok) {
        let html = response.html();
        let storyList = [];
        
        let stories = html.select("a.group.bg-bgc-layer1");
        stories.forEach(function(story) {
            let name = story.select("div.px-2.pb-2").text().trim();
            let link = encodeURI(story.attr("href"));
            let cover = story.select("img").first().attr("src");
            let description = story.select("span").text().trim() || "";
            if (name && link && name != nameStory) {
                storyList.push({
                    name: name,
                    link: link,
                    cover: cover,
                    description: description,
                    host: BASE_URL

                });
            }
        });

        let next = null;
        let lastBtn = html.select("button[title*='Tới trang cuối']");
        if (!lastBtn.isEmpty() && !lastBtn.toString().includes("disabled")) {
            next = (parseInt(page) + 1).toString();
        }

        storyList.sort(function(){ return 0.5 - Math.random(); });
        storyList = storyList.slice(0, 10);
        return Response.success(storyList);
    }

    return null;
}