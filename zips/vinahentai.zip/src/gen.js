load("config.js");

function execute(input, page) {
    if (!page) page = "1";
    let url = input.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    if (url.endsWith("/")) {
        url = url.slice(0, -1);
    }
    url += url.includes("?") ? "&page=" + page : "?page=" + page;
    let response = fetch(url);

    if (response.ok) {
        let html = response.html();
        let storyList = [];

        let stories = html.select("a.group.bg-bgc-layer1");
        stories.forEach(function(story) {
            let name = story.select("div.px-2.pb-2").text().trim();
            let link = encodeURI(story.attr("href"));
            if (link.includes("login")) link = decodeURIComponent(getParam(link, "redirect"));
            let cover = story.select("img").first().attr("src");
            let description = story.select("span").last().text().trim();
            if (name && link) {
                
                storyList.push({
                    name: name,
                    link: link,
                    cover: cover,
                    description: description,
                    host: BASE_URL

                });
            }
        });

        let next = null;
        let lastBtn = html.select("button[title*='Tới trang cuối']");
        if (!lastBtn.isEmpty() && !lastBtn.toString().includes("disabled")) {
            next = (parseInt(page) + 1).toString();
        }

        return Response.success(storyList, next);
    }

    return Response.error("Không thể tải danh sách truyện.");
}