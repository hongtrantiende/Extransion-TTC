let BASE_URL = "https://vinahentai.bond";

try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {}

try {
    if (typeof config_url !== "undefined") {
        if (config_url != "null") {
            BASE_URL = config_url;
        }
    }
} catch (error) {}

function getParam(input, name) {
    let match = input.match(new RegExp("[?&]" + name + "=([^&]+)"));
    return match ? decodeURIComponent(match[1]) : "";
}