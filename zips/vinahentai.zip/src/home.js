load("config.js");

function execute() {
  return Response.success([
    { title: "Mới Cập Nhật", input: BASE_URL + "/danh-sach?sort=updatedAt", script: "gen.js" },
    { title: "Truyện Mới", input: BASE_URL + "/danh-sach?sort=createdAt", script: "gen.js" },
    { title: "Hoàn Thành", input: BASE_URL + "/danh-sach?sort=updatedAt&status=completed", script: "gen.js" },
    { title: "Top All Time", input: BASE_URL + "/leaderboard/manga?period=all-time", script: "rank.js" },
    { title: "Top Tháng", input: BASE_URL + "/leaderboard/manga?period=monthly", script: "rank.js" },
    { title: "Top Tuần", input: BASE_URL + "/leaderboard/manga?period=weekly", script: "rank.js" },
    { title: "Top Ngày", input: BASE_URL + "/leaderboard/manga?period=daily", script: "rank.js" }
  ]);
}
