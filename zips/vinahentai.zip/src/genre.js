load("config.js");

function execute() {
    return Response.success([
        // Nhóm ký tự đặc biệt & Số
        { title: "3D Hentai", input: BASE_URL + "/genres/3d-hentai", script: "gen.js" },
        { title: "Manhwa", input: BASE_URL + "/genres/manhwa", script: "gen.js" },
        { title: "Ảnh Cosplay", input: BASE_URL + "/genres/anh-cosplay", script: "gen.js" },

        // Nhóm A
        { title: "Action", input: BASE_URL + "/genres/action", script: "gen.js" },
        { title: "Adult", input: BASE_URL + "/genres/adult", script: "gen.js" },
        { title: "Adventure", input: BASE_URL + "/genres/adventure", script: "gen.js" },
        { title: "Ahegao", input: BASE_URL + "/genres/ahegao", script: "gen.js" },
        { title: "AI Generated", input: BASE_URL + "/genres/ai-generated", script: "gen.js" },
        { title: "Anal", input: BASE_URL + "/genres/anal", script: "gen.js" },
        { title: "Angel", input: BASE_URL + "/genres/angel", script: "gen.js" },
        { title: "Ảnh động", input: BASE_URL + "/genres/anh-dong", script: "gen.js" },
        { title: "Animal", input: BASE_URL + "/genres/animal", script: "gen.js" },
        { title: "Animal Girl", input: BASE_URL + "/genres/animal-girl", script: "gen.js" },
        { title: "Áo dài", input: BASE_URL + "/genres/ao-dai", script: "gen.js" },
        { title: "Apron", input: BASE_URL + "/genres/apron", script: "gen.js" },
        { title: "Artist CG", input: BASE_URL + "/genres/artist-cg", script: "gen.js" },

        // Nhóm B
        { title: "Based Game", input: BASE_URL + "/genres/based-game", script: "gen.js" },
        { title: "BBM", input: BASE_URL + "/genres/bbm", script: "gen.js" },
        { title: "BBW", input: BASE_URL + "/genres/bbw", script: "gen.js" },
        { title: "BDSM", input: BASE_URL + "/genres/bdsm", script: "gen.js" },
        { title: "Beach", input: BASE_URL + "/genres/beach", script: "gen.js" },
        { title: "Bestiality", input: BASE_URL + "/genres/bestiality", script: "gen.js" },
        { title: "Big Ass", input: BASE_URL + "/genres/big-ass", script: "gen.js" },
        { title: "Big Boobs", input: BASE_URL + "/genres/big-boobs", script: "gen.js" },
        { title: "Big Penis", input: BASE_URL + "/genres/big-penis", script: "gen.js" },
        { title: "Bikini", input: BASE_URL + "/genres/bikini", script: "gen.js" },
        { title: "Bisexual", input: BASE_URL + "/genres/bisexual", script: "gen.js" },
        { title: "Black Skin", input: BASE_URL + "/genres/black-skin", script: "gen.js" },
        { title: "Blackmail", input: BASE_URL + "/genres/blackmail", script: "gen.js" },
        { title: "Blindfold", input: BASE_URL + "/genres/blindfold", script: "gen.js" },
        { title: "Bloomers", input: BASE_URL + "/genres/bloomers", script: "gen.js" },
        { title: "BlowJobs", input: BASE_URL + "/genres/blowjobs", script: "gen.js" },
        { title: "Body Swap", input: BASE_URL + "/genres/body-swap", script: "gen.js" },
        { title: "Body Writing", input: BASE_URL + "/genres/body-writing", script: "gen.js" },
        { title: "Bodysuit", input: BASE_URL + "/genres/bodysuit", script: "gen.js" },
        { title: "Bondage", input: BASE_URL + "/genres/bondage", script: "gen.js" },
        { title: "Breast Sucking", input: BASE_URL + "/genres/breast-sucking", script: "gen.js" },
        { title: "BreastJobs", input: BASE_URL + "/genres/breastjobs", script: "gen.js" },
        { title: "Brocon", input: BASE_URL + "/genres/brocon", script: "gen.js" },
        { title: "Brother", input: BASE_URL + "/genres/brother", script: "gen.js" },
        { title: "Bukkake", input: BASE_URL + "/genres/bukkake", script: "gen.js" },
        { title: "Bunny Girl", input: BASE_URL + "/genres/bunny-girl", script: "gen.js" },
        { title: "Business Suit", input: BASE_URL + "/genres/business-suit", script: "gen.js" },

        // Nhóm C
        { title: "Chastity belt", input: BASE_URL + "/genres/chastity-belt", script: "gen.js" },
        { title: "Che ít", input: BASE_URL + "/genres/che-it", script: "gen.js" },
        { title: "Che nhiều", input: BASE_URL + "/genres/che-nhieu", script: "gen.js" },
        { title: "Cheating", input: BASE_URL + "/genres/cheating", script: "gen.js" },
        { title: "Cheerleader", input: BASE_URL + "/genres/cheerleader", script: "gen.js" },
        { title: "Chikan", input: BASE_URL + "/genres/chikan", script: "gen.js" },
        { title: "Chinese Dress", input: BASE_URL + "/genres/chinese-dress", script: "gen.js" },
        { title: "Có che", input: BASE_URL + "/genres/co-che", script: "gen.js" },
        { title: "Collar", input: BASE_URL + "/genres/collar", script: "gen.js" },
        { title: "Comedy", input: BASE_URL + "/genres/comedy", script: "gen.js" },
        { title: "Comic", input: BASE_URL + "/genres/comic", script: "gen.js" },
        { title: "Condom", input: BASE_URL + "/genres/condom", script: "gen.js" },
        { title: "Cosplay", input: BASE_URL + "/genres/cosplay", script: "gen.js" },
        { title: "Cousin", input: BASE_URL + "/genres/cousin", script: "gen.js" },
        { title: "Creampie", input: BASE_URL + "/genres/creampie", script: "gen.js" },
        { title: "Cross-dressing", input: BASE_URL + "/genres/cross-dressing", script: "gen.js" },
        { title: "Crotch Tattoo", input: BASE_URL + "/genres/crotch-tattoo", script: "gen.js" },
        { title: "Cuckold", input: BASE_URL + "/genres/cuckold", script: "gen.js" },
        { title: "Cum swap", input: BASE_URL + "/genres/cum-swap", script: "gen.js" },
        { title: "Cunnilingus", input: BASE_URL + "/genres/cunnilingus", script: "gen.js" },

        // Nhóm D
        { title: "Dark Skin", input: BASE_URL + "/genres/dark-skin", script: "gen.js" },
        { title: "Daughter", input: BASE_URL + "/genres/daughter", script: "gen.js" },
        { title: "Deepthroat", input: BASE_URL + "/genres/deepthroat", script: "gen.js" },
        { title: "Demon", input: BASE_URL + "/genres/demon", script: "gen.js" },
        { title: "DemonGirl", input: BASE_URL + "/genres/demongirl", script: "gen.js" },
        { title: "Devil", input: BASE_URL + "/genres/devil", script: "gen.js" },
        { title: "DevilGirl", input: BASE_URL + "/genres/devilgirl", script: "gen.js" },
        { title: "Dirty", input: BASE_URL + "/genres/dirty", script: "gen.js" },
        { title: "DirtyOldMan", input: BASE_URL + "/genres/dirtyoldman", script: "gen.js" },
        { title: "Double Penetration", input: BASE_URL + "/genres/double-penetration", script: "gen.js" },
        { title: "Doujinshi", input: BASE_URL + "/genres/doujinshi", script: "gen.js" },
        { title: "Drama", input: BASE_URL + "/genres/drama", script: "gen.js" },
        { title: "Drug", input: BASE_URL + "/genres/drug", script: "gen.js" },
        { title: "Drunk", input: BASE_URL + "/genres/drunk", script: "gen.js" },

        // Nhóm E
        { title: "Ecchi", input: BASE_URL + "/genres/ecchi", script: "gen.js" },
        { title: "Elder Sister", input: BASE_URL + "/genres/elder-sister", script: "gen.js" },
        { title: "Elf", input: BASE_URL + "/genres/elf", script: "gen.js" },
        { title: "Exhibitionism", input: BASE_URL + "/genres/exhibitionism", script: "gen.js" },

        // Nhóm F
        { title: "Facesitting", input: BASE_URL + "/genres/facesitting", script: "gen.js" },
        { title: "Fantasy", input: BASE_URL + "/genres/fantasy", script: "gen.js" },
        { title: "Father", input: BASE_URL + "/genres/father", script: "gen.js" },
        { title: "Females only", input: BASE_URL + "/genres/females-only", script: "gen.js" },
        { title: "Femdom", input: BASE_URL + "/genres/femdom", script: "gen.js" },
        { title: "Feminization", input: BASE_URL + "/genres/feminization", script: "gen.js" },
        { title: "Fingering", input: BASE_URL + "/genres/fingering", script: "gen.js" },
        { title: "Footjob", input: BASE_URL + "/genres/footjob", script: "gen.js" },
        { title: "Full Color", input: BASE_URL + "/genres/full-color", script: "gen.js" },
        { title: "Furry", input: BASE_URL + "/genres/furry", script: "gen.js" },
        { title: "Futanari", input: BASE_URL + "/genres/futanari", script: "gen.js" },

        // Nhóm G
        { title: "Gag", input: BASE_URL + "/genres/gag", script: "gen.js" },
        { title: "Gangbang", input: BASE_URL + "/genres/gangbang", script: "gen.js" },
        { title: "Garter Belts", input: BASE_URL + "/genres/garter-belts", script: "gen.js" },
        { title: "Gender Bender", input: BASE_URL + "/genres/gender-bender", script: "gen.js" },
        { title: "Ghost", input: BASE_URL + "/genres/ghost", script: "gen.js" },
        { title: "Glasses", input: BASE_URL + "/genres/glasses", script: "gen.js" },
        { title: "Glory hole", input: BASE_URL + "/genres/glory-hole", script: "gen.js" },
        { title: "Góc Nhìn Nữ", input: BASE_URL + "/genres/goc-nhin-nu", script: "gen.js" },
        { title: "Gothic Lolita", input: BASE_URL + "/genres/gothic-lolita", script: "gen.js" },
        { title: "Group", input: BASE_URL + "/genres/group", script: "gen.js" },
        { title: "Guro", input: BASE_URL + "/genres/guro", script: "gen.js" },

        // Nhóm H
        { title: "Hairjob", input: BASE_URL + "/genres/hairjob", script: "gen.js" },
        { title: "Hairy", input: BASE_URL + "/genres/hairy", script: "gen.js" },
        { title: "Handjob", input: BASE_URL + "/genres/handjob", script: "gen.js" },
        { title: "Harem", input: BASE_URL + "/genres/harem", script: "gen.js" },
        { title: "Hell No", input: BASE_URL + "/genres/hell-no", script: "gen.js" },
        { title: "Hentaivn", input: BASE_URL + "/genres/hentaivn", script: "gen.js" },
        { title: "Hidden sex", input: BASE_URL + "/genres/hidden-sex", script: "gen.js" },
        { title: "Historical", input: BASE_URL + "/genres/historical", script: "gen.js" },
        { title: "Horror", input: BASE_URL + "/genres/horror", script: "gen.js" },
        { title: "Housewife", input: BASE_URL + "/genres/housewife", script: "gen.js" },
        { title: "Humiliation", input: BASE_URL + "/genres/humiliation", script: "gen.js" },

        // Nhóm I
        { title: "Idol", input: BASE_URL + "/genres/idol", script: "gen.js" },
        { title: "Imouto", input: BASE_URL + "/genres/imouto", script: "gen.js" },
        { title: "Incest", input: BASE_URL + "/genres/incest", script: "gen.js" },
        { title: "Insect", input: BASE_URL + "/genres/insect", script: "gen.js" },
        { title: "Isekai", input: BASE_URL + "/genres/isekai", script: "gen.js" },

        // Nhóm K
        { title: "Không che", input: BASE_URL + "/genres/hentai-khong-che", script: "gen.js" },
        { title: "Kimono", input: BASE_URL + "/genres/kimono", script: "gen.js" },
        { title: "Kissing", input: BASE_URL + "/genres/kissing", script: "gen.js" },
        { title: "Kuudere", input: BASE_URL + "/genres/kuudere", script: "gen.js" },

        // Nhóm L
        { title: "Lingerie", input: BASE_URL + "/genres/lingerie", script: "gen.js" },
        { title: "Lolicon", input: BASE_URL + "/genres/lolicon", script: "gen.js" },

        // Nhóm M
        { title: "Maids", input: BASE_URL + "/genres/maids", script: "gen.js" },
        { title: "Males only", input: BASE_URL + "/genres/males-only", script: "gen.js" },
        { title: "Manhua", input: BASE_URL + "/genres/manhua", script: "gen.js" },
        { title: "Masturbation", input: BASE_URL + "/genres/masturbation", script: "gen.js" },
        { title: "Mature", input: BASE_URL + "/genres/mature", script: "gen.js" },
        { title: "Mermaid", input: BASE_URL + "/genres/mermaid", script: "gen.js" },
        { title: "Miko", input: BASE_URL + "/genres/miko", script: "gen.js" },
        { title: "Milf", input: BASE_URL + "/genres/milf", script: "gen.js" },
        { title: "Mind Break", input: BASE_URL + "/genres/mind-break", script: "gen.js" },
        { title: "Mind Control", input: BASE_URL + "/genres/mind-control", script: "gen.js" },
        { title: "Monster", input: BASE_URL + "/genres/monster", script: "gen.js" },
        { title: "Monstergirl", input: BASE_URL + "/genres/monstergirl", script: "gen.js" },
        { title: "Mother", input: BASE_URL + "/genres/mother", script: "gen.js" },

        // Nhóm N
        { title: "Nakadashi", input: BASE_URL + "/genres/nakadashi", script: "gen.js" },
        { title: "Netori", input: BASE_URL + "/genres/netori", script: "gen.js" },
        { title: "Ngọt", input: BASE_URL + "/genres/ngot", script: "gen.js" },
        { title: "Non-hen", input: BASE_URL + "/genres/non-hen", script: "gen.js" },
        { title: "NTR", input: BASE_URL + "/genres/ntr", script: "gen.js" },
        { title: "Nun", input: BASE_URL + "/genres/nun", script: "gen.js" },
        { title: "Nurse", input: BASE_URL + "/genres/nurse", script: "gen.js" },

        // Nhóm O
        { title: "Office Lady", input: BASE_URL + "/genres/office-lady", script: "gen.js" },
        { title: "Old Man", input: BASE_URL + "/genres/old-man", script: "gen.js" },
        { title: "Oneshot", input: BASE_URL + "/genres/oneshot", script: "gen.js" },
        { title: "Oral", input: BASE_URL + "/genres/oral", script: "gen.js" },
        { title: "Osananajimi", input: BASE_URL + "/genres/osananajimi", script: "gen.js" },

        // Nhóm P
        { title: "Paizuri", input: BASE_URL + "/genres/paizuri", script: "gen.js" },
        { title: "Pantyhose", input: BASE_URL + "/genres/pantyhose", script: "gen.js" },
        { title: "Pegging", input: BASE_URL + "/genres/pegging", script: "gen.js" },
        { title: "Piercing", input: BASE_URL + "/genres/piercing", script: "gen.js" },
        { title: "Police", input: BASE_URL + "/genres/police", script: "gen.js" },
        { title: "Ponytail", input: BASE_URL + "/genres/ponytail", script: "gen.js" },
        { title: "Pregnant", input: BASE_URL + "/genres/pregnant", script: "gen.js" },
        { title: "Princess", input: BASE_URL + "/genres/princess", script: "gen.js" },

        // Nhóm R
        { title: "Rape", input: BASE_URL + "/genres/rape", script: "gen.js" },
        { title: "Rimjob", input: BASE_URL + "/genres/rimjob", script: "gen.js" },
        { title: "Romance", input: BASE_URL + "/genres/romance", script: "gen.js" },
        { title: "Ryona", input: BASE_URL + "/genres/ryona", script: "gen.js" },

        // Nhóm S
        { title: "Scat", input: BASE_URL + "/genres/scat", script: "gen.js" },
        { title: "School uniform", input: BASE_URL + "/genres/school-uniform", script: "gen.js" },
        { title: "SchoolGirl", input: BASE_URL + "/genres/schoolgirl", script: "gen.js" },
        { title: "Series", input: BASE_URL + "/genres/series", script: "gen.js" },
        { title: "Sex Toys", input: BASE_URL + "/genres/sex-toys", script: "gen.js" },
        { title: "Shimapan", input: BASE_URL + "/genres/shimapan", script: "gen.js" },
        { title: "Short", input: BASE_URL + "/genres/short", script: "gen.js" },
        { title: "Shota", input: BASE_URL + "/genres/shota", script: "gen.js" },
        { title: "Shoujo", input: BASE_URL + "/genres/shoujo", script: "gen.js" },
        { title: "Siscon", input: BASE_URL + "/genres/siscon", script: "gen.js" },
        { title: "Sister", input: BASE_URL + "/genres/sister", script: "gen.js" },
        { title: "Sixty-Nine", input: BASE_URL + "/genres/sixty-nine", script: "gen.js" },
        { title: "Slave", input: BASE_URL + "/genres/slave", script: "gen.js" },
        { title: "Sleeping", input: BASE_URL + "/genres/sleeping", script: "gen.js" },
        { title: "Small Boobs", input: BASE_URL + "/genres/small-boobs", script: "gen.js" },
        { title: "Soft Incest", input: BASE_URL + "/genres/soft-incest", script: "gen.js" },
        { title: "Son", input: BASE_URL + "/genres/son", script: "gen.js" },
        { title: "Spanking", input: BASE_URL + "/genres/spanking", script: "gen.js" },
        { title: "Sport", input: BASE_URL + "/genres/sport", script: "gen.js" },
        { title: "Squirting", input: BASE_URL + "/genres/squirting", script: "gen.js" },
        { title: "Stockings", input: BASE_URL + "/genres/stockings", script: "gen.js" },
        { title: "Strap-on", input: BASE_URL + "/genres/strap-on", script: "gen.js" },
        { title: "Succubus", input: BASE_URL + "/genres/succubus", script: "gen.js" },
        { title: "Supernatural", input: BASE_URL + "/genres/supernatural", script: "gen.js" },
        { title: "Sweating", input: BASE_URL + "/genres/sweating", script: "gen.js" },
        { title: "Swimsuit", input: BASE_URL + "/genres/swimsuit", script: "gen.js" },

        // Nhóm T
        { title: "Tail plug", input: BASE_URL + "/genres/tail-plug", script: "gen.js" },
        { title: "Tall Girl", input: BASE_URL + "/genres/tall-girl", script: "gen.js" },
        { title: "Teacher", input: BASE_URL + "/genres/teacher", script: "gen.js" },
        { title: "Tentacles", input: BASE_URL + "/genres/tentacles", script: "gen.js" },
        { title: "Threesome", input: BASE_URL + "/genres/threesome", script: "gen.js" },
        { title: "Time Stop", input: BASE_URL + "/genres/time-stop", script: "gen.js" },
        { title: "Tomboy", input: BASE_URL + "/genres/tomboy", script: "gen.js" },
        { title: "Tracksuit", input: BASE_URL + "/genres/tracksuit", script: "gen.js" },
        { title: "Transformation", input: BASE_URL + "/genres/transformation", script: "gen.js" },
        { title: "Trap", input: BASE_URL + "/genres/trap", script: "gen.js" },
        { title: "Truyện Việt", input: BASE_URL + "/genres/truyen-viet", script: "gen.js" },
        { title: "Tsundere", input: BASE_URL + "/genres/tsundere", script: "gen.js" },
        { title: "Tu Tiên", input: BASE_URL + "/genres/tu-tien", script: "gen.js" },
        { title: "Twins", input: BASE_URL + "/genres/twins", script: "gen.js" },
        { title: "Twintails", input: BASE_URL + "/genres/twintails", script: "gen.js" },

        // Nhóm U
        { title: "Underwater", input: BASE_URL + "/genres/underwater", script: "gen.js" },

        // Nhóm V
        { title: "Vampire", input: BASE_URL + "/genres/vampire", script: "gen.js" },
        { title: "Vanilla", input: BASE_URL + "/genres/vanilla", script: "gen.js" },
        { title: "Virgin", input: BASE_URL + "/genres/virgin", script: "gen.js" },
        { title: "Vtuber", input: BASE_URL + "/genres/vtuber", script: "gen.js" },

        // Nhóm W
        { title: "Webtoon", input: BASE_URL + "/genres/webtoon", script: "gen.js" },
        { title: "Wormhole", input: BASE_URL + "/genres/wormhole", script: "gen.js" },

        // Nhóm X
        { title: "X-ray", input: BASE_URL + "/genres/x-ray", script: "gen.js" },

        // Nhóm Y
        { title: "Yandere", input: BASE_URL + "/genres/yandere", script: "gen.js" },
        { title: "Yaoi", input: BASE_URL + "/genres/yaoi", script: "gen.js" },
        { title: "Yuri", input: BASE_URL + "/genres/yuri", script: "gen.js" },

        // Nhóm Z
        { title: "Zombie", input: BASE_URL + "/genres/zombie", script: "gen.js" }
    ]);
}