load("config.js");

function execute(input) {
    let url = input.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    // if (!url.endsWith("/")) {
    //     url += "/";
    // }
    let response = fetch(url);

    if (response.ok) {
        let html = response.html();
        
        let name = html.select("h1").text().trim();
        let author = html.select("a[href*='/authors/']").map(a => a.text().trim().replace(/\s*\d+\s*$/g, "")).join(" / ");
        let cover = html.select("img[alt*='Bìa truyện']").attr("src");
        let detail = "Cập nhật:" + html.select("time.text-txt-primary").text().trim() + "<br>" 
                   + "Lượt xem: " + html.select("span[title*='Lượt xem']").text().trim();
        let description = html.select("h1 ~ div").html().trim() || "Bạn đang đọc truyện " + name + " tại HentaiVina.";
        let ongoing = html.select("div.grid:contains(Tình trạng)").text().includes("Đang tiến hành");
        
        let suggests = [];
        html.select("a[href*='/authors/']").forEach(suggest => {
            let suggestTitle = "Cùng tác giả: " + suggest.text().replace(/\s*\d+\s*$/g, "").trim();
            let suggestLink = BASE_URL + suggest.attr("href") + "?nameStory=" + encodeURIComponent(name);
            if (suggestTitle && suggestLink) {
                suggests.push({ title: suggestTitle, input: suggestLink, script: "suggest.js" });
            }
        });

        let genres = [];
        html.select("a[href*='/genres/']").forEach(genre => {
            let genreTitle = genre.text().trim();
            let genreLink = BASE_URL + genre.attr("href");
            if (genreTitle) {
                genres.push({ title: genreTitle, input: genreLink, script: "gen.js" });
            }
        });
        html.select("a[href*='/authors/']").forEach(author => {
            let authorTitle = "Tác giả: " + author.text().replace(/\s*\d+\s*$/g, "").trim();
            let authorLink = BASE_URL + author.attr("href") + "?nameStory=" + encodeURIComponent(name);
            if (authorTitle && authorLink) {
                genres.push({ title: authorTitle, input: authorLink, script: "gen.js" });
            }
        });
        
        if (name) {
            return Response.success({
                name: name,
                author: author,
                cover: cover,
                detail: detail,
                description: description,
                ongoing: ongoing,
                suggests: suggests,
                genres: genres,
                host: BASE_URL
            });
        }
    }
    
    return Response.error("Không thể tải thông tin truyện.");
}
