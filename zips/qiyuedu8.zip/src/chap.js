function execute(url) {
    const cookie = "user_account=L3RNPSnEkxbTKyeQYS6wBTlvpqk6n1aTQakzV6o7x2AmiO83sNvgCs9v%2FnG6XeFT%2FImzzY%2B%2BLBb8slQnxJZ%2ByXxsQlXlcDSnUAxL4%2F9%2FSYsZ8se6X2IgwBjPSPhx; user_nickname=%E8%BA%BA%E5%A7%90%E5%A7%90%E6%80%80%E9%87%8C%E5%93%AD";
    
    let response = fetch(url, {
        headers: {
            "cookie": cookie,
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36",
            "Referer": "https://novel.qiyuedu8.top/"
        }
    });

    if (!response.ok) return Response.error("Failed to load chapter content");

    let json = response.json();
    if (!json || !json.data || !json.data.chapter || !json.data.chapter.content) {
        return Response.error("No chapter content found");
    }

    let content = json.data.chapter.content;
    
    content = content
        .replace(/<br\s*\/?>/gi, "\n")
        .replace(/&nbsp;/g, " ")
        .replace(/&amp;/g, "&")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'")
        .trim();

    return Response.success(content);
}
