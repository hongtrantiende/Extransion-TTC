function execute() {
    return Response.success([
        { title: "最新入库", input: "https://novel.qiyuedu8.top/module/novel/toplist.php?tid=0&type=1&limit=20&pt=wap", script: "gen.js" },
        { title: "最多点击", input: "https://novel.qiyuedu8.top/module/novel/toplist.php?tid=0&type=2&limit=20&pt=wap", script: "gen.js" },
        { title: "最多收藏", input: "https://novel.qiyuedu8.top/module/novel/toplist.php?tid=0&type=7&limit=20&pt=wap", script: "gen.js" },
        { title: "最多推荐", input: "https://novel.qiyuedu8.top/module/novel/toplist.php?tid=0&type=12&limit=20&pt=wap", script: "gen.js" },
        { title: "玄幻·奇幻", input: "https://novel.qiyuedu8.top/module/novel/type.php?tid=1&process=0&word=0&chapter=0&copy=0&cost=0&letter=0&order=0&pt=wap", script: "gen.js" },
        { title: "武侠·仙侠", input: "https://novel.qiyuedu8.top/module/novel/type.php?tid=2&process=0&word=0&chapter=0&copy=0&cost=0&letter=0&order=0&pt=wap", script: "gen.js" },
        { title: "都市·言情", input: "https://novel.qiyuedu8.top/module/novel/type.php?tid=3&process=0&word=0&chapter=0&copy=0&cost=0&letter=0&order=0&pt=wap", script: "gen.js" },
        { title: "历史·军事", input: "https://novel.qiyuedu8.top/module/novel/type.php?tid=4&process=0&word=0&chapter=0&copy=0&cost=0&letter=0&order=0&pt=wap", script: "gen.js" },
        { title: "科幻·网游", input: "https://novel.qiyuedu8.top/module/novel/type.php?tid=9&process=0&word=0&chapter=0&copy=0&cost=0&letter=0&order=0&pt=wap", script: "gen.js" },
        { title: "恐怖·灵异", input: "https://novel.qiyuedu8.top/module/novel/type.php?tid=10&process=0&word=0&chapter=0&copy=0&cost=0&letter=0&order=0&pt=wap", script: "gen.js" },
        { title: "同人·其它", input: "https://novel.qiyuedu8.top/module/novel/type.php?tid=11&process=0&word=0&chapter=0&copy=0&cost=0&letter=0&order=0&pt=wap", script: "gen.js" }
    ]);
}
