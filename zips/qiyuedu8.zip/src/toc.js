function execute(url) {
    const cookie = "user_account=L3RNPSnEkxbTKyeQYS6wBTlvpqk6n1aTQakzV6o7x2AmiO83sNvgCs9v%2FnG6XeFT%2FImzzY%2B%2BLBb8slQnxJZ%2ByXxsQlXlcDSnUAxL4%2F9%2FSYsZ8se6X2IgwBjPSPhx; user_nickname=%E8%BA%BA%E5%A7%90%E5%A7%90%E6%80%80%E9%87%8C%E5%93%AD";
    
    let nidMatch = url.match(/nid=(\d+)/);
    let tidMatch = url.match(/tid=(\d+)/);
    let nid = nidMatch ? nidMatch[1] : "";
    let tid = tidMatch ? tidMatch[1] : "";

    let response = fetch(url, {
        headers: {
            "cookie": cookie,
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36",
            "Referer": "https://novel.qiyuedu8.top/"
        }
    });

    if (!response.ok) return Response.error("Failed to load table of contents");

    let json = response.json();
    if (!json || !json.data || !json.data.list) return Response.error("No chapters found");

    let list = json.data.list;
    let data = [];

    list.forEach(function(item) {
        data.push({
            name: item.name,
            url: "https://novel.qiyuedu8.top/module/novel/read.php?tid=" + tid + "&nid=" + nid + "&cid=" + item.chapterId + "&pt=wap"
        });
    });

    return Response.success(data);
}
