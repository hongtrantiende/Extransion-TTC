load('config.js');
function execute(url) {
    var doc = fetch(url).html();
    var el = doc.select(".comics-chapters > a")
    const data = [];
    for (var i = el.size() - 1; i >= 0; i--) {
        var e = el.get(i);
        data.push({
            name: e.text(),
            url: e.attr("href"),
            host: BASE_URL
        })
    }
    data.reverse();
    return Response.success(data);
}