let BASE_URL = 'https://www.h0g2e.top/enter/index.html';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}