let BASE_URL = 'https://tuoitre.vn/tto-nld.htm';

try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}