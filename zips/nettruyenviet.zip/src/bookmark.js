load("config.js");

function execute(url, page) {
    if (!page) page = "1";
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL) + "?page=" + page;
    if (url.slice(-1) === "/") {
        url = url.slice(0, -1);
    }
    let response = fetch(url);

    let currentUrl = response.url;
    if (currentUrl.indexOf("Login") !== -1){
        return Response.error("Vui lòng đăng nhập để xem truyện đang theo dõi!");
    }

    if (response.ok) {
        let html = response.html();
        let storyList = [];

        let elements = html.select("div.table-responsive tbody tr");
        elements.forEach(function(e) {
            let name = e.select("a").get(1).text().trim();
            let link = e.select("a").get(1).attr("href");
            let cover = e.select("img").attr("data-original");
            let description = e.select("td.nowrap.chapter a").last().text().trim() + " - " + e.select("time.time").last().text().trim();
            if (name) {
                storyList.push({
                    name: name,
                    link: link,
                    cover: cover,
                    description: description,
                    host: BASE_URL
                });
            }

        });

        let next = null;
        let nextBtn = html.select("a.page-link[rel=next]").attr("href");
        if (nextBtn) {
            next = (parseInt(page) + 1).toString();
        }

        if (storyList.length == 0) {
            return Response.error("Bạn chưa theo dõi truyện nào.");
        }

        return Response.success(storyList, next);
    }
    
    return Response.error("Không thể tải danh sách truyện.");
}
