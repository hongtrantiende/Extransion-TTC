load("config.js");

function execute(url, page) {
    if (!page) page = "1";
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    if (url.slice(-1) !== "/") {
        url = url + "/";
    }
    let comicId = getComicId(url);
    let api = BASE_URL + "/api/comments/list?commentable_type=comics&commentable_id=" + comicId + "&page=" + page;
    let response = fetch(api);

    if (response.ok) {
        let json = response.json();
        let commentList = [];

        let parents = json.comments;
        parents.forEach(function(parent) {
            let parentName = parent.commenter.name ;
            let parentContent = parent.content;
            let parentDescription = formatTime(parent.created_at);
            if (parentName) {
                commentList.push({
                    name: parentName,
                    content: parentContent,
                    description: parentDescription
                });
            }

            let replies = parent.children;
            replies.forEach(function(reply) {
                let replyName = reply.commenter.name;
                let replyContent = reply.content;
                let replyDescription = formatTime(reply.created_at) + "\nTrả lời: " + parentName + "\n\"" + parentContent + "\"";
                if (replyName) {
                    commentList.push({
                        name: replyName,
                        content: replyContent,
                        description: replyDescription
                    });
                }
            });
        });

        let next = null;
        if (commentList.length > 0) {
            next = (parseInt(page) + 1).toString();
        }
        
        return Response.success(commentList, next);
    }

    return null;
}

function getComicId(url) {
    let response = fetch(url);
    if (!response.ok) return null;

    let html = response.html();
    let id = html.select("#comment-wrapper").attr("data-id");
    return id ? id.trim() : null;
}

function formatTime(t) {
    if (!t) return "";

    let past = new Date(t.replace(" ", "T"));
    let now = new Date();

    let diff = Math.floor((now - past) / 1000);

    if (diff < 60) {
        return diff + " giây trước";
    }

    let minutes = Math.floor(diff / 60);
    if (minutes < 60) {
        return minutes + " phút trước";
    }

    let hours = Math.floor(minutes / 60);
    if (hours < 24) {
        return hours + " giờ trước";
    }

    let days = Math.floor(hours / 24);
    if (days < 30) {
        return days + " ngày trước";
    }

    let months = Math.floor(days / 30);
    if (months < 12) {
        return months + " tháng trước";
    }

    let years = Math.floor(months / 12);
    return years + " năm trước";
}