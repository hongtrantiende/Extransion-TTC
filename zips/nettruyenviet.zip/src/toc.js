load("config.js");

function execute(url) {
    let slug = url.match(/\/truyen-tranh\/([^\/?#]+)/i)[1];
    let api = BASE_URL + "/Comic/Services/ComicService.asmx/ChapterList?slug=" + slug;
    let response = fetch(api);

    if (response.ok) {
        let json = response.json();
        let chapList = [];

        json.data.forEach(function(d) {
            chapList.push({
                name: d.chapter_name,
                url: "/truyen-tranh/" + slug + "/" + d.chapter_slug,
                host: BASE_URL
            });
        });
        
        chapList.reverse();
        return Response.success(chapList);
    }

    return Response.error("Không thể tải danh sách chương.");
}
