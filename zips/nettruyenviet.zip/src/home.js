load("config.js");

function execute() {
    return Response.success([
        { title: "Mới Cập Nhật", input: BASE_URL + "/tim-truyen?status=", script: "gen.js" },
        { title: "Truyện Hoàn Thành", input: BASE_URL + "/tim-truyen?status=2", script: "gen.js" },
        { title: "Truyện Mới", input: BASE_URL + "/tim-truyen?status=&sort=15", script: "gen.js" },
        { title: "Top All", input: BASE_URL + "/tim-truyen?status=&sort=10", script: "gen.js" },
        { title: "Top Tháng", input: BASE_URL + "/tim-truyen?status=&sort=11", script: "gen.js" },
        { title: "Top Tuần", input: BASE_URL + "/tim-truyen?status=&sort=12", script: "gen.js" },
        { title: "Top Ngày", input: BASE_URL + "/tim-truyen?status=&sort=13", script: "gen.js" },
        { title: "Truyện Theo Dõi", input: BASE_URL + "/Secure/ComicFollowed.aspx", script: "bookmark.js" }
    ]);
}
