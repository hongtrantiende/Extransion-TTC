load("config.js");

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    if (url.slice(-1) !== "/") {
        url = url + "/";
    }
    let response = fetch(url);

    if (response.ok) {
        let html = response.html();

        let name = html.select("h1.title-detail").last().text().trim();
        let author = html.select("li.author a").text().trim();
        let cover = html.select(".detail-info img").attr("data-src");
        let detail = "Số chương: " + html.select(".list-info li:contains(Số chương) .col-xs-8").text().trim() + "<br>"
                   + "Năm phát hành: " + html.select(".list-info li:contains(Năm phát hành) .col-xs-8").text().trim() + "<br>"
                   + "Cập nhật cuối: " + html.select(".list-info li:contains(Cập nhật cuối) .col-xs-8").text().trim() + "<br>"
                   + "Lượt xem: " + html.select(".list-info li:contains(Lượt xem) .col-xs-8").text().trim() + "<br>" 
                   + "Lượt theo dõi: " + html.select(".number_follow").text().trim() + "<br>" 
                   + "Lượt đánh giá: " + formatNumber(Number(html.select("[itemprop=ratingCount]").text().trim())) + "<br>"
                   + "Xếp hạng: " + html.select("[itemprop=bestRating]").text().trim() + "/5";
        let description = html.select(".detail-content div[style*='padding-top']").get(4).html();
        let ongoing = !html.select("li.status").text().includes("Hoàn thành");
        let suggests = [{title: "Truyện đề cử", input: BASE_URL, script: "suggest.js"}];
        let comments = [{title: "Bình luận", input: url, script: "comment.js"}];
        let genres = [];
        html.select(".list-info li.kind a").forEach(e => {
            genres.push({ title: e.text(), input: e.attr("href") + "?", script: "gen.js" });
        });

        if (name) {
            return Response.success({
                name: name,
                author: author,
                cover: cover,
                detail: detail,
                description: description,
                ongoing: ongoing,
                suggests: suggests,
                comments: comments,
                genres: genres,
                host: BASE_URL
            });
        }
    }

    return Response.error("Không thể tải thông tin truyện.");
}

function formatNumber(n){
    return n.toString().replace(/\B(?=(\d{3})+(?!\d))/g,".");
}