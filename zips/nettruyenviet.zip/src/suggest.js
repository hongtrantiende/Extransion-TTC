load("config.js");

function execute(url, page) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    if (url.slice(-1) !== "/") {
        url = url + "/";
    }
    let response = fetch(url);

    if (response.ok) {
        let html = response.html();
        let storyList = [];

        let elements = html.select(".top-comics .item");
        elements.forEach(function(e) {
            let name = e.select("h3 a").text().trim();
            let link = e.select("h3 a").attr("href");
            let cover = e.select("img").attr("data-original");
            let description = e.select("a[title*=Chapter]").text().trim();
            if (name) {
                storyList.push({
                    name: name,
                    link: link,
                    cover: cover,
                    description: description,
                    host: BASE_URL
                });
            }
        });

        storyList.sort(function(){ return 0.5 - Math.random(); });
        storyList = storyList.slice(0, 8);
        return Response.success(storyList);
    }
    
    return null;
}