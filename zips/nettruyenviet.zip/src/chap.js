load("config.js");

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    if (url.slice(-1) !== "/") {
        url = url + "/";
    }
    let response = fetch(url);

    if (response.ok) {
        let html = response.html();
        let data = [];
        
        let elements = html.select(".page-chapter img:not([alt*='Banner']):not([alt*='Notice'])");
        elements.forEach(function(e) {
            let link = e.attr("data-src") || e.attr("src");
            let fallback = [e.attr("data-sv1"), e.attr("data-sv2")];
            data.push({
                link: link,
                fallback: fallback
            });
        });

        if (data.length > 0) {
        return Response.success(data);
        }
    }

    return Response.error("Không thể tải nội dung chương.");
}
