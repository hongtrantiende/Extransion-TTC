load("config.js");

function execute(key, page) { 
    if (!page) page = "1";
    let url = BASE_URL + "/tim-truyen?keyword=" + encodeURIComponent(key) + "&page=" + page;
    if (url.slice(-1) !== "/") {
        url = url + "/";
    }
    let response = fetch(url);

    if (response.ok) {
        let html = response.html();
        let storyList = [];

        let elements = html.select(".items .item");
        elements.forEach(function(e) {
            let name = e.select("h3 a").text().trim();
            let link = e.select("h3 a").attr("href");
            let cover = e.select("img").attr("data-original");
            let description = e.select("a[title*='Chapter']").first().text().trim();
            if (name) {
                storyList.push({
                    name: name,
                    link: link,
                    cover: cover,
                    description: description,
                    host: BASE_URL
                });
            }
        });

        let next = null;
        let nextBtn = html.select("a.page-link[rel=next]").attr("href");
        if (nextBtn) {
            next = (parseInt(page) + 1).toString();
        }

        return Response.success(storyList, next);
    }

    return Response.error("Không tìm thấy kết quả.");
}
