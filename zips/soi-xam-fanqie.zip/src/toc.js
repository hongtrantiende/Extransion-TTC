load("config.js");
load("function.js");
load("crypto.js");

function execute(input) {
    if (input.includes("/truyen/fanqie/")) {
        let match = input.match(/fanqie\/\d+\/(\d+)/);
        if (match) {
            input = "?book_id=" + encodeBase64(match[1]);
        }
    }
    else if (input.includes("fanqienovel.com/page/")) {
        let match = input.match(/page\/(\d+)/);
        if (match) {
            input = "?book_id=" + encodeBase64(match[1]);
        }
    }

    let bookId = getParam(input, "book_id");
    let rawBookId = bookId;
    if (/[a-zA-Z]/.test(bookId) && bookId.length > 10) {
        try {
            rawBookId = decodeBase64(bookId);
        } catch(e) {}
    }

    let api = "https://fanqienovel.com/api/reader/directory/detail?bookId=" + rawBookId;
    let response = fetch(api);

    if (response.ok) {
        let json = response.json();
        let chapList = [];

        if (json && json.data && json.data.chapterListWithVolume) {
            let volumes = json.data.chapterListWithVolume;
            volumes.forEach(function(volume) {
                if (Array.isArray(volume)) {
                    volume.forEach(function(item) {
                        let itemId = item.itemId || item.item_id;
                        if (itemId) {
                            let name = item.title;
                            let link = BASE_URL + "/online_reader?book_id=" + bookId + "&book_id1=" + bookId + "&book_id2=" + bookId + "&source=番茄&tab=小说&item_id=" + itemId;
                            chapList.push({
                                name: name,
                                url: link,
                                host: BASE_URL
                            });
                        }
                    });
                }
            });
        }
        
        if (chapList.length === 0) {
            return Response.error("Mục lục trống hoặc không thể phân tích.");
        }

        return Response.success(chapList);
    }

    return Response.error("Không thể tải danh sách chương.");
}