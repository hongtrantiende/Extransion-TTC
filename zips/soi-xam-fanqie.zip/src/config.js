let BASE_URL = "https://api.langge.cf";
// let BASE_URL = "https://v5.czyl.cf";

try {
    if (typeof config_url !== "undefined") {
        if (config_url != "null") {
            BASE_URL = config_url;
        }
    }
} catch (error) {}

try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {}

// ======================User=========================
// let USER_EMAIL = "";
// let USER_PASSWORD = "";

// try {
//     if (typeof user_email !== "undefined" && typeof user_password !== "undefined") {
//         if (user_email && user_password && user_email != "null" && user_password != "null") {
//             USER_EMAIL = user_email;
//             USER_PASSWORD = user_password;
//         }
//     }
// } catch (error) {}
