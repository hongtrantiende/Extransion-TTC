load("config.js");

function execute() {
    return Response.success([
        { title: "Top Đỉnh Cao", input: BASE_URL + "/get_discover?source=番茄&tab=小说&bdtype=巅峰榜&gender=1&is_ranking=1", script: "gen.js" },
        { title: "Top Đề Cử", input: BASE_URL + "/get_discover?source=番茄&tab=小说&bdtype=推荐榜&gender=1&is_ranking=1", script: "gen.js" },
        { title: "Top Tìm Kiếm", input: BASE_URL + "/get_discover?source=番茄&tab=小说&bdtype=热搜榜&gender=1&is_ranking=1", script: "gen.js" },
        { title: "Top Hắc Mã", input: BASE_URL + "/get_discover?source=番茄&tab=小说&bdtype=黑马榜&gender=1&is_ranking=1", script: "gen.js" },
        { title: "Top Cập Nhật", input: BASE_URL + "/get_discover?source=番茄&tab=小说&bdtype=爆更榜&gender=1&is_ranking=1", script: "gen.js" },
    ]);
}