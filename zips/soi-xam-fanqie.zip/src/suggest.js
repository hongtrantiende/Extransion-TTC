load("config.js");
load("function.js");
load("crypto.js");

function execute(input) {
    let book_id = getParam(input, "book_id");
    let api = input.replace(/\&book_id=\d+/, "");
    let response = fetch(api);
    
    if (response.ok) {
        let json = response.json();
        let storyList = [];

        if (json.data) {
            let stories = json.data.author_book_info;
            stories.forEach(function(story) {
                let name = story.book_name;
                let link = BASE_URL + "/online_detail?book_id=" + encodeBase64(story.book_id) + "&source=%E7%95%AA%E8%8C%84&tab=%E5%B0%8F%E8%AF%B4";
                let cover = story.thumb_url;
                let description = story.category;
                if (story.book_id != book_id) {
                    storyList.push({
                        name: name,
                        link: link,
                        cover: cover,
                        description: description,
                        host: BASE_URL
                    });
                }
            });
        }
        
        return Response.success(storyList);
    }

    return null;
}