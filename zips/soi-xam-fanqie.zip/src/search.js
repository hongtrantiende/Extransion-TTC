load("config.js");
load("function.js");
load('crypto.js');

function execute(key, page) { 
    if (!page) page = "1";
    let api = BASE_URL + "/search?title=" + key + "&source=番茄&tab=小说&page=" + page; 
    let response = fetch(api);

    if (response.ok) {
        let json = response.json();
        // console.log(JSON.stringify(json, null, 2));
        let storyList = [];

        if (json.data) {
            let stories = json.data;
            stories.forEach(function(story) {
                let name = story.book_name;
                let link = BASE_URL + "/online_detail?book_id=" + story.book_id + "&source=%E7%95%AA%E8%8C%84&tab=%E5%B0%8F%E8%AF%B4";
                let cover = story.thumb_url;
                let description = convertName(story.author);
                if (story.status) {
                    storyList.push({
                        name: name,
                        link: link,
                        cover: cover,
                        description: description,
                        host: BASE_URL
                    });
                }
            });

            let next = null;
            if (parseInt(page) <= 5) {
                next = (parseInt(page) + 1).toString();
            }

            return Response.success(storyList, next);
        }
    }

    return Response.error("Không tìm thấy kết quả.");
}
