load("config.js");
load("function.js");
load("crypto.js");

function execute(input) {
    if (input.includes("/truyen/fanqie/")) {
        let match = input.match(/fanqie\/\d+\/(\d+)/);
        if (match) {
            let bookId = encodeBase64(match[1]);
            input = "?book_id=" + bookId;
        }
    }
    else if (input.includes("fanqienovel.com/page/")) {
        let match = input.match(/page\/(\d+)/);
        if (match) {
            let bookId = encodeBase64(match[1]);
            input = "?book_id=" + bookId;
        }
    }

    let bookId = getParam(input, "book_id");
    let source = "番茄";
    let tab = "小说"

    let api = BASE_URL + "/detail?" 
            + "book_id=" + bookId
            + "&source=" + source
            + "&tab=" + tab; 
    let response = fetch(api);

    if (response.ok) {
        let json = response.json();
        // console.log(JSON.stringify(json, null, 2));
        let data = json.data;

        if (data) {
            let name = data.book_name;
            let author = convertName(data.author);
            let cover = data.thumb_url;
            let detail = "Điểm: " + data.score + "<br>"
                       + "Số lượng từ: " + data.word_number + "<br>"
                       + "Lượt đọc (Fanqie): " + formatNumber(data.read_count) + "<br>"
                    //    + "Tổng lượt đọc: " + formatNumber(data.read_count_all) + "<br>"
                       + "Nhân vật chính: " + convertName(data.role) + "<br>"
                       + "Cập nhật lần cuối: " + timeAgo(data.last_chapter_update_time) + "<br>"
                       + "Chương mới nhất: " + data.last_chapter_title;
            let description = data.abstract.replace(/\r?\n/g, "<br>");
            let ongoing = !data.status.includes("已完结");
            let link = BASE_URL + "/online_detail?book_id=" + data.book_id + "&source=%E7%95%AA%E8%8C%84&tab=%E5%B0%8F%E8%AF%B4";
            let { genres, suggests } = getGenresAndSuggests(bookId);
            let comments = [{
                title: "Bình luận (Nhiều yêu thích)",
                input: BASE_URL + "/book_review?book_id=" + bookId +"&source=番茄&tab=小说&count=20",
                script: "comment.js"
            }];

            

            return Response.success({
                name: name,
                author: author,
                cover: cover,
                detail: detail,
                description: description,
                ongoing: ongoing,
                url: link,
                genres: genres,
                suggests: suggests,
                comments: comments,
                host: BASE_URL
            });
        }
    }

    return Response.error("Không thể tải thông tin truyện.");
}
