load("config.js");
load("function.js");

function execute(input, page) {
    if (!page) page = "1";
    let api = input + "&page=" + page;
    let response = fetch(api);

    if (response.ok) {
        let json = response.json();
        let storyList = [];
        
        if (json.data) {
            let stories = json.data;
            stories.forEach(function(story) {
                let name = story.book_name;
                let link = BASE_URL + "/online_detail?book_id=" + story.book_id + "&source=%E7%95%AA%E8%8C%84&tab=%E5%B0%8F%E8%AF%B4";
                let cover = story.thumb_url;
                let description = convertName(story.author);
                storyList.push({
                    name: name,
                    link: link,
                    cover: cover,
                    description: description,
                    host: BASE_URL
                });
            });
        }

        let next = null;
        if (input.indexOf("is_ranking=") === -1) {
            if (parseInt(page) < 15) {
                next = (parseInt(page) + 1).toString();
            }
        }

        return Response.success(storyList, next);
    }

    return Response.error("Không thể tải danh sách truyện.");
}