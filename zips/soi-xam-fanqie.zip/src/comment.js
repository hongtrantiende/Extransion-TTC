load('config.js');
load("function.js");

function execute(input, offset) {
    if (!offset) offset = "0"
    let api = input + "&offset=" + offset;

    let response = fetch(api);
    if (response.ok) {
        let json = response.json();
        let comments = [];

        let commentList = json.data.comment;
        commentList.forEach(function(comment) {
            let score = Math.round(comment.score / 2);
            let star = "⭐".repeat(score) + '☆'.repeat(5 - score);
            let mainComment = star + "&nbsp;".repeat(17) + comment.digg_count + "❤️  " + comment.reply_count + "💬 <br>" + comment.text.replace(/\n/g, "<br>");
            let additionComment = "";
            if (comment.addition_comment) {
                let additionScore = Math.round(comment.addition_comment.score / 2);
                let additionStar = "⭐".repeat(additionScore) + '☆'.repeat(5 - additionScore);
                additionComment = "<br>\u200B<br>✍️Đánh Giá Lại✍️<br>" + additionStar + "<br>" + comment.addition_comment.text.replace(/\n/g, "<br>");
            }
            comments.push({
                name: convertName(comment.user_info.user_name),
                content: mainComment + additionComment,
                description: timeAgoFromTimestamp(comment.create_timestamp),
                avatar: comment.user_info.user_avatar
            });
        });

        let next = null;
        if (json.data.has_more) {
            next = json.data.next_offset.toString()
        } else if (offset == "0" && comments.length > 0) {
            next = "20";
        }
        return Response.success(comments, next);
    }
    
    return null;
}