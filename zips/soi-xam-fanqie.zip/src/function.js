function getParam(input, name) {
    let match = input.match(new RegExp("[?&]" + name + "=([^&]+)"));
    return match ? decodeURIComponent(match[1]) : "";
}

function replaceCover(url) {
    if (!url) return url;
    let clean = url.replace(/^https?:\/\//, "");
    let parts = clean.split("/");
    parts[0] = "https://i0.wp.com/p6-novel.byteimg.com/origin";

    let result = parts.map(function(p) {
        if (p.includes("?") || p.includes("~")) {
            return p.split("~")[0];
        }
        return p;
    });

    return result.join("/");
}

function formatTime(timeStr) {
    if (!timeStr) return "";

    let date = new Date(timeStr.replace(" ", "T"));

    let day = String(date.getDate()).padStart(2, "0");
    let month = String(date.getMonth() + 1).padStart(2, "0");
    let year = date.getFullYear();
    let hour = String(date.getHours()).padStart(2, "0");
    let minute = String(date.getMinutes()).padStart(2, "0");
    let second = String(date.getSeconds()).padStart(2, "0");

    return `${day}/${month}/${year} ${hour}:${minute}:${second}`;
}

function formatChineseDate(timestamp) {
    const date = new Date(timestamp * 1000);

    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");

    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    const seconds = String(date.getSeconds()).padStart(2, "0");

    return `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
}

function timeAgo(timeStr) {
    let date = new Date(timeStr.replace(" ", "T"));

    date.setHours(date.getHours() - 1);

    let now = new Date();
    let diff = Math.floor((now - date) / 1000);

    if (diff < 60) return diff + " giây trước";

    let minutes = Math.floor(diff / 60);
    if (minutes < 60) return minutes + " phút trước";

    let hours = Math.floor(minutes / 60);
    if (hours < 24) return hours + " giờ trước";

    let days = Math.floor(hours / 24);
    if (days < 30) return days + " ngày trước";

    let months = Math.floor(days / 30);
    if (months < 12) return months + " tháng trước";

    let years = Math.floor(months / 12);
    return years + " năm trước";
}

function timeAgoFromTimestamp(ts) {
    if (ts.toString().length === 10) {
        ts = ts * 1000;
    }

    let now = Date.now();
    let diff = Math.floor((now - ts) / 1000);

    if (diff < 60) return diff + " giây trước";

    let minutes = Math.floor(diff / 60);
    if (minutes < 60) return minutes + " phút trước";

    let hours = Math.floor(minutes / 60);
    if (hours < 24) return hours + " giờ trước";

    let days = Math.floor(hours / 24);
    if (days < 30) return days + " ngày trước";

    let months = Math.floor(days / 30);
    if (months < 12) return months + " tháng trước";

    let years = Math.floor(months / 12);
    return years + " năm trước";
}

function formatNumber(num) {
    num = String(num);
    return num.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function capitalizeWords(text) {
    if (!text) return "";
    
    let str = (text + "").toLowerCase();
    
    return str.replace(/^.|\s\S/g, function(match) {
        return match.toUpperCase();
    });
}

function convertName(name) {
    try {
        return capitalizeWords(Qt.translate(name , "hv").translateText);
    } catch (e) {
        return name;
    }
}

function encodeBase64(str) {
    return CryptoJS.enc.Base64.stringify(CryptoJS.enc.Utf8.parse(str)).replace(/=+$/, "");
}

function decodeBase64(str) {
    return CryptoJS.enc.Base64.parse(str).toString(CryptoJS.enc.Utf8);
}

function encodeBookId(id) {
    return encodeBase64(String(id)).replace(/=+$/, "");
}

function getGenresAndSuggests(book_id) {
    let result = {
        genres: [],
        suggests: []
    };

    try {
        if (!/^\d+$/.test(book_id)) {
            book_id = decodeBase64(book_id);
        }

        let url = "https://fanqienovel.com/page/" + book_id + "?force_mobile=1";
        let response = fetch(url);

        if (!response.ok) return result;

        let html = response.text();
        let match = html.match(/window\.__INITIAL_STATE__\s*=\s*(\{[\s\S]*?\});/);

        if (!match) return result;

        let state = JSON.parse(match[1].replace(/:\s*undefined/g, ':null'));
        let book_info = state.page;

        if (!book_info) return result;

        if (book_info.categoryV2) {
            let list = JSON.parse(book_info.categoryV2);

            list.forEach(function(e) {
                result.genres.push({
                    title: e.Name,
                    input: BASE_URL + "/get_discover?source=番茄&tab=小说&type=" + e.ObjectId + "&gender=1&genre_type=0",
                    script: "gen.js"
                });
            });
        }

        if (book_info.author && book_info.authorId) {
            result.suggests.push({
                title: "Cùng tác giả",
                input: "https://api5-normal-sinfonlinec.fqnovel.com/reading/user/basic_info/get/v?user_id=" + book_info.authorId + "&aid=1967&version_code=65532&book_id=" + book_id,
                script: "suggest.js"
            });
        }

    } catch (e) {
    }

    return result;
}

function translateText(text, fromLang, toLang) {
    try {
        if (!text) return text;

        let encodedText = encodeURIComponent(text);
        let url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${fromLang}&tl=${toLang}&dt=t&q=${encodedText}`;

        let response = fetch(url);
        if (!response.ok) return text;

        let json = response.json();
        let result = "";

        if (json && json[0]) {
            for (let i = 0; i < json[0].length; i++) {
                if (json[0][i][0]) {
                    result += json[0][i][0];
                }
            }
        }

        return result || text;
    } catch (e) {
        return text;
    }
}

// function logIn() {
//     try {
//         // console.log(BASE_URL);
//         let cookie = localStorage.getItem("cookie_" + BASE_URL) || "";
//         // console.log("Cookie hiện tại: " + cookie);
//         // console.log("Đang đăng nhập với email: " + USER_EMAIL);
//         // console.log("Đang đăng nhập với mật khẩu: " + USER_PASSWORD);
//         if (!cookie.includes("qttoken") && USER_EMAIL && USER_PASSWORD) {
//             let loginApi = BASE_URL + "/login_api";
//             let loginRes = fetch(loginApi, {
//                 method: "POST",
//                 headers: {
//                     "User-Agent": UserAgent.chrome(),
//                     "Referer": BASE_URL + "/",
//                     "Content-Type": "application/json",
//                 },
//                 body: JSON.stringify({
//                     "register_email": USER_EMAIL,
//                     "password": USER_PASSWORD,
//                 })
//             });
                
//             if (loginRes.ok) {
//                 loginRes = loginRes.json();
//                 console.log("Đăng nhập thành công, token: " + loginRes.key);
//                 localStorage.setItem("cookie_" + BASE_URL, "qttoken=" + loginRes.key);
//             }
//         }
//     } catch (e) {
//     }
// }

function getCookie() {
    var domains = [
        "https://v2.czyl.cf",
        "https://v4.czyl.cf",
        "https://v5.czyl.cf",
        "https://api.langge.cf"
    ];
    for (var i = 0; i < domains.length; i++) {
        try {
            var ck = localCookie.getCookie(domains[i]);
            if (ck && (ck.indexOf("qttoken") !== -1 || ck.indexOf("session") !== -1)) {
                return ck;
            }
        } catch (e) {}
    }
    try {
        let cookie = localCookie.getCookie();
        return cookie;
    } catch (e) {
        return "";
    }
}