load("config.js");
load("function.js");

function execute(input) {
    let itemId = getParam(input, "item_id");
    let cookie = getCookie();

    var SERVERS = [
        "https://v4.czyl.cf",
        "https://v5.czyl.cf",
        "https://v2.czyl.cf",
        "https://api.langge.cf"
    ];

    var startIdx = 0;
    try {
        var savedIdx = localStorage.getItem("dahuilang_server_idx");
        if (savedIdx !== null) {
            startIdx = parseInt(savedIdx, 10);
        }
    } catch (err) {}
    if (isNaN(startIdx) || startIdx < 0 || startIdx >= SERVERS.length) {
        startIdx = 0;
    }

    var lastErr = "";

    for (var attempt = 0; attempt < SERVERS.length; attempt++) {
        var currentIdx = (startIdx + attempt) % SERVERS.length;
        var baseServer = SERVERS[currentIdx];

        try {
            let fakeIp = (Math.floor(Math.random() * 254) + 1) + "." +
                         Math.floor(Math.random() * 255) + "." +
                         Math.floor(Math.random() * 255) + "." +
                         Math.floor(Math.random() * 255);

            let headers = {
                "User-Agent": UserAgent.chrome(),
                "Content-Type": "application/json",
                "X-Forwarded-For": fakeIp,
                "X-Real-IP": fakeIp,
                "Client-IP": fakeIp
            };
            if (cookie) {
                headers["Cookie"] = cookie;
            }

            let api = baseServer + "/content?review=1";
            let response = fetch(api, {
                method: "POST",
                headers: headers,
                body: JSON.stringify({
                    "item_id": itemId,
                    "source": "番茄",
                    "tab": "小说",
                    "version": "4.11.5.1"
                })
            });

            if (response.ok) {
                let json = response.json();

                if (json.code == -1) {
                    lastErr = "Server " + baseServer + " bị giới hạn: " + json.msg;
                    continue;
                }

                if (json.content) {
                    let content = json.content;

                    // Kiểm tra xem có phải cảnh báo giới hạn không
                    if (content.indexOf('免登录访问次数已达上限') !== -1 ||
                        content.indexOf('书源版本过低') !== -1 ||
                        content.indexOf('点击登录') !== -1 ||
                        content.indexOf('登录后刷新') !== -1) {
                        
                        lastErr = "Server " + baseServer + " trả về nội dung giới hạn.";
                        continue;
                    }

                    content = content
                        .replace(/<\/p>/g, "<br><br>")
                        .replace(/<p>/g, "")
                        .replace(/(&nbsp;)+/g, " ")
                        .replace(/&quot;/g, "\"")
                        .replace(/&#34;/g, "\"")
                        .replace(/(<br\s*\/?>\s*){2,}/g, "<br><br>")
                        .replace(/(^|<br>)([^<"]*)"([^<"]*)(?=<br>|$)/g, "$1$2$3")
                        .replace(/"([^"]+)"/g, "“$1”")
                        .trim();
                    content = content
                        .replace(/[\u200B-\u200F\u202A-\u202E\u2060\uFEFF]/g, "")
                        .replace(/<br[^>]*>(?!.*<br)[\s\S]*(?:q\s*q|大灰狼)[\s\S]*$/i, "");
                    
                    if (content) {
                        // Thành công! Lưu index server hoạt động
                        try {
                            localStorage.setItem("dahuilang_server_idx", currentIdx);
                        } catch (err) {}
                        
                        return Response.success(content);
                    }
                }
            }
            lastErr = "HTTP " + response.status + " từ " + baseServer;
        } catch (e) {
            lastErr = "Lỗi kết nối " + baseServer + ": " + e.message;
        }
    }

    // Nếu tất cả server đều bị giới hạn, hiển thị hướng dẫn đăng nhập
    var guideText = "⚠️ BẠN ĐÃ ĐỌC HẾT CÁC LƯỢT MIỄN PHÍ HÔM NAY (trên cả 4 server Sói Xám).\n\n"
        + "1. Mở TRÌNH DUYỆT ngay trong app vBook.\n"
        + "2. Truy cập địa chỉ: https://v2.czyl.cf/login\n"
        + "3. ĐĂNG NHẬP tài khoản SÓI XÁM (hoặc đổi mạng/VPN/4G để reset IP).\n"
        + "4. Quay lại app và LÀM MỚI CHƯƠNG để đọc tiếp.";
    return Response.success(guideText);
}