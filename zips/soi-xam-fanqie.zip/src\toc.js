load("config.js");
load("function.js");
load("crypto.js");

function execute(input) {
    if (input.includes("/truyen/fanqie/")) {
        let match = input.match(/fanqie\/\d+\/(\d+)/);
        if (match) {
            input = "?book_id=" + encodeBase64(match[1]);
        }
    }
    else if (input.includes("fanqienovel.com/page/")) {
        let match = input.match(/page\/(\d+)/);
        if (match) {
            input = "?book_id=" + encodeBase64(match[1]);
        }
    }

    let bookId = getParam(input, "book_id");
    let api = BASE_URL + "/catalog?" + "book_id=" + bookId + "&source=番茄&tab=小说";
    let response = fetch(api);

    if (response.ok) {
        let json = response.json();
        // console.log(JSON.stringify(json, null, 2));
        let chapList = [];

        if (json.data) {
            let items = json.data;
            items.forEach(function(item) {
                let name = item.title;
                let link = BASE_URL + "/online_reader?book_id=" + bookId + "&book_id1=" + bookId + "&book_id2=" + bookId + "&source=番茄&tab=小说&item_id=" + item.item_id;
                chapList.push({
                    name: name,
                    url: link,
                    host: BASE_URL
                });
            });
        }
        
        return Response.success(chapList);
    }

    return Response.error("Không thể tải danh sách chương.");
}