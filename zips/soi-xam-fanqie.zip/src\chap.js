load("config.js");
load("function.js");

function execute(input) {
    // console.log(BASE_URL);
    // logIn();
    let itemId = getParam(input, "item_id");
    let cookie = getCookie();
    // console.log("Cookie:" + cookie);
    let fakeIp = (Math.floor(Math.random() * 254) + 1) + "." +
                 Math.floor(Math.random() * 255) + "." +
                 Math.floor(Math.random() * 255) + "." +
                 Math.floor(Math.random() * 255);

    let headers = {
        "User-Agent": UserAgent.chrome(),
        "Content-Type": "application/json",
        "X-Forwarded-For": fakeIp,
        "X-Real-IP": fakeIp,
        "Client-IP": fakeIp
    };
    if (cookie) {
        headers["Cookie"] = cookie;
    }

    let api = BASE_URL + "/content?review=1";
    let response = fetch(api, {
        method: "POST",
        headers: headers,
        body: JSON.stringify({
            "item_id": itemId,
            "source": "番茄",
            "tab": "小说",
            "version": "4.11.5.1"
        })
    });
    // console.log("Cookie đã lấy:" + response.request.headers.cookie);

    if (response.ok) {
        let json = response.json();

        if (json.code == -1) {
            let fallbackRes = tryFetchDirectFanqie(itemId);
            if (fallbackRes) {
                return Response.success(fallbackRes);
            }
            return Response.error(translateText(json.msg, "zh-CN", "vi"));
        }

        if (json.content) {
            let content = json.content;
            content = content
                .replace(/<\/p>/g, "<br><br>")
                .replace(/<p>/g, "")
                .replace(/(&nbsp;)+/g, " ")
                .replace(/&quot;/g, "\"")
                .replace(/&#34;/g, "\"")
                .replace(/(<br\s*\/?>\s*){2,}/g, "<br><br>")
                .replace(/(^|<br>)([^<"]*)"([^<"]*)(?=<br>|$)/g, "$1$2$3")
                .replace(/"([^"]+)"/g, "“$1”")
                .trim();
            content = content
                .replace(/[\u200B-\u200F\u202A-\u202E\u2060\uFEFF]/g, "")
                .replace(/<br[^>]*>(?!.*<br)[\s\S]*(?:q\s*q|大灰狼)[\s\S]*$/i, "");
            
            if (content) {
                return Response.success(content);
            }
        }
    }

    return Response.error("Không thể tải nội dung chương.");
}

function tryFetchDirectFanqie(itemId) {
    try {
        let fallbackUrl = "http://101.35.133.34:5000/api/content?item_id=" + itemId + "&tab=小说";
        let res = fetch(fallbackUrl, {
            headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            }
        });
        if (res.ok) {
            let json = null;
            try {
                if (typeof res.json === "function") json = res.json();
                else json = JSON.parse(res.text());
            } catch (_) {}
            
            if (json && json.code === 200 && json.data && json.data.content) {
                let raw = json.data.content;
                return raw.split("\n").join("<br>");
            }
        }
    } catch (e) {
        // Mute fallback errors
    }
    return null;
}