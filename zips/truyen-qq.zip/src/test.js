load("config.js");

function execute(url, page) {
    if (!page) page = "1";

    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    if (url.slice(-1) === "/") {
        url = url.slice(0, -1);
    }
    url = url + "?page=" + page;

    logToServer("=== TEST COOKIE START ===");
    logToServer("URL: " + url);

    let response = fetch(url, {
        headers: {
            "user-agent": UserAgent.system(),
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "referer": BASE_URL + "/"
        }
    });

    logToServer("fetch " + url + " - status: " + response.status);
    logToServer("response.ok: " + response.ok);

    let setCookie = null;
    try {
        if (response.headers) {
            setCookie = response.headers["set-cookie"];
        } else {
            logToServer("response.headers is undefined");
        }
    } catch (e) {
        logToServer("read response.headers error: " + e);
    }

    logToServer("set-cookie raw: " + setCookie);

    let requestCookie = "";
    try {
        if (response.request && response.request.headers) {
            requestCookie = response.request.headers.cookie || "";
        } else {
            logToServer("response.request.headers is undefined");
        }
    } catch (e) {
        logToServer("request cookie read error: " + e);
    }
    logToServer("request cookie: " + requestCookie);

    let cfClearance = null;
    if (setCookie) {
        let match = setCookie.match(/cf_clearance=([^;]+)/);
        if (match) {
            cfClearance = match[1];
            logToServer("cf_clearance found: " + cfClearance);
        } else {
            logToServer("cf_clearance NOT found in set-cookie");
        }
    } else {
        logToServer("set-cookie is null/empty");
    }

    if (cfClearance) {
        let cookieHeader = "cf_clearance=" + cfClearance;
        logToServer("cookie header for request 2: " + cookieHeader);

        let response2 = fetch(url, {
            headers: {
                "user-agent": UserAgent.system(),
                "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "referer": BASE_URL + "/",
                "cookie": cookieHeader
            }
        });

        logToServer("request 2 status: " + response2.status);

        try {
            let html2 = response2.text();
            logToServer("request 2 html length: " + html2.length);
            if (html2.indexOf("Just a moment") !== -1) {
                logToServer("request 2 still hit Cloudflare");
            } else {
                logToServer("request 2 maybe passed Cloudflare");
            }
        } catch (e) {
            logToServer("request 2 read html error: " + e);
        }
    }

    logToServer("=== TEST COOKIE END ===");

    if (response.ok) {
        let doc = response.html();
        let storyList = [];

        let elements = doc.select(".listing .item");
        logToServer("elements size: " + elements.size());

        elements.forEach(function(e) {
            let name = e.select(".info a").first().text().trim();
            let link = e.select(".info a").first().attr("href");
            let cover = e.select(".cover img").attr("src");
            let description = e.select(".info .line").first().text().trim() + " - "
                            + e.select(".info .line").last().text().trim();

            if (name) {
                storyList.push({
                    name: name,
                    link: link,
                    cover: cover,
                    description: description,
                    host: BASE_URL
                });
            }
        });

        let next = null;
        let lastHref = doc.select(".pagination .btn-page").last().attr("href");
        if (lastHref.indexOf("page=") !== -1) {
            next = (parseInt(page) + 1).toString();
        }

        logToServer("storyList size: " + storyList.length);
        return Response.success(storyList, next);
    }

    return Response.error("Không thể tải danh sách truyện.");
}