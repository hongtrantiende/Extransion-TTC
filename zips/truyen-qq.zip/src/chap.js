load("config.js");
load("bypass.js");

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL) ;
    if (url.slice(-1) !== "/") {
        url = url + "/";
    }
    let response = fetch(url, {
        headers: {
            "user-agent": UserAgent.system(),
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "referer": BASE_URL + "/"
        }
    });

    if (!response.ok) {
        bypass(url);
        response = fetch(url, {
            headers: {
                "user-agent": UserAgent.system(),
                "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "referer": BASE_URL + "/"
            }
        });
    }

    if (response.ok) {
        let doc = response.html();
        let data = [];
        
        let elements = doc.select(".reading-content img");
        elements.forEach(function(e) {
            let link = e.attr("data-src") ||  e.attr("src");
            data.push({
                link: link,
                fallback: []
            });
        });

        if (data.length > 0) {
        return Response.success(data);
        }
    }

    return Response.error("Không thể tải nội dung chương.");
}
