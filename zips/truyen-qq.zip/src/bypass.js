function bypass(url) {
    let browser = Engine.newBrowser();
    browser.setUserAgent(UserAgent.android());
    browser.launch(url, 15000);
    sleep(8000);
    browser.close();
    return null;
}
