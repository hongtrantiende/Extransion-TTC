let BASE_URL = "https://truyenqq.com.vn";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {}
