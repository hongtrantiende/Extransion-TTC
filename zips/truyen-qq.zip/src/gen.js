load("config.js");
load("bypass.js");

function execute(url, page) {
    if (!page) page = "1";
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL) + "?page=" + page;
    if (url.slice(-1) === "/") {
        url = url.slice(0, -1);
    }
    let response = fetch(url, {
        headers: {
            "user-agent": UserAgent.system(),
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "referer": BASE_URL + "/"
        }
    });

    if (!response.ok) {
        bypass(url);
        response = fetch(url, {
            headers: {
                "user-agent": UserAgent.system(),
                "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "referer": BASE_URL + "/"
            }
        });
    }

    if (response.ok) {
        let doc = response.html();
        let storyList = [];
        
        let elements = doc.select(".listing .item");
        elements.forEach(function(e) {
            let name = e.select(".info a").first().text().trim();
            let link = e.select(".info a").first().attr("href");
            let cover = e.select(".cover img").attr("src");
            let description = e.select(".info .line").first().text().trim() + " - " 
                            + e.select(".info .line").last().text().trim();
            if (name) {
                storyList.push({
                    name: name,
                    link: link,
                    cover: cover,
                    description: description,
                    host: BASE_URL
                });
            }

        });

        let next = null;
        let lastHref = doc.select(".pagination .btn-page").last().attr("href");
        if (lastHref.indexOf("page=") !== -1) {
            next = (parseInt(page) + 1).toString();
        }

        return Response.success(storyList, next);
    }

    return Response.error("Không thể tải danh sách truyện.");
}
