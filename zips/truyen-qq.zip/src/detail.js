load("config.js");
load("bypass.js");

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    if (url.slice(-1) !== "/") {
        url = url + "/";
    }
    let response = fetch(url, {
        headers: {
            "user-agent": UserAgent.system(),
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "referer": BASE_URL + "/"
        }
    });

    if (!response.ok) {
        bypass(url);
        response = fetch(url, {
            headers: {
                "user-agent": UserAgent.system(),
                "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "referer": BASE_URL + "/"
            }
        });
    }

    if (response.ok) {
        let doc = response.html();

        let name = doc.select("h1[itemprop=name]").text().trim();
        let author = doc.select(".line:has(.fa-user) .result").text().trim();
        let cover = doc.select(".poster img").attr("src");
        let detail = doc.select(".line:has(.fa-eye)").text().trim() + "<br>" 
                    + doc.select(".line:has(.fa-clock-o)").text().trim();
        let description = doc.select("div[itemprop=description]").html();
        let ongoing = doc.select(".line:has(.fa-ellipsis-h) .result").text().includes("Đang ra");
        let suggests = [{title: "Truyện phổ biến", input: BASE_URL, script: "suggest.js"}];
        let genres = [];
        doc.select(".line:has(.fa-folder) a").forEach(e => {
            genres.push({ title: e.text(), input: BASE_URL + e.attr("href"), script: "gen.js" });
        });

        if (name) {
            return Response.success({
                name: name,
                author: author,
                cover: cover,
                detail: detail,
                description: description,
                ongoing: ongoing,
                suggests: suggests,
                genres: genres,
                host: BASE_URL
            });
        }
    }

    return Response.error("Không thể tải thông tin truyện.");
}
