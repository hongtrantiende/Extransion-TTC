load("config.js");
load("bypass.js");

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    if (url.slice(-1) !== "/") {
        url = url + "/";
    }
    let response = fetch(url, {
        headers: {
            "user-agent": UserAgent.system(),
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "referer": BASE_URL + "/"
        }
    });

    if (!response.ok) {
        bypass(url);
        response = fetch(url, {
            headers: {
                "user-agent": UserAgent.system(),
                "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "referer": BASE_URL + "/"
            }
        });
    }

    if (response.ok) {
        let doc = response.html();
        let chapList = [];
        
        let elements = doc.select("#chapter-list a");
        elements.forEach(function(e) {
            chapList.push({
                name: e.text().trim(),
                url: e.attr("href"),
                host: BASE_URL
            });
        });

        chapList.reverse();
        return Response.success(chapList);
    }
    
    return Response.error("Không thể tải danh sách chương.");
}