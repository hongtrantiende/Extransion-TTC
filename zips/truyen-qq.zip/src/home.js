load("config.js");

function execute() {
  return Response.success([
    { title: "Truyện Hot", input: BASE_URL + "/truyen-hot", script: "gen.js" },
    { title: "Truyện Mới", input: BASE_URL + "/truyen-moi", script: "gen.js" },
  ]);
}
