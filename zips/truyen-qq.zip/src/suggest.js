load("config.js");

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    if (url.slice(-1) !== "/") {
        url = url + "/";
    }
    let response = fetch(url, {
        headers: {
            "user-agent": UserAgent.system(),
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "referer": BASE_URL + "/"
        }
    });

    if (!response.ok) {
        bypass(url);
        response = fetch(url, {
            headers: {
                "user-agent": UserAgent.system(),
                "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "referer": BASE_URL + "/"
            }
        });
    }

    if (response.ok) {
        let doc = response.html();
        let storyList = [];

        let elements = doc.select("#owl-slide .item");
        elements.forEach(function(e) {
            let name = e.select("h3").text().trim();
            let link = e.select("a").attr("href");
            let cover = e.select("img").attr("src");
            let description = e.select("p").text().trim();
            if (name) {
                storyList.push({
                    name: name,
                    link: link,
                    cover: cover,
                    description: description,
                    host: BASE_URL
                });
            }

        });

        return Response.success(storyList);
    }

    return Response.error("Không thể tải danh sách truyện.");
}
