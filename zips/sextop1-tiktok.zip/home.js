function execute() {
    var kinds = [
        {
            title: "Sextop1 TikTok",
            name: "Sextop1 TikTok",
            input: "https://sextop1.am/phim-sex-viet/"
        },
        {
            title: "Tab 2",
            name: "Tab 2",
            input: "https://sextop1.am/phim-sex-viet/page/2/"
        }
    ];
    return Response.success(kinds);
}
