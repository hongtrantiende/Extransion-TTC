// Các helper cho Sáng Tác Việt direct fetch fallback
if (typeof STV_CONFIG === "undefined") {
    var STV_CONFIG = {
        BASES: [
            "https://dns1.stv-appdomain-00000001.org",
            "http://14.225.254.182"
        ],
        BETA_BASES: [
            "https://dns1.stv-appdomain-00000001.org",
            "http://14.225.254.182"
        ],
        PUBLIC_BASE: "http://14.225.254.182",
        BETA_PUBLIC_BASE: "http://14.225.254.182",
        USER_AGENT: "Mozilla/5.0 (Linux; Android 11; sdk_gphone64_x86_64 Build/RSR1.201013.001.A1) AppleWebKit/537.36 (KHTML, like Gecko) Mobile Safari/537.36",
        SIGN_SALT: "erogh982^%*%^*",
        CF_SYNC_TIMEOUT_MS: 15000,
        CF_COOKIE_CACHE_TTL_MS: 1800000,
        CF_COOKIE_STORAGE_KEY: "stv.cf.cookie.v1",
        APP_HEADERS: {
            "x-stv-transport": "app",
            "x-requested-with": "com.sangtacviet.mobilereader"
        }
    };
}

if (typeof STV_STATE === "undefined") {
    var STV_STATE = {
        lastBase: STV_CONFIG.BASES[0],
        cfCookieByBase: {},
        cfCookieUpdatedAt: {},
        cfCookieStoreLoaded: false
    };
}

if (typeof AUTH_COOKIE === "undefined") {
    var AUTH_COOKIE = "";
}

function stvTrim(text) {
    if (text === null || typeof text === "undefined") return "";
    return String(text).replace(/^\s+|\s+$/g, "");
}

function stvFirst(v1, v2, v3) {
    var values = [v1, v2, v3];
    for (var i = 0; i < values.length; i++) {
        var value = stvTrim(values[i]);
        if (value) return value;
    }
    return "";
}

function stvEncode(text) {
    return encodeURIComponent(text === null || typeof text === "undefined" ? "" : String(text));
}

function stvDecode(text) {
    try {
        return decodeURIComponent(text === null || typeof text === "undefined" ? "" : String(text));
    } catch (_) {
        return text === null || typeof text === "undefined" ? "" : String(text);
    }
}

function stvNormalizeBase(base) {
    var value = stvTrim(base);
    if (!value) return "";
    if (value.indexOf("http://") !== 0 && value.indexOf("https://") !== 0) {
        value = "https://" + value;
    }
    while (value.length > 0 && value.charAt(value.length - 1) === "/") {
        value = value.substring(0, value.length - 1);
    }
    return value;
}

function stvBuildUrl(base, path) {
    var normalizedBase = stvNormalizeBase(base);
    if (!normalizedBase) return "";
    if (!path) return normalizedBase;
    if (path.indexOf("http://") === 0 || path.indexOf("https://") === 0) return path;
    if (path.charAt(0) !== "/") return normalizedBase + "/" + path;
    return normalizedBase + path;
}

function stvIsSangtacBase(base) {
    var normalized = stvNormalizeBase(base).toLowerCase();
    return normalized.indexOf("://sangtacviet.") >= 0
        || normalized.indexOf("://www.sangtacviet.") >= 0;
}

function stvIsBetaRuntime() {
    return false;
}

function stvRuntimeBase(base) {
    var normalized = stvNormalizeBase(base);
    if (!normalized) return "";
    if (stvIsSangtacBase(normalized)) {
        return stvNormalizeBase(STV_CONFIG.PUBLIC_BASE || STV_CONFIG.BETA_PUBLIC_BASE || normalized);
    }
    return normalized;
}

function stvRuntimeBases() {
    var bases = STV_CONFIG.BASES;
    var out = [];
    for (var i = 0; i < bases.length; i++) {
        var normalized = stvRuntimeBase(bases[i]);
        if (normalized) out.push(normalized);
    }
    return out;
}

function stvRuntimeDefaultBase() {
    var bases = stvRuntimeBases();
    return bases.length > 0 ? bases[0] : stvNormalizeBase(STV_CONFIG.BASES[0]);
}

function stvGetBaseCandidates(preferredBase) {
    var result = [];
    var seen = {};

    function add(base) {
        var normalized = stvRuntimeBase(base);
        if (!normalized) return;
        if (seen[normalized]) return;
        seen[normalized] = true;
        result.push(normalized);
    }

    var bases = stvRuntimeBases();
    for (var i = 0; i < bases.length; i++) {
        add(bases[i]);
    }
    add(preferredBase);
    add(STV_STATE.lastBase);

    return result;
}

function stvMergeHeaders(baseHeaders, extraHeaders) {
    var out = {};
    var key;
    if (baseHeaders) {
        for (key in baseHeaders) {
            if (baseHeaders.hasOwnProperty(key)) out[key] = baseHeaders[key];
        }
    }
    if (extraHeaders) {
        for (key in extraHeaders) {
            if (extraHeaders.hasOwnProperty(key) && extraHeaders[key] !== null && typeof extraHeaders[key] !== "undefined") {
                out[key] = extraHeaders[key];
            }
        }
    }
    return out;
}

function stvHeaders(extraHeaders) {
    var headers = {
        "User-Agent": STV_CONFIG.USER_AGENT,
        "Accept": "*/*"
    };
    headers = stvMergeHeaders(headers, STV_CONFIG.APP_HEADERS);
    headers = stvMergeHeaders(headers, extraHeaders);
    return headers;
}

function stvNormalizeCookieText(cookieText) {
    var text = stvTrim(cookieText);
    if (!text) return "";
    return text.replace(/^[;\s]+|[;\s]+$/g, "");
}

function stvConfiguredCookie() {
    return "";
}

function stvGetCloudflareCookieForBase(base) {
    var normalizedBase = stvNormalizeBase(base);
    if (!normalizedBase) return "";

    stvEnsureCloudflareCookieStoreLoaded();

    if (!STV_STATE.cfCookieByBase) STV_STATE.cfCookieByBase = {};
    if (!STV_STATE.cfCookieUpdatedAt) STV_STATE.cfCookieUpdatedAt = {};

    var cookie = stvNormalizeCookieText(STV_STATE.cfCookieByBase[normalizedBase]);
    if (!cookie) return "";

    var ttl = STV_CONFIG.CF_COOKIE_CACHE_TTL_MS || 1800000;
    var updatedAt = STV_STATE.cfCookieUpdatedAt[normalizedBase] || 0;
    if (updatedAt > 0 && (new Date().getTime() - updatedAt) > ttl) {
        delete STV_STATE.cfCookieByBase[normalizedBase];
        delete STV_STATE.cfCookieUpdatedAt[normalizedBase];
        stvWriteCloudflareCookieStore();
        return "";
    }

    return cookie;
}

function stvSetCloudflareCookieForBase(base, cookieText) {
    var normalizedBase = stvNormalizeBase(base);
    var picked = stvPickCloudflareCookie(cookieText);
    if (!normalizedBase || !picked) return "";

    stvEnsureCloudflareCookieStoreLoaded();

    if (!STV_STATE.cfCookieByBase) STV_STATE.cfCookieByBase = {};
    if (!STV_STATE.cfCookieUpdatedAt) STV_STATE.cfCookieUpdatedAt = {};

    STV_STATE.cfCookieByBase[normalizedBase] = picked;
    STV_STATE.cfCookieUpdatedAt[normalizedBase] = new Date().getTime();
    stvWriteCloudflareCookieStore();
    return picked;
}

function stvBuildCookie(cookieText) {
    function mergeCookieText(store, text) {
        var raw = stvNormalizeCookieText(text);
        if (!raw) return;
        var parts = raw.split(";");
        for (var i = 0; i < parts.length; i++) {
            var item = stvTrim(parts[i]);
            if (!item) continue;
            var eq = item.indexOf("=");
            if (eq <= 0) continue;
            var key = stvTrim(item.substring(0, eq));
            var value = stvTrim(item.substring(eq + 1));
            if (!key || !value) continue;
            store[key] = value;
        }
    }

    var base = arguments.length >= 2 ? arguments[1] : STV_STATE.lastBase;
    var baseCookie = stvNormalizeCookieText(cookieText);
    var authCookie = stvNormalizeCookieText(AUTH_COOKIE);
    var configCookie = "";
    var cfCookie = stvNormalizeCookieText(stvGetCloudflareCookieForBase(base));
    var merged = {};
    var parts = [];

    mergeCookieText(merged, baseCookie);
    mergeCookieText(merged, authCookie);
    mergeCookieText(merged, configCookie);
    mergeCookieText(merged, cfCookie);

    for (var key in merged) {
        if (!merged.hasOwnProperty(key)) continue;
        parts.push(key + "=" + merged[key]);
    }
    if (parts.length === 0) return "";
    return parts.join("; ") + ";";
}

function stvPickCloudflareCookie(cookieText) {
    var raw = stvNormalizeCookieText(cookieText);
    if (!raw) return "";

    var parts = raw.split(";");
    var out = [];
    var seen = {};
    for (var i = 0; i < parts.length; i++) {
        var item = stvTrim(parts[i]);
        if (!item) continue;
        var eq = item.indexOf("=");
        if (eq <= 0) continue;
        var key = stvTrim(item.substring(0, eq));
        var value = stvTrim(item.substring(eq + 1));
        if (!key || !value) continue;
        var lower = key.toLowerCase();
        if (lower !== "cf_clearance" && lower.indexOf("__cf") !== 0) continue;
        if (seen[lower]) continue;
        seen[lower] = true;
        out.push(key + "=" + value);
    }
    return out.join("; ");
}

function stvCanUseLocalStorage() {
    try {
        return typeof localStorage !== "undefined" && !!localStorage;
    } catch (_) {
        return false;
    }
}

function stvReadCloudflareCookieStore() {
    if (!stvCanUseLocalStorage()) return null;
    try {
        var raw = localStorage.getItem(STV_CONFIG.CF_COOKIE_STORAGE_KEY || "stv.cf.cookie.v1");
        if (!raw) return null;
        var parsed = JSON.parse(raw);
        if (!parsed || typeof parsed !== "object") return null;
        var byBase = parsed.byBase && typeof parsed.byBase === "object" ? parsed.byBase : {};
        var updatedAt = parsed.updatedAt && typeof parsed.updatedAt === "object" ? parsed.updatedAt : {};
        return { byBase: byBase, updatedAt: updatedAt };
    } catch (_) {
        return null;
    }
}

function stvWriteCloudflareCookieStore() {
    if (!stvCanUseLocalStorage()) return;
    try {
        var payload = {
            byBase: STV_STATE.cfCookieByBase || {},
            updatedAt: STV_STATE.cfCookieUpdatedAt || {}
        };
        localStorage.setItem(STV_CONFIG.CF_COOKIE_STORAGE_KEY || "stv.cf.cookie.v1", JSON.stringify(payload));
    } catch (_) {}
}

function stvEnsureCloudflareCookieStoreLoaded() {
    if (STV_STATE.cfCookieStoreLoaded) return;
    STV_STATE.cfCookieStoreLoaded = true;
    if (!STV_STATE.cfCookieByBase) STV_STATE.cfCookieByBase = {};
    if (!STV_STATE.cfCookieUpdatedAt) STV_STATE.cfCookieUpdatedAt = {};
    var store = stvReadCloudflareCookieStore();
    if (!store) return;
    STV_STATE.cfCookieByBase = store.byBase || {};
    STV_STATE.cfCookieUpdatedAt = store.updatedAt || {};
}

function stvSyncCloudflareCookie(base, hintUrl) {
    var normalizedBase = stvRuntimeBase(base || STV_STATE.lastBase || stvRuntimeDefaultBase());
    if (!normalizedBase) return false;

    if (typeof Engine === "undefined" || !Engine || typeof Engine.newBrowser !== "function") {
        return false;
    }

    var browser = null;
    try {
        browser = Engine.newBrowser();
        if (!browser || typeof browser.launch !== "function") return false;

        if (typeof browser.setUserAgent === "function") {
            browser.setUserAgent(STV_CONFIG.USER_AGENT);
        }

        if (typeof browser.overrideCookie === "function") {
            var mergedCookie = stvBuildCookie("", normalizedBase);
            var cookieObj = {};
            var cookiePairs = stvNormalizeCookieText(mergedCookie).split(";");
            var hasCookie = false;
            for (var i = 0; i < cookiePairs.length; i++) {
                var pair = stvTrim(cookiePairs[i]);
                if (!pair) continue;
                var eq = pair.indexOf("=");
                if (eq <= 0) continue;
                var key = stvTrim(pair.substring(0, eq));
                var value = stvTrim(pair.substring(eq + 1));
                if (!key || !value) continue;
                cookieObj[key] = value;
                hasCookie = true;
            }
            if (hasCookie) {
                browser.overrideCookie(cookieObj);
            }
        }

        var openUrl = stvTrim(hintUrl);
        if (!(openUrl.indexOf("http://") === 0 || openUrl.indexOf("https://") === 0)) {
            openUrl = stvBuildUrl(normalizedBase, "/");
        }

        browser.launch(openUrl, STV_CONFIG.CF_SYNC_TIMEOUT_MS || 15000);

        if (typeof browser.callJs !== "function" || typeof browser.getVariable !== "function") {
            return false;
        }

        var key = "stv_cf_cookie_sync_" + Math.random().toString(36).substring(2);
        var js = "try{Cache.putVariable('" + key + "', String(document.cookie||''));}"
            + "catch(e){try{Cache.putVariable('" + key + "', '');}catch(_){}}";
        browser.callJs(js, 4000);
        var rawCookie = stvTrim(browser.getVariable(key));
        var picked = stvSetCloudflareCookieForBase(normalizedBase, rawCookie);
        return !!picked;
    } catch (_) {
        return false;
    } finally {
        try {
            if (browser && typeof browser.close === "function") browser.close();
        } catch (_) {
            // Ignore close errors.
        }
    }
}

function stvLooksLikeCloudflareText(text) {
    var sample = stvTrim(text).toLowerCase();
    if (!sample) return false;
    return sample.indexOf("cloudflare") >= 0
        || sample.indexOf("just a moment") >= 0
        || sample.indexOf("attention required") >= 0
        || sample.indexOf("cf-browser-verification") >= 0
        || sample.indexOf("challenge-platform") >= 0;
}

function stvIsCloudflareBlockedResponse(responseLike) {
    if (!responseLike) return false;
    var status = responseLike.status || 0;
    if (status === 403 || status === 429 || status === 503 || status === 1020) return true;
    return stvLooksLikeCloudflareText(responseLike.text || "");
}

function stvGetHeaderValue(headers, wantedName) {
    if (!headers || !wantedName) return "";
    var lowerWanted = String(wantedName).toLowerCase();
    if (typeof headers.get === "function") {
        var direct = headers.get(wantedName);
        if (direct) return String(direct);
        var lowered = headers.get(lowerWanted);
        if (lowered) return String(lowered);
    }
    var keys = [wantedName, lowerWanted, "Set-Cookie", "set-cookie"];
    for (var i = 0; i < keys.length; i++) {
        var key = keys[i];
        if (typeof headers[key] !== "undefined" && headers[key] !== null) {
            var value = headers[key];
            if (Object.prototype.toString.call(value) === "[object Array]") {
                return value.join("; ");
            }
            return String(value);
        }
    }
    return "";
}

function stvExtractSetCookie(headers) {
    return stvGetHeaderValue(headers, "set-cookie");
}

function stvFindReadContextId(setCookieText) {
    var text = stvTrim(setCookieText);
    if (!text) return "";
    var match = text.match(/readcontextid=([^;\s]+)/i);
    return match && match[1] ? match[1] : "";
}

function stvBuildBookUrl(base, host, bookid, status) {
    var state = stvTrim(status);
    if (!state) state = "1";
    return stvBuildUrl(base, "/truyen/" + stvEncode(host) + "/" + stvEncode(state) + "/" + stvEncode(bookid) + "/");
}

function stvMd5Hex(text) {
    if (typeof CryptoJS !== "undefined" && CryptoJS && typeof CryptoJS.MD5 === "function") {
        return String(CryptoJS.MD5(String(text)));
    }
    return "";
}

function stvWithLoginHint(message) {
    var text = stvTrim(message);
    if (!text) return text;

    var lower = text.toLowerCase();
    var needHint = lower.indexOf("đăng nhập") >= 0
        || lower.indexOf("dang nhap") >= 0
        || lower.indexOf("login") >= 0;

    if (!needHint) return text;
    if (text.indexOf("STV Cookie") >= 0 || text.indexOf("var AUTH_COOKIE = \"\";") >= 0) return text;

    return text + " Vui lòng nhập toàn bộ chuỗi cookie vào trường STV Cookie (beta) hoặc mã bổ sung, ví dụ: 'var AUTH_COOKIE = \"hstamp=...;_ga=...;...\";'";
}

function stvParseJsonLoose(text) {
    if (text === null || typeof text === "undefined") return null;

    var data = String(text).replace(/^\uFEFF/, "");
    var first = data.indexOf("{");
    if (first > 0) data = data.substring(first);

    data = stvTrim(data);
    if (!data) return null;

    try {
        return JSON.parse(data);
    } catch (_) {
        return null;
    }
}

function stvFetchText(url, options) {
    try {
        var response = fetch(url, options || {});
        var text = response ? response.text() : "";
        return {
            ok: !!(response && response.ok),
            status: response ? response.status : 0,
            text: text,
            headers: response ? response.headers : null,
            response: response
        };
    } catch (e) {
        return {
            ok: false,
            status: 0,
            text: "",
            headers: null,
            response: null,
            error: e
        };
    }
}

function stvFetchJson(url, options) {
    var result = stvFetchText(url, options);
    result.json = stvParseJsonLoose(result.text);
    return result;
}

function stvReadChapter(base, payload, grant) {
    if (!grant || !grant.chapterkey) return null;

    var params = {
        sajax: "readchapter",
        h: payload.host,
        bookid: payload.bookid,
        c: payload.cid,
        key: grant.chapterkey
    };

    var sorted = stvSortQuery(params);
    var sign = stvMd5Hex(sorted + STV_CONFIG.SIGN_SALT);
    if (!sign) return null;

    var url = stvBuildUrl(base,
        "/?sajax=readchapter"
        + "&h=" + stvEncode(payload.host)
        + "&bookid=" + stvEncode(payload.bookid)
        + "&c=" + stvEncode(payload.cid)
        + "&key=" + stvEncode(grant.chapterkey)
    );

    var cookieParts = [];
    if (grant.readcontextid) cookieParts.push("readcontextid=" + grant.readcontextid);
    cookieParts.push("mac_tt=true");
    
    function requestChapter() {
        var cookie = stvBuildCookie(cookieParts.join("; "), base);
        var requestHeaders = {
            "x-stv-sign": sign,
            "Referer": stvBuildBookUrl(base, payload.host, payload.bookid, 1)
        };
        if (cookie) requestHeaders["Cookie"] = cookie;

        return stvFetchJson(url, {
            method: "GET",
            headers: stvHeaders(requestHeaders)
        });
    }

    var response = requestChapter();
    if ((!response.ok || !response.json) && stvIsCloudflareBlockedResponse(response)) {
        var synced = stvSyncCloudflareCookie(base, stvBuildBookUrl(base, payload.host, payload.bookid, 1));
        if (synced) {
            response = requestChapter();
        }
    }

    if (!response.ok || !response.json) return null;
    return response.json;
}
