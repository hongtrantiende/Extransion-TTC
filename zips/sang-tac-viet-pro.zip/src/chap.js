load("config.js");
load("crypto.js");
load("stv_fallback_helpers.js");
load("chap_decode.js");

var lastProxyErr = "";

function execute(url) {
    let meta = parseStvUrl(url);
    if (!meta || !meta.chapterId) {
        return Response.error("Không nhận diện được URL chương Sáng Tác Việt.");
    }

    // Tải trực tiếp không qua proxy (tắt dịch lấy raw Trung)
    let directResult = tryFetchChapterDirect(meta);
    if (directResult.error) {
        return Response.error(directResult.error);
    }

    return Response.success(directResult.data);
}

function tryFetchChapterDirect(meta) {
    try {
        var payload = {
            base: meta.origin || STV_ORIGIN,
            host: meta.host,
            bookid: meta.bookId,
            cid: meta.chapterId
        };
        
        var bases = [payload.base, "https://dns1.stv-appdomain-00000001.org", "http://14.225.254.182"];
        var lastErr = "";

        for (var i = 0; i < bases.length; i++) {
            var base = bases[i];
            var grant = stvGrantContext(base, payload.host, payload.bookid);

            if (!grant || !grant.chapterkey) {
                lastErr = stvWithLoginHint(stvFirst(grant ? grant.grantErr : "", "Không lấy được chapterkey."));
                continue;
            }

            var json = stvReadChapter(base, payload, grant);
            if (!json) {
                lastErr = stvWithLoginHint("Không đọc được readchapter.");
                continue;
            }

            if (String(json.code) !== "0") {
                lastErr = stvWithLoginHint(stvFirst(json.err, json.info, "STV trả về lỗi không xác định."));
                continue;
            }

            STV_STATE.lastBase = base;

            var raw = stvFirst(json.data, "");
            var content = stvNormalizeChapterHtml(payload.host, base, raw, payload.bookid, payload.cid, json.defaultname);
            if (!content) {
                return { error: "Đã nhận dữ liệu chương nhưng không có nội dung." };
            }

            return { data: content };
        }
        return { error: stvWithLoginHint(lastErr || "Không thể tải nội dung chương STV.") };
    } catch (e) {
        return { error: "Lỗi tải trực tiếp từ STV: " + e.message };
    }
}

function resolveStvLlmNames(meta) {
    if (AI_MODE !== "llm" || !meta) return "";
    try {
        var storageKey = findStvExistingLlmNamesStorageKey(meta, resolveStvBookTitle(meta, ""));
        return storageKey ? normalizeStvLlmNamesText(readStvStorageText(storageKey)) : "";
    } catch (e) {
        return "";
    }
}

function captureStvProxyCookie(meta) {
    // Probe STV URL via Vbook native HTTP 
    // client to get FULL cookie jar
    // (including HttpOnly session cookies — unlike document.cookie which only reads JS-accessible cookies)
    // Same technique as sangtacviet extension: read response.request.headers.cookie
    var urls = [];
    if (meta && meta.chapterId) {
        urls.push(buildStvChapterUrl(meta, meta.chapterId));
    }
    if (meta) {
        urls.push(buildStvBookUrl(meta));
    }
    for (var i = 0; i < urls.length; i++) {
        try {
            var probe = fetch(urls[i], { headers: { "User-Agent": STV_ANDROID_UA } });
            if (probe && probe.request && probe.request.headers && probe.request.headers.cookie) {
                var cookie = String(probe.request.headers.cookie || "").replace(/[\r\n]/g, "");
                if (cookie) {
                    return cookie;
                }
            }
        } catch (probeErr) {}
    }
    return "";
}

function tryFetchChapterViaProxy(meta) {
    try {
        var stvCookie = captureStvProxyCookie(meta);

        let endpoint = PROXY_URL + "/stv/chapter";

        var body = {
            bookid: meta.bookId,
            cid:    meta.chapterId,
            host:   meta.host
        };
        if (stvCookie) {
            body.stvCookie = stvCookie;
        }
        if (AI_MODE === "llm") {
            body.aiMode = "llm";
            var names = resolveStvLlmNames(meta);
            if (names) {
                body.names = names;
            }
        }

        let response = fetch(endpoint, {
            method: "POST",
            headers: {
                "Accept":       "application/json",
                "Content-Type": "application/json",
                "User-Agent":   STV_ANDROID_UA,
                "X-License-Token": PROXY_TOKEN
            },
            body: JSON.stringify(body)
        });

        let p = null;
        try { p = response.json(); } catch (e) {}

        if (!response.ok) {
            return { error: buildErrorMsg(response.status, p) };
        }

        if (p && p.code === 0 && p.data) {
            return { data: p.data };
        }

        return { error: buildErrorMsg(response.status, p) };

    } catch (e) {
        return { error: "Lỗi kết nối tới Proxy Server. Kiểm tra lại mạng và URL server." };
    }
}

function buildTokenStatusInfo(tokenInfo) {
    if (!tokenInfo) {
        return "";
    }

    var state = tokenInfo.active ? (tokenInfo.isExpired ? "Hết hạn" : "Đang hoạt động") : "Đã bị khóa";
    var stats = tokenInfo.stats || {};
    var parts = [];

    parts.push("Trạng thái: " + state);

    if (tokenInfo.tokenHint) {
        parts.push("Token: " + tokenInfo.tokenHint);
    }
    if (tokenInfo.dailyLimit != null || tokenInfo.monthlyLimit != null) {
        var dayPart = (stats.todayCount || 0) + "/" + (tokenInfo.dailyLimit != null ? tokenInfo.dailyLimit : "∞");
        var monthPart = (stats.monthCount || 0) + "/" + (tokenInfo.monthlyLimit != null ? tokenInfo.monthlyLimit : "∞");
        parts.push("Quota: ngày " + dayPart + ", tháng " + monthPart);
    }
    if (tokenInfo.proxyDisplay || tokenInfo.upstreamOrigin) {
        parts.push("Route: " + (tokenInfo.proxyDisplay || "direct") + " -> " + (tokenInfo.upstreamOrigin || "-"));
    }
    if (tokenInfo.lastClientIp) {
        parts.push("IP gần nhất: " + tokenInfo.lastClientIp);
    }
    if (stats.lastSeen) {
        parts.push("Lần gọi cuối: " + String(stats.lastSeen).replace("T", " ").replace(/\.\d+Z$/, "Z"));
    }

    return parts.length ? "\n\n[Token Info]\n" + parts.join("\n") : "";
}

// Chuyển HTTP status + JSON body của proxy thành thông báo tiếng Việt cho người dùng.
function buildErrorMsg(httpStatus, p) {
    var tokenInfoText = buildTokenStatusInfo(p && p.tokenInfo ? p.tokenInfo : null);

    // Một số JS engine (Vbook) có thể báo httpStatus=0 thay vì status thực.
    // Dùng p.code làm fallback khi httpStatus không đáng tin.
    var statusCode = httpStatus || 0;
    var pCode = p && (p.code || p.reason) ? (Number(p.code) || 0) : 0;
    if (!statusCode && pCode >= 400) {
        statusCode = pCode;
    }

    // 401 — token sai hoặc hết hạn
    if (statusCode === 401 || (p && p.code === 401)) {
        return "[Token] Token không hợp lệ hoặc đã hết hạn.\nKiểm tra lại License Token trong Cài đặt plugin." + tokenInfoText;
    }

    // 429 — rate limit / cooldown / daily / monthly
    if (statusCode === 429 || (p && p.code === 429)) {
        let errText = (p && p.error) ? String(p.error) : "";

        if (p && p.cooldown && p.retryAfter) {
            let mins = Math.ceil(p.retryAfter / 60);
            return "[Rate Limit] Token bị tạm khóa " + mins + " phút do gửi quá nhiều request liên tục.\nThử lại sau " + mins + " phút." + tokenInfoText;
        }
        if (errText.indexOf("ngày") !== -1) {
            return "[Quota] Đã đạt giới hạn request trong ngày. Thử lại vào ngày mai." + tokenInfoText;
        }
        if (errText.indexOf("tháng") !== -1) {
            return "[Quota] Đã đạt giới hạn request trong tháng. Thử lại vào tháng sau." + tokenInfoText;
        }
        return "[Rate Limit] Quá nhiều request. Chờ một chút rồi thử lại." + tokenInfoText;
    }

    // 500 / 503 — lỗi server
    if (statusCode === 500) {
        return "[Server] Lỗi nội bộ proxy server. Thử lại sau." + tokenInfoText;
    }
    if (statusCode === 503) {
        return "[Server] Proxy server đang bảo trì hoặc token chưa được gán proxy khả dụng. Thử lại sau." + tokenInfoText;
    }

    // Lỗi STV trả về (code != 0) hoặc lỗi proxy có error message
    if (p && p.error) {
        return "[STV] " + p.error + tokenInfoText;
    }

    if (statusCode && statusCode !== 200) {
        return "[HTTP " + statusCode + "] Không kết nối được proxy server." + tokenInfoText;
    }

    
    return "Không tải được nội dung chương. Kiểm tra Proxy Server URL và License Token." + tokenInfoText;
}