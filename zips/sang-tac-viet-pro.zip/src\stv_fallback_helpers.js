// Các helper cho Sáng Tác Việt direct fetch fallback
if (typeof STV_CONFIG === "undefined") {
    var STV_CONFIG = {
        BASES: [
            "https://dns1.stv-appdomain-00000001.org",
            "http://14.225.254.182"
        ],
        BETA_BASES: [
            "https://dns1.stv-appdomain-00000001.org",
            "http://14.225.254.182"
        ],
        PUBLIC_BASE: "http://14.225.254.182",
        BETA_PUBLIC_BASE: "http://14.225.254.182",
        USER_AGENT: "Mozilla/5.0 (Linux; Android 11; sdk_gphone64_x86_64 Build/RSR1.201013.001.A1) AppleWebKit/537.36 (KHTML, like Gecko) Mobile Safari/537.36",
        SIGN_SALT: "erogh982^%*%^*",
        CF_SYNC_TIMEOUT_MS: 15000,
        CF_COOKIE_CACHE_TTL_MS: 1800000,
        CF_COOKIE_STORAGE_KEY: "stv.cf.cookie.v1",
        APP_HEADERS: {
            "x-stv-transport": "app",
            "x-requested-with": "com.sangtacviet.mobilereader"
        }
    };
}

if (typeof STV_STATE === "undefined") {
    var STV_STATE = {
        lastBase: STV_CONFIG.BASES[0],
        cfCookieByBase: {},
        cfCookieUpdatedAt: {},
        cfCookieStoreLoaded: false
    };
}

if (typeof AUTH_COOKIE === "undefined") {
    var AUTH_COOKIE = "";
}

function stvTrim(text) {
    if (text === null || typeof text === "undefined") return "";
    return String(text).replace(/^\s+|\s+$/g, "");
}

function stvFirst(v1, v2, v3) {
    var values = [v1, v2, v3];
    for (var i = 0; i < values.length; i++) {
        var value = stvTrim(values[i]);
        if (value) return value;
    }
    return "";
}

function stvEncode(text) {
    return encodeURIComponent(text === null || typeof text === "undefined" ? "" : String(text));
}

function stvDecode(text) {
    try {
        return decodeURIComponent(text === null || typeof text === "undefined" ? "" : String(text));
    } catch (_) {
        return text === null || typeof text === "undefined" ? "" : String(text);
    }
}

function stvNormalizeBase(base) {
    var value = stvTrim(base);
    if (!value) return "";
    if (value.indexOf("http://") !== 0 && value.indexOf("https://") !== 0) {
        value = "https://" + value;
    }
    while (value.length > 0 && value.charAt(value.length - 1) === "/") {
        value = value.substring(0, value.length - 1);
    }
    return value;
}

function stvBuildUrl(base, path) {
    var normalizedBase = stvNormalizeBase(base);
    if (!normalizedBase) return "";
    if (!path) return normalizedBase;
    if (path.indexOf("http://") === 0 || path.indexOf("https://") === 0) return path;
    if (path.charAt(0) !== "/") return normalizedBase + "/" + path;
    return normalizedBase + path;
}

function stvIsSangtacBase(base) {
    var normalized = stvNormalizeBase(base).toLowerCase();
    return normalized.indexOf("://sangtacviet.") >= 0
        || normalized.indexOf("://www.sangtacviet.") >= 0;
}

function stvIsBetaRuntime() {
    return false;
}

function stvRuntimeBase(base) {
    var normalized = stvNormalizeBase(base);
    if (!normalized) return "";
    if (stvIsSangtacBase(normalized)) {
        return stvNormalizeBase(STV_CONFIG.PUBLIC_BASE || STV_CONFIG.BETA_PUBLIC_BASE || normalized);
    }
    return normalized;
}

function stvRuntimeBases() {
    var bases = STV_CONFIG.BASES;
    var out = [];
    for (var i = 0; i < bases.length; i++) {
        var normalized = stvRuntimeBase(bases[i]);
        if (normalized) out.push(normalized);
    }
    return out;
}

function stvRuntimeDefaultBase() {
    var bases = stvRuntimeBases();
    return bases.length > 0 ? bases[0] : stvNormalizeBase(STV_CONFIG.BASES[0]);
}

function stvGetBaseCandidates(preferredBase) {
    var result = [];
    var seen = {};

    function add(base) {
        var normalized = stvRuntimeBase(base);
        if (!normalized) return;
        if (seen[normalized]) return;
        seen[normalized] = true;
        result.push(normalized);
    }

    var bases = stvRuntimeBases();
    for (var i = 0; i < bases.length; i++) {
        add(bases[i]);
    }
    add(preferredBase);
    add(STV_STATE.lastBase);

    return result;
}

function stvMergeHeaders(baseHeaders, extraHeaders) {
    var out = {};
    var key;
    if (baseHeaders) {
        for (key in baseHeaders) {
            if (baseHeaders.hasOwnProperty(key)) out[key] = baseHeaders[key];
        }
    }
    if (extraHeaders) {
        for (key in extraHeaders) {
            if (extraHeaders.hasOwnProperty(key) && extraHeaders[key] !== null && typeof extraHeaders[key] !== "undefined") {
                out[key] = extraHeaders[key];
            }
        }
    }
    return out;
}

function stvHeaders(extraHeaders) {
    var headers = {
        "User-Agent": STV_CONFIG.USER_AGENT,
        "Accept": "*/*"
    };
    headers = stvMergeHeaders(headers, STV_CONFIG.APP_HEADERS);
    headers = stvMergeHeaders(headers, extraHeaders);
    return headers;
}

function stvNormalizeCookieText(cookieText) {
    var text = stvTrim(cookieText);
    if (!text) return "";
    return text.replace(/^[;\s]+|[;\s]+$/g, "");
}

function stvConfiguredCookie() {
    return "";
}

function stvGetCloudflareCookieForBase(base) {
    return "";
}

function stvSetCloudflareCookieForBase(base, cookieText) {
    return "";
}

function stvBuildCookie(cookieText) {
    function mergeCookieText(store, text) {
        var raw = stvNormalizeCookieText(text);
        if (!raw) return;
        var parts = raw.split(";");
        for (var i = 0; i < parts.length; i++) {
            var item = stvTrim(parts[i]);
            if (!item) continue;
            var eq = item.indexOf("=");
            if (eq <= 0) continue;
            var key = stvTrim(item.substring(0, eq));
            var value = stvTrim(item.substring(eq + 1));
            if (!key || !value) continue;
            store[key] = value;
        }
    }

    var base = arguments.length >= 2 ? arguments[1] : STV_STATE.lastBase;
    var baseCookie = stvNormalizeCookieText(cookieText);
    var authCookie = stvNormalizeCookieText(AUTH_COOKIE);
    var configCookie = stvConfiguredCookie();
    var cfCookie = "";
    var merged = {};
    var parts = [];

    mergeCookieText(merged, baseCookie);
    mergeCookieText(merged, authCookie);
    mergeCookieText(merged, configCookie);
    mergeCookieText(merged, cfCookie);

    for (var key in merged) {
        if (!merged.hasOwnProperty(key)) continue;
        parts.push(key + "=" + merged[key]);
    }
    if (parts.length === 0) return "";
    return parts.join("; ") + ";";
}

function stvGetHeaderValue(headers, wantedName) {
    if (!headers || !wantedName) return "";
    var lowerWanted = String(wantedName).toLowerCase();
    if (typeof headers.get === "function") {
        var direct = headers.get(wantedName);
        if (direct) return String(direct);
        var lowered = headers.get(lowerWanted);
        if (lowered) return String(lowered);
    }
    var keys = [wantedName, lowerWanted, "Set-Cookie", "set-cookie"];
    for (var i = 0; i < keys.length; i++) {
        var key = keys[i];
        if (typeof headers[key] !== "undefined" && headers[key] !== null) {
            var value = headers[key];
            if (Object.prototype.toString.call(value) === "[object Array]") {
                return value.join("; ");
            }
            return String(value);
        }
    }
    return "";
}

function stvExtractSetCookie(headers) {
    return stvGetHeaderValue(headers, "set-cookie");
}

// Bỏ qua stvSyncCloudflareCookie do nó gọi Engine.newBrowser() phức tạp
function stvSyncCloudflareCookie(base, hintUrl) {
    return false;
}

function stvIsCloudflareBlockedResponse(responseLike) {
    return false;
}

function stvFindReadContextId(setCookieText) {
    var text = stvTrim(setCookieText);
    if (!text) return "";
    var match = text.match(/readcontextid=([^;\s]+)/i);
    return match && match[1] ? match[1] : "";
}

function stvBuildBookUrl(base, host, bookid, status) {
    var state = stvTrim(status);
    if (!state) state = "1";
    return stvBuildUrl(base, "/truyen/" + stvEncode(host) + "/" + stvEncode(state) + "/" + stvEncode(bookid) + "/");
}
