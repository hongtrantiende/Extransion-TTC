var STV_ORIGIN = (typeof stv_origin !== "undefined" && stv_origin ? stv_origin.replace(/\/$/, "") : "http://103.82.20.93");
var STV_DESKTOP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36";
var STV_ANDROID_UA = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36";
var STV_URL_REGEX = /\/truyen\/([^\/]+)\/\d+\/(\d+)(?:\/(\d+))?\/?$/i;
var STV_CJK_CHAR_CLASS = "\\u3400-\\u4DBF\\u4E00-\\u9FFF\\uF900-\\uFAFF";
var STV_CJK_PUNCT_CLASS = "\\u3000-\\u303F\\uFF00-\\uFFEF";
var STV_CJK_TOKEN_CLASS = STV_CJK_CHAR_CLASS + STV_CJK_PUNCT_CLASS;

var PROXY_URL = (typeof proxy_url !== "undefined" && proxy_url ? proxy_url.replace(/\/$/, "") : "");
var PROXY_TOKEN = (typeof proxy_token !== "undefined" && proxy_token ? proxy_token : "");
var AI_MODE = (typeof ai_mode !== "undefined" && ai_mode ? String(ai_mode).trim().toLowerCase() : "llm");

function getStvHeaders() {
    var lang = AI_MODE === "llm" ? "vi" : "zh";
    return {
        "Cookie": "lang=" + lang + "; transmode=1",
        "User-Agent": STV_DESKTOP_UA
    };
}

function getStvTocHeaders(meta) {
    var lang = AI_MODE === "llm" ? "vi" : "zh";
    return {
        "Cookie": "lang=" + lang + "; transmode=1",
        "User-Agent": STV_DESKTOP_UA,
        "Referer": buildStvBookUrl(meta)
    };
}

function safeStvText(value) {
    if (!value) {
        return "";
    }

    return String(value).replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
}

var STV_DOMAIN_REGEX = /^(https?:\/\/(?:[\w-]+\.)*(?:sangtacviet\.(?:app|com|pro|vip)|14\.225\.254\.182|103\.82\.20\.93))/i;

function normalizeStvUrl(url) {
    if (!url) {
        return STV_ORIGIN;
    }

    if (/^https?:\/\//i.test(url)) {
        return url; // giữ nguyên domain gốc từ URL được chia sẻ
    }

    if (url.charAt(0) !== "/") {
        url = "/" + url;
    }

    return STV_ORIGIN + url;
}

function normalizeStvImageUrl(url) {
    url = safeStvText(url);
    if (!url) {
        return "";
    }

    if (url.indexOf("//") === 0) {
        return "https:" + url;
    }

    if (url.charAt(0) === "/") {
        return STV_ORIGIN + url;
    }

    if (url.indexOf("http://") === 0) {
        return "https://" + url.substring(7);
    }

    return url;
}

function parseStvUrl(url) {
    let origin = STV_ORIGIN;
    let domainMatch = STV_DOMAIN_REGEX.exec(url);
    if (domainMatch) {
        origin = domainMatch[1];
    }
    let normalized = normalizeStvUrl(url);
    let match = STV_URL_REGEX.exec(normalized);
    if (!match) {
        return null;
    }

    return {
        host: match[1],
        bookId: match[2],
        chapterId: match[3] || "",
        origin: origin,
        url: normalized
    };
}

function buildStvBookUrl(meta) {
    return (meta.origin || STV_ORIGIN) + "/truyen/" + meta.host + "/1/" + meta.bookId + "/";
}

function normalizeStvBookLink(url) {
    let meta = parseStvUrl(url);
    return meta ? buildStvBookUrl(meta) : normalizeStvUrl(url);
}

function buildStvChapterUrl(meta, chapterId) {
    return buildStvBookUrl(meta) + chapterId + "/";
}

function buildStvTocEndpoint(meta) {
    return (meta.origin || STV_ORIGIN) + "/index.php?ngmar=chapterlist&h=" + meta.host + "&bookid=" + meta.bookId + "&sajax=getchapterlist";
}

function firstStvText(doc, selectors) {
    for (let i = 0; i < selectors.length; i++) {
        let value = safeStvText(doc.select(selectors[i]).text());
        if (value) {
            return value;
        }
    }

    return "";
}

function firstStvAttr(doc, selectors, attr) {
    for (let i = 0; i < selectors.length; i++) {
        let nodes = doc.select(selectors[i]);
        if (nodes && nodes.length > 0) {
            let value = safeStvText(nodes.first().attr(attr));
            if (value) {
                return value;
            }
        }
    }

    return "";
}

function parseStvListing(doc) {
    let items = [];
    let cards = doc.select(".booksearch");

    cards.forEach(function(card) {
        let name = safeStvText(card.select(".searchbooktitle").text());
        let description = safeStvText(card.select(".searchtag").last().text()) || safeStvText(card.select(".searchtag").first().text());
        let link = safeStvText(card.attr("href"));
        if (!link) {
            let nestedLink = card.select("a");
            if (nestedLink && nestedLink.length > 0) {
                link = safeStvText(nestedLink.first().attr("href"));
            }
        }

        if (!name || !link) {
            return;
        }

        items.push({
            name: name,
            link: normalizeStvBookLink(link),
            cover: normalizeStvImageUrl(firstStvAttr(card, ["img"], "data-src") || firstStvAttr(card, ["img"], "src")),
            description: description,
            host: STV_ORIGIN
        });
    });

    return items;
}

function parseStvChapterList(data) {
    let chapters = [];
    if (!data) {
        return chapters;
    }

    let rows = String(data).split("-//-");
    for (let i = 0; i < rows.length; i++) {
        let parts = rows[i].split("-/-");
        if (parts.length < 3) {
            continue;
        }

        let chapterId = safeStvText(parts[1]);
        let rawName = safeStvText(parts.slice(2).join("-/-"));
        // Detect VIP marker trước khi xóa
        let isVip = /-\/-vip\s*$/i.test(rawName);
        let name = rawName.replace(/-\/-(?:vip|unvip)\s*$/i, "").trim();
        if (!chapterId || !name) {
            continue;
        }

        chapters.push({
            chapterId: chapterId,
            name: name,
            pay: isVip
        });
    }

    return chapters;
}

// ─── LLM names storage helpers (for AI translation) ──────────────────────

var STV_LLM_LEGACY_NAMES_STORAGE_PREFIX = "STV_LLM_NAMES_";

function getStvLocalStorage() {
    try {
        if (typeof localStorage !== "undefined" && localStorage && typeof localStorage.getItem === "function" && typeof localStorage.setItem === "function") {
            return localStorage;
        }
    } catch (e) {}
    return undefined;
}

function readStvStorageText(key) {
    var storage = getStvLocalStorage();
    if (!storage || !key) return "";
    try { var v = storage.getItem(String(key)); return typeof v === "string" ? v : ""; } catch (e) { return ""; }
}

function writeStvStorageText(key, value) {
    var storage = getStvLocalStorage();
    if (!storage || !key) return false;
    try { storage.setItem(String(key), typeof value === "undefined" ? "" : String(value)); return true; } catch (e) { return false; }
}

function deleteStvStorageText(key) {
    var storage = getStvLocalStorage();
    if (!storage || !key) return false;
    try { if (typeof storage.removeItem === "function") { storage.removeItem(String(key)); return true; } } catch (e) {}
    return false;
}

function hasStvStorageKey(key) {
    var storage = getStvLocalStorage();
    if (!storage || !key) return false;
    try { return storage.getItem(String(key)) !== null; } catch (e) { return false; }
}

function getStvStorageKeys() {
    var storage = getStvLocalStorage();
    var keys = [];
    if (!storage) return keys;
    try {
        var len = Number(storage.length || 0);
        for (var i = 0; i < len; i++) {
            var k = storage.key(i);
            if (typeof k === "string" && k) keys.push(k);
        }
    } catch (e) {}
    return keys;
}

function buildStvStorageSegment(value, fallback) {
    var text = safeStvText(value).toLowerCase().replace(/[^\w-]+/g, "_").replace(/^_+|_+$/g, "");
    return text || fallback || "unknown";
}

function buildStvLlmBookStorageId(meta) {
    if (!meta) return "unknown_0";
    return buildStvStorageSegment(meta.host, "unknown") + "_" + buildStvStorageSegment(meta.bookId, "0");
}

function getStvLegacyLlmBookStorageKey(meta) {
    return "STV_LLM_BOOK_" + buildStvLlmBookStorageId(meta);
}

function getStvLegacyLlmNamesStorageKey(meta) {
    return STV_LLM_LEGACY_NAMES_STORAGE_PREFIX + buildStvLlmBookStorageId(meta);
}

function getStvNativeLlmNamesStorageKey(meta) {
    if (!meta) return "";
    return safeStvText(meta.host).replace(/\s+/g, "") + safeStvText(meta.bookId).replace(/\s+/g, "");
}

function buildStvLlmNamesStorageKey(meta, bookName) {
    var text = String(bookName || "").replace(/\r?\n/g, " ").replace(/\s+/g, " ").trim();
    return text || (meta ? ("Truyện Sáng Tác Việt " + meta.bookId) : "Truyện");
}

function findStvExistingLlmNamesStorageKey(meta, bookName) {
    var titleKey = buildStvLlmNamesStorageKey(meta, bookName);
    if (titleKey && hasStvStorageKey(titleKey)) return titleKey;
    if (!meta) return "";

    var legacyKey = getStvLegacyLlmNamesStorageKey(meta);
    var suffix = "_" + buildStvLlmBookStorageId(meta);
    var keys = getStvStorageKeys();

    for (var i = 0; i < keys.length; i++) {
        var key = keys[i];
        if (key === legacyKey) return key;
        if (key.indexOf(STV_LLM_LEGACY_NAMES_STORAGE_PREFIX) === 0 && key.lastIndexOf(suffix) === key.length - suffix.length) return key;
    }

    if (hasStvStorageKey(legacyKey)) return legacyKey;
    return "";
}

function normalizeStvLlmNamesText(value) {
    var text = String(value || "").replace(/\r/g, "");
    if (text.indexOf("~//~") !== -1) text = text.replace(/~\/\/~/g, "\n");
    var lines = text.split("\n");
    var output = [];
    var seen = {};
    for (var i = 0; i < lines.length; i++) {
        var line = String(lines[i] || "").replace(/\t/g, " ").trim();
        if (line.charAt(0) === "$") line = line.substring(1).trim();
        if (!line || line.indexOf("#") === 0 || line.indexOf("//") === 0) continue;
        line = line.replace(/[ ]{2,}/g, " ");
        if (Object.prototype.hasOwnProperty.call(seen, line)) continue;
        seen[line] = true;
        output.push(line);
    }
    return output.join("\n").trim();
}

function resolveStvBookTitle(meta, fallbackTitle) {
    if (!meta) return safeStvText(fallbackTitle);
    if (typeof meta.bookTitle !== "undefined") return safeStvText(meta.bookTitle) || safeStvText(fallbackTitle);
    var title = safeStvText(fallbackTitle);
    try {
        var resp = fetch(buildStvBookUrl(meta), { headers: getStvHeaders() });
        if (resp.ok) {
            var doc = resp.html();
            title = firstStvText(doc, ["#book_name2", "h1", ".book_name"]);
            if (!title) {
                var htmlContent = doc.html() || "";
                var mName = htmlContent.match(/"name(?:vi)?"\s*:\s*"([^"]+)"/);
                if (mName && mName[1]) title = mName[1];
            }
        }
    } catch (e) {}
    meta.bookTitle = safeStvText(title);
    return meta.bookTitle;
}

function mergeStvLlmNamesText(values) {
    var output = [];
    var seen = {};
    for (var i = 0; i < values.length; i++) {
        var normalized = normalizeStvLlmNamesText(values[i]);
        if (!normalized) continue;
        var lines = normalized.split("\n");
        for (var j = 0; j < lines.length; j++) {
            var line = lines[j];
            if (!line || Object.prototype.hasOwnProperty.call(seen, line)) continue;
            seen[line] = true;
            output.push(line);
        }
    }
    return output.join("\n").trim();
}

function parseStvLlmBookTitle(value) {
    var text = safeStvText(value);
    if (!text) return "";
    if (text.charAt(0) === "{") {
        try {
            var parsed = JSON.parse(text);
            if (parsed && typeof parsed === "object") return safeStvText(parsed.title || parsed.bookName || parsed.name);
        } catch (e) {}
    }
    return text;
}

function registerStvLlmBook(meta, bookName, options) {
    if (!meta) return {};
    options = options || {};

    var storageId = buildStvLlmBookStorageId(meta);
    var legacyBookKey = getStvLegacyLlmBookStorageKey(meta);
    var legacyNamesKey = getStvLegacyLlmNamesStorageKey(meta);
    var nativeNamesKey = getStvNativeLlmNamesStorageKey(meta);
    var legacyTitle = parseStvLlmBookTitle(readStvStorageText(legacyBookKey));
    var title = resolveStvBookTitle(meta, safeStvText(bookName) || safeStvText(options.bookName) || legacyTitle || "Truyện Sáng Tác Việt " + meta.bookId);
    var existingNamesKey = findStvExistingLlmNamesStorageKey(meta, title);
    var namesKey = buildStvLlmNamesStorageKey(meta, title);
    var normalizedNames = mergeStvLlmNamesText([
        readStvStorageText(namesKey),
        readStvStorageText(existingNamesKey),
        readStvStorageText(legacyNamesKey),
        readStvStorageText(nativeNamesKey)
    ]);

    writeStvStorageText(namesKey, normalizedNames);
    if (existingNamesKey && existingNamesKey !== namesKey) deleteStvStorageText(existingNamesKey);
    if (legacyNamesKey && legacyNamesKey !== namesKey) deleteStvStorageText(legacyNamesKey);
    deleteStvStorageText(legacyBookKey);
    deleteStvStorageText("STV_LLM_BOOK_INDEX");

    return { storageId: storageId, title: title, namesKey: namesKey, nativeNamesKey: nativeNamesKey };
}