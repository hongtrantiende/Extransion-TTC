let BASE_URL = "https://teamsany.com";

try { if (CONFIG_URL) BASE_URL = CONFIG_URL; } catch (e) {}

function changeDomainLegacy(anyUrl, newBase) {
  var m = String(anyUrl).match(/^https?:\/\/[^\/]+(\/.*)?$/i);
  if (!m) return anyUrl;
  var rest = m[1] || "/";

  return String(newBase).replace(/\/+$/, "") + rest;
}