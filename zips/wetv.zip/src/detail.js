load("shared.js");

function execute(input) {
    return Response.success(buildWetvDetail(input));
}
