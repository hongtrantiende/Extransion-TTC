load("shared.js");

function execute() {
    return Response.success(commonHomeList());
}
