var WETV_BASE = "https://wetv.vip";
var WETV_LANG_PATH = "/vi";
var WETV_API_BASE = WETV_BASE + "/api";
var WETV_PLAY_BASE = "https://play.wetv.vip";
var WETV_FILTER_API = "https://pbaccess.wetv.vip/trpc.video_app_international.trpc_filter_page.FilterPage/GetFilterPage";
function getWetvNextBuildId() {
    try {
        var response = fetch("https://wetv.vip/vi", {
            headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            }
        });
        var html = response ? String(response.text() || "") : "";
        if (html) {
            var match = html.match(/"buildId"\s*:\s*"([^"]+)"/);
            if (match && match[1]) return String(match[1]).trim();
            match = html.match(/\/_next\/static\/([^\/]+)\/_buildManifest\.js/);
            if (match && match[1]) return String(match[1]).trim();
        }
    } catch (e) {}
    return "wetv_prod_4810"; // Fallback
}
var WETV_NEXT_BUILD = getWetvNextBuildId();
var WETV_COUNTRY_CODE = "153569";
var WETV_LANG_CODE = "1491994";
var WETV_LANG = "vi";
var WETV_VIDEO_APPID = "1200004";
var WETV_PLATFORM = "4830201";
var WETV_SDTFROM = "1002";
var WETV_APP_VER = "2.8.44";
var WETV_GUID_KEY = "wetv.guid.v1";
var WETV_COOKIE_STORE_KEY = "wetv.cookie.store.v1";
var WETV_COOKIE_TTL_MS = 12 * 60 * 60 * 1000;
var WETV_PAGE_CTX_PREFIX = "wetv.pagectx.v1:";
var WETV_FILTER_CTX_PREFIX = "wetv.filterctx.v1:";
var WETV_SUGGEST_CACHE_PREFIX = "wetv.suggest.v1:";

var WETV_QUALITY_LABELS = {
    ld: "144P",
    sd: "360P",
    hd: "480P",
    shd: "720P",
    fhd: "1080P",
    uhd: "4K",
    hdr10: "HDR",
    dolby: "Dolby"
};

function trimText(value) {
    if (value == null) return "";
    return String(value).replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "");
}

function isArray(value) {
    return Object.prototype.toString.call(value) === "[object Array]";
}

function safeJsonParse(text) {
    try {
        return JSON.parse(String(text || ""));
    } catch (e) {
        return null;
    }
}

function decodeURIComponentSafe(value) {
    try {
        return decodeURIComponent(String(value || "").replace(/\+/g, " "));
    } catch (e) {
        return String(value || "");
    }
}

function htmlEscape(text) {
    return String(text == null ? "" : text)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

function htmlDescription(text) {
    text = trimText(text);
    return text ? "<p>" + htmlEscape(text) + "</p>" : "";
}

function joinParts(parts, sep) {
    var out = [];
    for (var i = 0; i < parts.length; i++) {
        var value = trimText(parts[i]);
        if (value) out.push(value);
    }
    return out.join(sep || " · ");
}

function firstValue(obj, keys) {
    obj = obj || {};
    for (var i = 0; i < keys.length; i++) {
        var value = obj[keys[i]];
        if (value != null && value !== "") return value;
    }
    return "";
}

function buildQuery(params, keepEmpty) {
    var parts = [];
    for (var key in params) {
        if (!params.hasOwnProperty(key)) continue;
        if (params[key] == null) continue;
        if (!keepEmpty && params[key] === "") continue;
        parts.push(encodeURIComponent(key) + "=" + encodeURIComponent(String(params[key])));
    }
    return parts.join("&");
}

function appendQuery(url, params, keepEmpty) {
    var query = buildQuery(params || {}, keepEmpty);
    if (!query) return url;
    return url + (url.indexOf("?") >= 0 ? "&" : "?") + query;
}

function getUrlOrigin(url) {
    var match = String(url || "").match(/^(https?:\/\/[^\/?#]+)/i);
    return match && match[1] ? match[1] : "";
}

function getUrlHost(url) {
    var match = String(url || "").match(/^https?:\/\/([^\/?#]+)/i);
    return match && match[1] ? String(match[1]).toLowerCase() : "";
}

function normalizeUrl(url) {
    url = trimText(url).replace(/&amp;/g, "&");
    if (!url) return "";
    if (url.indexOf("wetv:") === 0 || url.indexOf("tenvideoi18n://") === 0) return url;
    if (url.indexOf("//") === 0) return "https:" + url;
    if (url.indexOf("/") === 0) return WETV_BASE + url;
    if (!/^[a-zA-Z]+:\/\//.test(url)) return WETV_BASE + "/" + url.replace(/^\/+/, "");
    return url;
}

function normalizeImage(url) {
    url = normalizeUrl(url);
    return url ? url.replace(/^http:\/\//i, "https://") : "";
}

function getQueryParam(url, key) {
    var re = new RegExp("[?&]" + String(key || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "=([^&#]*)", "i");
    var match = String(url || "").match(re);
    return match && match[1] ? decodeURIComponentSafe(match[1]) : "";
}

function getStoredValue(key) {
    try {
        if (typeof localStorage !== "undefined" && localStorage && localStorage.getItem) return localStorage.getItem(key) || "";
    } catch (e) {}
    return "";
}

function setStoredValue(key, value) {
    try {
        if (typeof localStorage !== "undefined" && localStorage && localStorage.setItem) {
            localStorage.setItem(key, value);
            return true;
        }
    } catch (e) {}
    return false;
}

function getSessionCacheValue(key) {
    try {
        if (typeof cacheStorage !== "undefined" && cacheStorage && cacheStorage.getItem) return cacheStorage.getItem(key) || "";
    } catch (e) {}
    return "";
}

function setSessionCacheValue(key, value) {
    try {
        if (typeof cacheStorage !== "undefined" && cacheStorage && cacheStorage.setItem) {
            cacheStorage.setItem(key, value);
            return true;
        }
    } catch (e) {}
    return false;
}

function removeSessionCacheValue(key) {
    try {
        if (typeof cacheStorage !== "undefined" && cacheStorage) {
            if (typeof cacheStorage.removeItem === "function") {
                cacheStorage.removeItem(key);
                return true;
            }
            if (typeof cacheStorage.deleteItem === "function") {
                cacheStorage.deleteItem(key);
                return true;
            }
            if (typeof cacheStorage["delete"] === "function") {
                cacheStorage["delete"](key);
                return true;
            }
            if (typeof cacheStorage.setItem === "function") {
                cacheStorage.setItem(key, "");
                return true;
            }
        }
    } catch (e) {}
    return false;
}

function randomHex(length) {
    var out = "";
    for (var i = 0; i < length; i++) out += Math.floor(Math.random() * 16).toString(16);
    return out;
}

function getWetvGuid() {
    var guid = trimText(getStoredValue(WETV_GUID_KEY));
    if (!/^[0-9a-f]{16,32}$/i.test(guid)) {
        guid = randomHex(32);
        setStoredValue(WETV_GUID_KEY, guid);
    }
    return guid;
}

function readCookieStore() {
    var parsed = safeJsonParse(getStoredValue(WETV_COOKIE_STORE_KEY));
    return parsed && typeof parsed === "object" ? parsed : {};
}

function writeCookieStore(store) {
    setStoredValue(WETV_COOKIE_STORE_KEY, JSON.stringify(store || {}));
}

function readRuntimeCookie(url) {
    var cookie = "";
    try {
        if (typeof localCookie !== "undefined" && localCookie && typeof localCookie.getCookie === "function") {
            cookie = mergeCookieHeaders(cookie, localCookie.getCookie(url));
        }
    } catch (e) {}
    try {
        if (typeof document !== "undefined" && document && document.cookie) {
            cookie = mergeCookieHeaders(cookie, document.cookie);
        }
    } catch (e2) {}
    return normalizeCookieHeader(cookie);
}

function readStoredCookieForUrl(url) {
    var origin = getUrlOrigin(url);
    if (!origin) return "";
    var store = readCookieStore();
    var item = store[origin] || {};
    var cookie = normalizeCookieHeader(item.cookie || "");
    var savedAt = Number(item.savedAt || 0);
    if (cookie && savedAt && new Date().getTime() - savedAt <= WETV_COOKIE_TTL_MS) return cookie;
    if (store[origin]) {
        delete store[origin];
        writeCookieStore(store);
    }
    return "";
}

function saveCookieForUrl(url, setCookieText) {
    var origin = getUrlOrigin(url);
    if (!origin) return "";
    var incoming = normalizeSetCookieHeader(setCookieText);
    if (!incoming) return "";
    var merged = mergeCookieHeaders(readStoredCookieForUrl(url), incoming);
    if (!merged) return "";
    var store = readCookieStore();
    store[origin] = { cookie: merged, savedAt: new Date().getTime() };
    writeCookieStore(store);
    return merged;
}

function buildPublicCookieHeader() {
    var guid = getWetvGuid();
    return normalizeCookieHeader([
        "guid=" + guid,
        "video_guid=" + guid,
        "uin=" + guid,
        "wetv_pt=v",
        "vplatform=2",
        "country_code=" + WETV_COUNTRY_CODE,
        "lang_code=" + WETV_LANG_CODE,
        "wetv_lang=" + WETV_LANG,
        "video_appid=" + WETV_VIDEO_APPID
    ].join("; "));
}

function buildWetvCookieHeader(url) {
    return mergeCookieHeaders(
        buildPublicCookieHeader(),
        mergeCookieHeaders(readStoredCookieForUrl(url), readRuntimeCookie(url))
    );
}

function buildRuntimeCookieHeader(url) {
    return mergeCookieHeaders(readStoredCookieForUrl(url), readRuntimeCookie(url));
}

function buildMediaCookieHeader(url) {
    var host = getUrlHost(url);
    if (/(\.|^)wetv\.vip$/i.test(host)) return buildRuntimeCookieHeader(url);
    return readStoredCookieForUrl(url);
}

function buildAllWetvCookieHeader(primaryUrl) {
    return mergeCookieHeaders(
        mergeCookieHeaders(buildWetvCookieHeader(WETV_BASE), buildWetvCookieHeader(WETV_PLAY_BASE)),
        primaryUrl ? buildWetvCookieHeader(primaryUrl) : ""
    );
}

function mergeCookieHeaders(left, right) {
    var jar = {};
    addCookieHeaderToJar(jar, left);
    addCookieHeaderToJar(jar, right);
    var out = [];
    for (var key in jar) {
        if (jar.hasOwnProperty(key) && key) out.push(key + "=" + jar[key]);
    }
    return out.join("; ");
}

function addCookieHeaderToJar(jar, text) {
    text = normalizeCookieHeader(text);
    if (!text) return;
    var parts = text.split(";");
    for (var i = 0; i < parts.length; i++) {
        var pair = trimText(parts[i]);
        var eq = pair.indexOf("=");
        if (eq <= 0) continue;
        var name = trimText(pair.slice(0, eq));
        var value = trimText(pair.slice(eq + 1));
        if (isCookieAttribute(name)) continue;
        jar[name] = value;
    }
}

function normalizeCookieHeader(text) {
    text = String(text == null ? "" : text).replace(/[\r\n]+/g, "; ");
    text = text.replace(/,\s*(?=[A-Za-z0-9_.-]+=)/g, "; ");
    var jar = {};
    var parts = text.split(";");
    for (var i = 0; i < parts.length; i++) {
        var pair = trimText(parts[i]);
        var eq = pair.indexOf("=");
        if (eq <= 0) continue;
        var name = trimText(pair.slice(0, eq));
        var value = trimText(pair.slice(eq + 1));
        if (!name || isCookieAttribute(name)) continue;
        jar[name] = value;
    }
    var out = [];
    for (var key in jar) if (jar.hasOwnProperty(key) && key) out.push(key + "=" + jar[key]);
    return out.join("; ");
}

function normalizeSetCookieHeader(text) {
    text = String(text == null ? "" : text);
    if (!text) return "";
    var chunks = text.replace(/\r/g, "\n").split(/\n|,(?=\s*[A-Za-z0-9_.-]+=)/);
    var out = [];
    for (var i = 0; i < chunks.length; i++) {
        var first = trimText(String(chunks[i] || "").split(";")[0]);
        var eq = first.indexOf("=");
        if (eq <= 0) continue;
        var name = trimText(first.slice(0, eq));
        if (!name || isCookieAttribute(name)) continue;
        out.push(name + "=" + trimText(first.slice(eq + 1)));
    }
    return normalizeCookieHeader(out.join("; "));
}

function isCookieAttribute(name) {
    name = String(name || "").toLowerCase();
    return name === "path" || name === "domain" || name === "expires" || name === "max-age" ||
        name === "secure" || name === "httponly" || name === "samesite" || name === "priority";
}

function getCookieValue(cookie, name) {
    var parts = normalizeCookieHeader(cookie).split(";");
    for (var i = 0; i < parts.length; i++) {
        var pair = trimText(parts[i]);
        var eq = pair.indexOf("=");
        if (eq <= 0) continue;
        if (trimText(pair.slice(0, eq)) === name) return trimText(pair.slice(eq + 1));
    }
    return "";
}

function collectResponseHeaders(headers) {
    var out = {};
    if (!headers) return out;
    try {
        if (typeof headers.forEach === "function") {
            headers.forEach(function (value, key) {
                out[String(key || "").toLowerCase()] = String(value || "");
            });
        }
    } catch (e) {}
    var keys = ["set-cookie", "Set-Cookie", "content-type", "location", "Location"];
    for (var i = 0; i < keys.length; i++) {
        var value = getHeaderValue(headers, keys[i]);
        if (value) out[String(keys[i]).toLowerCase()] = value;
    }
    return out;
}

function getHeaderValue(headers, name) {
    if (!headers) return "";
    var names = [name, String(name || "").toLowerCase(), headerTitleCase(name)];
    for (var i = 0; i < names.length; i++) {
        try {
            if (typeof headers.get === "function") {
                var direct = headers.get(names[i]);
                if (direct) return String(direct);
            } else if (headers[names[i]]) {
                return String(headers[names[i]]);
            }
        } catch (e) {}
    }
    return "";
}

function headerTitleCase(name) {
    return String(name || "").replace(/(^|-)([a-z])/g, function (_, a, b) {
        return a + String(b || "").toUpperCase();
    });
}

function getDefaultHeaders(extra, url) {
    url = normalizeUrl(url || WETV_BASE);
    var headers = {
        Accept: "application/json,text/plain,text/html,*/*",
        "Accept-Language": "vi,en;q=0.9,en-US;q=0.8,zh-CN;q=0.7,zh;q=0.6",
        Referer: WETV_BASE + WETV_LANG_PATH
    };
    var cookie = buildWetvCookieHeader(url);
    if (cookie) headers.Cookie = cookie;
    extra = extra || {};
    for (var key in extra) {
        if (extra.hasOwnProperty(key) && extra[key] != null) headers[key] = extra[key];
    }
    return headers;
}

function getWetvUserAgent() {
    var userAgent = appWetvUserAgent("system");
    if (userAgent) return userAgent;
    userAgent = appWetvUserAgent("chrome");
    if (userAgent) return userAgent;
    userAgent = appWetvUserAgent("android");
    if (userAgent) return userAgent;
    try {
        if (typeof navigator !== "undefined" && navigator && navigator.userAgent) return String(navigator.userAgent || "");
    } catch (e) {}
    return "";
}

function appWetvUserAgent(kind) {
    try {
        if (typeof UserAgent !== "undefined" && UserAgent && typeof UserAgent[kind] === "function") {
            var userAgent = String(UserAgent[kind]() || "");
            if (userAgent) return userAgent;
        }
    } catch (e) {}
    try {
        if (typeof userAgents === "function") {
            var value = kind ? userAgents(kind) : userAgents();
            value = String(value || "");
            if (value) return value;
        }
    } catch (e2) {}
    return "";
}

function fetchText(url, options) {
    url = normalizeUrl(url);
    options = options || {};
    var rawHeaders = !!options.rawHeaders;
    delete options.rawHeaders;
    options.headers = rawHeaders ? (options.headers || {}) : getDefaultHeaders(options.headers || {}, url);
    var response = fetch(url, options);
    var text = "";
    try {
        text = String(response.text() || "");
    } catch (e) {}
    var result = {
        url: response && response.url ? String(response.url || url) : String(url || ""),
        status: response && typeof response.status !== "undefined" ? response.status : 0,
        ok: !!(response && response.ok),
        text: text,
        headers: collectResponseHeaders(response && response.headers),
        response: response
    };
    var setCookie = result.headers["set-cookie"] || "";
    if (setCookie) saveCookieForUrl(result.url || url, setCookie);
    return result;
}

function fetchJson(url, options) {
    var result = fetchText(url, options || {});
    var text = trimText(result.text);
    var json = safeJsonParse(unwrapJsonp(text));
    if (!json && text.indexOf("{") >= 0) json = safeJsonParse(text.substring(text.indexOf("{"), text.lastIndexOf("}") + 1));
    if (!json) throw new Error("WeTV không trả JSON: HTTP " + result.status);
    return json;
}

function unwrapJsonp(text) {
    text = trimText(text);
    var first = text.indexOf("(");
    var last = text.lastIndexOf(")");
    if (first > 0 && last > first && /^[\w$.]+$/.test(text.slice(0, first))) return text.slice(first + 1, last);
    return text;
}

function postJson(url, body, referer) {
    return fetchJson(url, {
        method: "POST",
        body: JSON.stringify(body || {}),
        headers: {
            "Content-Type": "application/json",
            Origin: WETV_BASE,
            Referer: referer || (WETV_BASE + WETV_LANG_PATH)
        }
    });
}

function commonHomeList() {
    return [
        { title: "Đề xuất", input: buildListInput("channel", { id: "1001", title: "Đề xuất", home: true }), script: "gen.js" },
        { title: "Phim truyền hình", input: buildListInput("channel", { id: "10274", title: "Phim truyền hình" }), script: "gen.js" },
        { title: "Phim điện ảnh", input: buildListInput("channel", { id: "10276", title: "Phim điện ảnh" }), script: "gen.js" },
        { title: "Anime", input: buildListInput("channel", { id: "10277", title: "Anime" }), script: "gen.js" },
        { title: "Miễn phí", input: buildListInput("channel", { id: "10373", title: "Miễn phí" }), script: "gen.js" },
        { title: "Tất cả hot", input: buildListInput("filter", { title: "Tất cả hot", choice: defaultFilterChoice({ first_category: "0", sort: "2" }) }), script: "gen.js" },
        { title: "Mới nhất", input: buildListInput("filter", { title: "Mới nhất", choice: defaultFilterChoice({ first_category: "0", sort: "1" }) }), script: "gen.js" },
        { title: "Đánh giá cao", input: buildListInput("filter", { title: "Đánh giá cao", choice: defaultFilterChoice({ first_category: "0", sort: "4" }) }), script: "gen.js" }
    ];
}

function commonGenreList() {
    var out = [
        { title: "Đề xuất", input: buildListInput("channel", { id: "1001", title: "Đề xuất", home: true }), script: "gen.js" },
        { title: "Phim truyền hình", input: buildListInput("filter", { title: "Phim truyền hình", choice: defaultFilterChoice({ first_category: "2" }) }), script: "gen.js" },
        { title: "Phim điện ảnh", input: buildListInput("filter", { title: "Phim điện ảnh", choice: defaultFilterChoice({ first_category: "1" }) }), script: "gen.js" },
        { title: "Anime", input: buildListInput("filter", { title: "Anime", choice: defaultFilterChoice({ first_category: "3" }) }), script: "gen.js" }
    ];
    try {
        var json = fetchFilteredRaw(defaultFilterChoice({ first_category: "0" }), "");
        var data = getFilterData(json);
        var dims = data.filter && isArray(data.filter.dimensions) ? data.filter.dimensions : [];
        appendFilterDimensionLinks(out, dims);
    } catch (e) {
        appendStaticGenreFallback(out);
    }
    return dedupeMenu(out);
}

function appendFilterDimensionLinks(out, dims) {
    var labels = {
        sort: "Sắp xếp",
        first_category: "Danh mục",
        category_value: "Nhóm",
        "main_genre_id,sub_genre_id": "Thể loại",
        year: "Năm",
        pay_status: "Gói",
        area_id: "Khu vực"
    };
    for (var i = 0; i < dims.length; i++) {
        var dim = dims[i] || {};
        var key = trimText(dim.key || "");
        if (!key || !isArray(dim.options)) continue;
        var label = labels[key] || trimText(dim.name || key);
        for (var j = 0; j < dim.options.length; j++) {
            var opt = dim.options[j] || {};
            var value = trimText(opt.value || "");
            var name = trimText(opt.name || "");
            if (!name || !value || value === "0") continue;
            var choice = defaultFilterChoice({});
            choice[key] = value;
            if (key !== "sort") choice.sort = "2";
            out.push({
                title: label ? (label + ": " + name) : name,
                input: buildListInput("filter", { title: name, choice: choice }),
                script: "gen.js"
            });
        }
    }
}

function appendStaticGenreFallback(out) {
    var genres = ["Lãng mạn", "Cổ trang", "Hành động", "Kinh dị", "Hài", "BL", "Thái Lan", "Trung Quốc", "Hàn Quốc"];
    for (var i = 0; i < genres.length; i++) {
        out.push({ title: genres[i], input: genres[i], script: "search.js" });
    }
}

function dedupeMenu(list) {
    var out = [];
    var seen = {};
    for (var i = 0; i < list.length; i++) {
        var item = list[i] || {};
        var key = item.title + "|" + item.input;
        if (!item.title || seen[key]) continue;
        seen[key] = true;
        out.push(item);
    }
    return out;
}

function buildListInput(mode, params) {
    params = params || {};
    params.mode = mode;
    return "wetv:list:" + encodeURIComponent(JSON.stringify(params));
}

function parseListInput(input) {
    input = trimText(input);
    if (input.indexOf("wetv:list:") === 0) return safeJsonParse(decodeURIComponentSafe(input.slice("wetv:list:".length))) || {};
    var json = safeJsonParse(input);
    if (json) return json;
    return { mode: "channel", id: input || "1001", title: input || "Đề xuất" };
}

function buildTrackPayload(payload) {
    return "wetv:track:" + encodeURIComponent(JSON.stringify(payload || {}));
}

function parseTrackPayload(input) {
    input = trimText(input);
    if (input.indexOf("wetv:track:") === 0) return safeJsonParse(decodeURIComponentSafe(input.slice("wetv:track:".length))) || {};
    var json = safeJsonParse(input);
    if (json) return json;
    var ids = parseWetvInput(input);
    ids.url = input;
    return ids;
}

function defaultFilterChoice(extra) {
    var choice = {
        first_category: "0",
        sort: "2",
        "main_genre_id,sub_genre_id": "0",
        category_value: "0",
        year: "0",
        pay_status: "0",
        area_id: "0"
    };
    extra = extra || {};
    for (var key in extra) if (extra.hasOwnProperty(key)) choice[key] = extra[key];
    return choice;
}

function fetchWetvList(input, page) {
    var params = parseListInput(input);
    if (params.mode === "suggest") return {
        items: dedupeCards(isArray(params.cards) ? params.cards : []),
        next: null
    };
    if (params.mode === "suggest_cache") {
        var text = params.key ? getSessionCacheValue(params.key) : "";
        if (params.key) removeSessionCacheValue(params.key);
        var cards = safeJsonParse(text);
        if (!isArray(cards) && isArray(params.cards)) cards = params.cards;
        return {
            items: dedupeCards(isArray(cards) ? cards : []),
            next: null
        };
    }
    if (params.mode === "filter") return fetchFilterList(params, page);
    return fetchChannelList(params, page);
}

function fetchChannelList(params, page) {
    params = params || {};
    var id = trimText(params.id || (params.home ? "1001" : "1001"));
    page = Math.max(1, Number(page || 1));
    var data = fetchChannelPageData(id, page);
    var cards = buildCardsFromModules(data.modules || []);
    return {
        items: dedupeCards(cards),
        next: data.has_next_page && data.page_ctx ? String(page + 1) : null
    };
}

function fetchChannelPageData(id, page) {
    var key = "channel:" + id;
    var data = null;
    var ctx = "";
    for (var current = 1; current <= page; current++) {
        if (current === 1) {
            data = fetchInitialChannelData(id);
        } else {
            ctx = getCachedPageCtx(key, current);
            if (!ctx && data && data.page_ctx) ctx = data.page_ctx;
            if (!ctx) {
                data = fetchInitialChannelData(id);
                ctx = data.page_ctx || "";
            }
            data = fetchApiChannelPage(id, ctx);
        }
        if (data && data.page_ctx) setCachedPageCtx(key, current + 1, data.page_ctx);
    }
    return data || { modules: [], has_next_page: false, page_ctx: "" };
}

function fetchInitialChannelData(id) {
    var url;
    if (String(id) === "1001") {
        url = WETV_BASE + "/_next/data/" + WETV_NEXT_BUILD + "/index.json";
    } else {
        url = WETV_BASE + "/_next/data/" + WETV_NEXT_BUILD + "/channel/" + encodeURIComponent(id) + ".json?id=" + encodeURIComponent(id) + "&type=PAGE_TYPE_MODULE_LIST";
    }
    var json = fetchJson(url, { headers: { Referer: WETV_BASE + WETV_LANG_PATH } });
    var data = json && json.pageProps ? json.pageProps.data : null;
    if (!data) throw new Error("Không đọc được danh sách WeTV");
    return data;
}

function fetchApiChannelPage(id, pageCtx) {
    var json = fetchJson(appendQuery(WETV_API_BASE + "/channel", { pageCtx: pageCtx || "", id: id || "1001" }, true), {
        headers: { Referer: WETV_BASE + WETV_LANG_PATH + "/channel/" + encodeURIComponent(id || "1001") }
    });
    if (json.retCode != null && Number(json.retCode) !== 0) throw new Error("WeTV lỗi danh sách: " + (json.error && json.error.message || json.retCode));
    return json.response || { modules: [], has_next_page: false, page_ctx: "" };
}

function getCachedPageCtx(key, page) {
    return getSessionCacheValue(WETV_PAGE_CTX_PREFIX + key + ":" + page);
}

function setCachedPageCtx(key, page, ctx) {
    if (ctx) setSessionCacheValue(WETV_PAGE_CTX_PREFIX + key + ":" + page, ctx);
}

function fetchFilterList(params, page) {
    params = params || {};
    page = Math.max(1, Number(page || 1));
    var choice = defaultFilterChoice(params.choice || {});
    var cacheKey = JSON.stringify(choice);
    var ctx = "";
    var raw = null;
    for (var current = 1; current <= page; current++) {
        if (current === 1) {
            ctx = "";
        } else {
            ctx = getSessionCacheValue(WETV_FILTER_CTX_PREFIX + cacheKey + ":" + current);
            if (!ctx && raw) {
                var prev = getFilterData(raw);
                ctx = prev.page_ctx || "";
            }
        }
        raw = fetchFilteredRaw(choice, ctx);
        var data = getFilterData(raw);
        if (data.page_ctx) setSessionCacheValue(WETV_FILTER_CTX_PREFIX + cacheKey + ":" + (current + 1), data.page_ctx);
    }
    var filterData = getFilterData(raw);
    var posters = isArray(filterData.posters) ? filterData.posters : [];
    var cards = [];
    for (var i = 0; i < posters.length; i++) {
        var card = buildCardFromFilterPoster(posters[i]);
        if (card) cards.push(card);
    }
    return {
        items: dedupeCards(cards),
        next: filterData.has_next_page && filterData.page_ctx ? String(page + 1) : null
    };
}

function fetchFilteredRaw(choice, pageCtx) {
    var url = appendQuery(WETV_FILTER_API, {
        vappid: "92089330",
        vsecret: "cd21b1cef4d2ac7d600e5d3e4f1b1fb612a31b4c6ccf5c8d",
        video_appid: WETV_VIDEO_APPID,
        ver: 1
    }, false);
    return postJson(url, { user_choice: choice || defaultFilterChoice({}), page_ctx: pageCtx || "" }, WETV_BASE + WETV_LANG_PATH + "/explorar");
}

function getFilterData(json) {
    return json && json.data && json.data.data ? json.data.data : {};
}

function buildCardsFromModules(modules) {
    var cards = [];
    if (!isArray(modules)) return cards;
    for (var i = 0; i < modules.length; i++) {
        var module = modules[i] || {};
        var items = module.items || module.list || [];
        if (!isArray(items)) continue;
        for (var j = 0; j < items.length; j++) {
            var card = buildCardFromItem(items[j], module);
            if (card) cards.push(card);
        }
    }
    return cards;
}

function buildCardFromItem(item, module) {
    item = item || {};
    var type = trimText(item.type || "");
    if (/^ITEM_TYPE_/i.test(type) && !/ITEM_TYPE_(ALBUM|VIDEO|SHORT|CLIP)/i.test(type)) return null;
    var cid = normalizeWetvCid(item.cid || item.cover_id || item.album_id || item.id || "");
    var vid = normalizeWetvVid(item.vid || item.video_id || item.episode_id || "");
    var title = trimText(item.title || item.main_title || item.name || "");
    if (!title || (!cid && !vid)) return null;
    var link = buildPlayUrl(cid, vid, title);
    return {
        name: title,
        link: link,
        cover: normalizeImage(item.pic || item.img || item.img_url || item.poster || item.posterVt || ""),
        description: joinParts([item.subtitle || "", module && module.name || "", labelsText(item.mark_label_list || item.labels), item.film_score || ""], " · "),
        host: WETV_BASE,
        tag: firstLabelText(item.mark_label_list || item.labels)
    };
}

function buildCardFromFilterPoster(item) {
    item = item || {};
    var cid = normalizeWetvCid(item.cid || item.poster_id || "");
    var vid = firstVidFromList(item.vid || "");
    var title = trimText(item.main_title || item.title || "");
    if (!title || !cid) return null;
    return {
        name: title,
        link: buildPlayUrl(cid, vid, title),
        cover: normalizeImage(item.img_url || item.pic || ""),
        description: joinParts([item.subtitle || "", item.description || "", labelsText(item.mark_label_list)], " · "),
        host: WETV_BASE,
        tag: firstLabelText(item.mark_label_list)
    };
}

function firstVidFromList(value) {
    value = trimText(value);
    if (!value) return "";
    return normalizeWetvVid(value.split(",")[0]);
}

function firstLabelText(list) {
    var values = collectLabelTexts(list);
    return values.length ? values[0] : "";
}

function labelsText(list) {
    return collectLabelTexts(list).join(" · ");
}

function collectLabelTexts(list) {
    var out = [];
    if (isArray(list)) {
        for (var i = 0; i < list.length; i++) appendLabelText(out, list[i]);
    } else if (list && typeof list === "object") {
        for (var key in list) if (list.hasOwnProperty(key)) appendLabelText(out, list[key]);
    }
    return out;
}

function appendLabelText(out, item) {
    var value = trimText(item && (item.text || item.name || item.title) || item);
    if (value) out.push(value);
}

function normalizeWetvCid(value) {
    value = trimText(value);
    if (/^[a-z0-9]{8,40}$/i.test(value)) return value;
    return "";
}

function normalizeWetvVid(value) {
    value = cleanVid(value);
    if (/^[a-z][a-z0-9]{8,20}$/i.test(value)) return value;
    return "";
}

function firstNonEmpty(values) {
    for (var i = 0; i < values.length; i++) {
        var value = trimText(values[i]);
        if (value) return value;
    }
    return "";
}

function dedupeCards(cards) {
    var out = [];
    var seen = {};
    for (var i = 0; i < cards.length; i++) {
        var card = cards[i] || {};
        var key = card.link || card.name;
        if (!key || seen[key]) continue;
        seen[key] = true;
        out.push(card);
    }
    return out;
}

function searchWetv(key, page) {
    key = trimText(key);
    page = Number(page || 1);
    if (!key || page > 1) return { items: [], next: null };
    var slug = encodeURIComponent(key).replace(/%20/g, "%20");
    var url = WETV_BASE + "/_next/data/" + WETV_NEXT_BUILD + "/search/" + slug + ".json?query=" + encodeURIComponent(key).replace(/%20/g, "+");
    var json = fetchJson(url, { headers: { Referer: WETV_BASE + WETV_LANG_PATH + "/search/" + encodeURIComponent(key) } });
    var data = json && json.pageProps ? json.pageProps.data : {};
    var result = isArray(data.result) ? data.result : [];
    var cards = [];
    for (var i = 0; i < result.length; i++) {
        var card = buildSearchCard(result[i]);
        if (card) cards.push(card);
    }
    return { items: dedupeCards(cards), next: null };
}

function buildSearchCard(item) {
    item = item || {};
    var cid = normalizeWetvCid(item.cid || item.cover_id || item.id || "");
    var vid = normalizeWetvVid(item.episode_id || item.vid || item.video_id || "");
    if (!vid && isArray(item.videoDetails) && item.videoDetails.length) vid = normalizeWetvVid(item.videoDetails[0] && item.videoDetails[0].vid);
    var title = trimText(item.title || item.name || "");
    if (!title || !cid) return null;
    return {
        name: title,
        link: buildPlayUrl(cid, vid, title),
        cover: normalizeImage(item.pic || item.posterVt || item.posterHz || ""),
        description: joinParts([item.subtitle || "", item.description || "", labelsText(item.mark_label_list || item.labels)], " · "),
        host: WETV_BASE,
        tag: firstLabelText(item.mark_label_list || item.labels)
    };
}

function parseWetvInput(input) {
    if (input && typeof input === "object") {
        return {
            cid: trimText(input.cid || input.id || ""),
            vid: trimText(input.vid || input.videoId || input.episode_id || ""),
            url: normalizeUrl(input.url || input.link || input.path || "")
        };
    }
    input = trimText(input);
    var payload = safeJsonParse(input);
    if (payload) return parseWetvInput(payload);
    if (input.indexOf("wetv:track:") === 0) return parseTrackPayload(input);
    var url = normalizeUrl(input);
    var out = { cid: "", vid: "", url: url };
    var match = url.match(/\/play\/([^\/?#]+)(?:\/([^\/?#]+))?/i);
    if (match) {
        out.cid = trimText(match[1]);
        out.vid = cleanVid(trimText(match[2] || ""));
    }
    match = url.match(/\/album\/([^\/?#]+)/i);
    if (match && !out.cid) out.cid = trimText(match[1]);
    match = url.match(/\/short\/([^\/?#]+)/i);
    if (match && !out.vid) out.vid = cleanVid(trimText(match[1] || ""));
    if (!out.cid) out.cid = getQueryParam(url, "cid");
    if (!out.vid) out.vid = getQueryParam(url, "vid");
    if (!out.cid && url.indexOf("tenvideoi18n://") === 0) out.cid = getQueryParam(url, "cid");
    return out;
}

function cleanVid(value) {
    value = trimText(value);
    if (!value) return "";
    var match = value.match(/^([a-z0-9]+)/i);
    return match && match[1] ? match[1] : value;
}

function ensureWetvIds(input) {
    var ids = parseWetvInput(input);
    if (!ids.cid && ids.vid) {
        var info = fetchPlayData("", ids.vid);
        ids.cid = trimText(info.coverInfo && info.coverInfo.cid || "");
    }
    if (!ids.cid) throw new Error("Không xác định được cid WeTV");
    if (!ids.vid) {
        var data = fetchPlayData(ids.cid, "");
        ids.vid = firstVideoId(data);
    }
    return ids;
}

function firstVideoId(playData) {
    if (playData && isArray(playData.videoList) && playData.videoList.length) return trimText(playData.videoList[0] && playData.videoList[0].vid);
    if (playData && playData.coverInfo && isArray(playData.coverInfo.videoIdList) && playData.coverInfo.videoIdList.length) return trimText(playData.coverInfo.videoIdList[0]);
    return "";
}

function buildPlayUrl(cid, vid, title) {
    cid = trimText(cid);
    vid = trimText(vid);
    var url = WETV_BASE + WETV_LANG_PATH + "/play/" + encodeURIComponent(cid);
    if (vid) url += "/" + encodeURIComponent(vid);
    return url;
}

function fetchPlayData(cid, vid) {
    var json = fetchPlayPayload(cid, vid);
    var playData = json.playData || {};
    if (playData.msg && !playData.coverInfo) throw new Error("WeTV lỗi: " + playData.msg);
    playData.__rec = json.rec || [];
    playData.__hot = json.hot || [];
    return playData;
}

function fetchPlayPayload(cid, vid) {
    return fetchJson(appendQuery(WETV_API_BASE + "/play", { cid: cid || "", vid: vid || "" }, false), {
        headers: { Referer: buildPlayUrl(cid, vid) }
    });
}

function buildWetvDetail(input) {
    var ids = parseWetvInput(input);
    var playData = fetchPlayData(ids.cid, ids.vid);
    var cover = playData.coverInfo || {};
    var title = trimText(cover.title || cover.secondTitle || "WeTV");
    var video = currentVideoInfo(playData, ids.vid);
    var path = buildPlayUrl(cover.cid || ids.cid, video.vid || ids.vid, title);
    return {
        bookId: path,
        name: title,
        cover: normalizeImage(cover.posterVt || cover.posterHz || video.pic_640_360 || ""),
        author: joinParts([cover.director || "", cover.actorNames || cover.actors || ""], " · ") || "WeTV",
        description: htmlDescription(cover.description || cover.secondTitle || ""),
        detail: buildDetailHtml(cover, video),
        host: WETV_BASE,
        path: path,
        ongoing: isOngoingCover(cover),
        format: Number(cover.episodeAll || 0) > 1 || isArray(playData.videoList) && playData.videoList.length > 1 ? "series" : "single",
        type: "video",
        genres: buildGenreLinks(joinParts([cover.category || "", cover.mainGenres || "", cover.subGenres || ""], ",")),
        suggests: buildSuggestEntries(playData)
    };
}

function currentVideoInfo(playData, vid) {
    if (playData && isArray(playData.videoList)) {
        for (var i = 0; i < playData.videoList.length; i++) {
            if (trimText(playData.videoList[i] && playData.videoList[i].vid) === trimText(vid)) return playData.videoList[i] || {};
        }
        return playData.videoList[0] || {};
    }
    return playData && playData.videoInfo ? playData.videoInfo : {};
}

function buildDetailHtml(cover, video) {
    var rows = [];
    appendDetailRow(rows, "Tên gốc", cover.secondTitle || "");
    appendDetailRow(rows, "Điểm", cover.score || "");
    appendDetailRow(rows, "Cập nhật", cover.updateInfo || cover.episodeUpdatedText || "");
    appendDetailRow(rows, "Số tập", cover.episodeAll ? (cover.episodeUpdated ? cover.episodeUpdated + "/" + cover.episodeAll : cover.episodeAll) : "");
    appendDetailRow(rows, "Năm", cover.year || "");
    appendDetailRow(rows, "Khu vực", cover.areaName || "");
    appendDetailRow(rows, "Thể loại", joinParts([cover.category || "", cover.mainGenres || "", cover.subGenres || ""], " · "));
    appendDetailRow(rows, "Đạo diễn", cover.director || "");
    appendDetailRow(rows, "Diễn viên", cover.actorNames || cover.actors || "");
    appendDetailRow(rows, "Tập đang chọn", video && video.title || "");
    return rows.join("");
}

function appendDetailRow(rows, label, value) {
    value = trimText(value);
    if (value) rows.push("<p><b>" + htmlEscape(label) + ":</b> " + htmlEscape(value) + "</p>");
}

function isOngoingCover(cover) {
    cover = cover || {};
    var all = Number(cover.episodeAll || 0);
    var updated = Number(cover.episodeUpdated || 0);
    if (all && updated) return updated < all;
    return /cập nhật|update|đang/i.test(trimText(cover.updateInfo || ""));
}

function buildGenreLinks(text) {
    var parts = String(text || "").split(/[\/,|]/);
    var out = [];
    for (var i = 0; i < parts.length; i++) {
        var title = trimText(parts[i]);
        if (title && !/^\d+$/.test(title)) out.push({ title: title, input: title, script: "search.js" });
    }
    return out;
}

function buildSuggestEntries(playData) {
    playData = playData || {};
    var cover = playData.coverInfo || {};
    var currentCid = normalizeWetvCid(cover.cid || "");
    var suggests = [];
    appendSuggestEntry(suggests, "Có thể bạn sẽ thích", buildOfficialAlbumCards(playData.__rec, "Có thể bạn sẽ thích", currentCid));
    appendSuggestEntry(suggests, "Tác phẩm liên quan", buildActorWorkCards(playData.actorInfoList, currentCid));
    return suggests;
}

function appendSuggestEntry(out, title, cards) {
    cards = dedupeCards(isArray(cards) ? cards : []).slice(0, 40);
    if (!cards.length) return;
    var input = buildListInput("suggest", { cards: cards });
    var key = WETV_SUGGEST_CACHE_PREFIX + new Date().getTime() + ":" + randomHex(8);
    if (setSessionCacheValue(key, JSON.stringify(cards))) input = buildListInput("suggest_cache", { key: key });
    out.push({ title: title, input: input, script: "gen.js" });
}

function buildOfficialAlbumCards(list, moduleTitle, skipCid) {
    var out = [];
    appendCardsFromAlbumArray(out, list, { name: moduleTitle || "" }, skipCid);
    return dedupeCards(out);
}

function buildActorWorkCards(actorInfoList, skipCid) {
    var out = [];
    if (!isArray(actorInfoList)) return out;
    for (var i = 0; i < actorInfoList.length; i++) {
        var actor = actorInfoList[i] || {};
        var title = trimText(actor.name || actor.actorName || actor.title || "Diễn viên");
        appendCardsFromAlbumArray(out, actor.workInfo || actor.work_info || actor.works || actor.videoList, { name: title }, skipCid);
    }
    return dedupeCards(out);
}

function appendCardsFromAlbumArray(out, list, module, skipCid) {
    if (!isArray(list)) return;
    for (var i = 0; i < list.length; i++) {
        var item = list[i] || {};
        var cid = normalizeWetvCid(item.cid || item.cover_id || item.album_id || item.id || "");
        if (skipCid && cid && cid === skipCid) continue;
        var card = buildCardFromItem(item, module || {});
        if (card) out.push(card);
    }
}

function buildWetvToc(input) {
    var ids = parseWetvInput(input);
    var playData = fetchPlayData(ids.cid, ids.vid);
    var cover = playData.coverInfo || {};
    var cid = trimText(cover.cid || ids.cid);
    var pageUrl = buildPlayUrl(cid, ids.vid);
    var items = [];
    var videos = isArray(playData.videoList) ? playData.videoList : [];
    if (!videos.length && ids.vid) videos = [{ vid: ids.vid, title: cover.title || "Phát video" }];
    if (videos.length > 1 || playData.clipsList && playData.clipsList.length) items.push({ name: "Danh sách tập", url: "", type: "section", host: WETV_BASE });
    appendTocVideos(items, videos, cid, false);
    if (isArray(playData.clipsList) && playData.clipsList.length) {
        var clipVideos = fetchClipVideos(playData.clipsList, pageUrl);
        if (!clipVideos.length) clipVideos = playData.clipsList;
        var clips = [];
        appendTocVideos(clips, clipVideos, cid, true);
        if (clips.length) {
            items.push({ name: "Clip / hậu trường", url: "", type: "section", host: WETV_BASE });
            for (var c = 0; c < clips.length; c++) items.push(clips[c]);
        }
    }
    return items;
}

function fetchClipVideos(list, pageUrl) {
    var ids = [];
    var seen = {};
    for (var i = 0; isArray(list) && i < list.length; i++) {
        var vid = trimText(typeof list[i] === "string" ? list[i] : list[i] && (list[i].vid || list[i].video_id || list[i].id));
        if (!vid || seen[vid]) continue;
        seen[vid] = true;
        ids.push(vid);
    }
    if (!ids.length) return [];
    try {
        var json = fetchJson(WETV_API_BASE + "/getVideoByVids?vidList=" + encodeURIComponent(ids.join("_")), {
            headers: { Referer: pageUrl || (WETV_BASE + WETV_LANG_PATH) }
        });
        return isArray(json.response) ? json.response : [];
    } catch (e) {
        return [];
    }
}

function appendTocVideos(items, list, fallbackCid, clip) {
    var seen = {};
    for (var i = 0; i < list.length; i++) {
        var item = list[i] || {};
        var vid = trimText(typeof item === "string" ? item : item.vid || item.video_id || item.id || "");
        if (!vid || seen[vid]) continue;
        seen[vid] = true;
        var cid = trimText(item.cid || item.cover_id || fallbackCid || "");
        var name = episodeName(item, clip);
        items.push({
            name: name,
            url: buildPlayUrl(cid, vid, name),
            host: WETV_BASE,
            description: joinParts([clip ? "Clip" : "", item.duration ? secondsToText(item.duration) : "", isVipVideo(item) ? "VIP" : "", item.isFree === true ? "Free" : ""], " · "),
            cover: normalizeImage(item.pic_640_360 || item.pic || item.img || ""),
            pay: isVipVideo(item)
        });
    }
}

function episodeName(item, clip) {
    item = item || {};
    if (typeof item === "string") return clip ? "Clip" : "Phát video";
    var title = trimText(item.title || item.name || "");
    var episode = trimText(item.episode || item.episode_number || "");
    if (title) return title;
    if (episode) return (clip ? "Clip " : "Tập ") + episode;
    return clip ? "Clip" : "Phát video";
}

function isVipVideo(item) {
    if (!item) return false;
    if (item.isFree === true) return false;
    if (item.isFree === false) return true;
    return /vip|rent|paid/i.test(labelsText(item.mark_label_list || item.labels || [])) || Number(item.payStatus || item.defaultPayStatus || 0) === 1;
}

function secondsToText(value) {
    var seconds = Number(value || 0);
    if (!seconds) return "";
    var h = Math.floor(seconds / 3600);
    var m = Math.floor(seconds % 3600 / 60);
    var s = Math.floor(seconds % 60);
    if (h) return h + ":" + pad2(m) + ":" + pad2(s);
    return m + ":" + pad2(s);
}

function pad2(value) {
    value = String(Math.max(0, Number(value || 0)));
    return value.length < 2 ? "0" + value : value;
}

function buildWetvChapTracks(input) {
    var ids = ensureWetvIds(input);
    var pageUrl = buildPlayUrl(ids.cid, ids.vid);
    var info = fetchGetVinfo({ cid: ids.cid, vid: ids.vid, defn: "", pageUrl: pageUrl });
    var defs = selectWetvDefinitions(info);
    if (!defs.length) defs = fallbackDefinitions();
    var tracks = [];
    for (var i = 0; i < defs.length; i++) {
        var def = defs[i] || {};
        var title = qualityDisplayName(def);
        tracks.push({
            title: title,
            data: buildTrackPayload({
                cid: ids.cid,
                vid: ids.vid,
                defn: trimText(def.name || def.sname || ""),
                label: title,
                pageUrl: pageUrl,
                nonce: new Date().getTime() + ":" + i + ":" + randomHex(4)
            }),
            host: WETV_PLAY_BASE
        });
    }
    return tracks;
}

function selectWetvDefinitions(info) {
    var list = info && info.fl && isArray(info.fl.fi) ? info.fl.fi : [];
    var enabled = getEnabledQualityMap();
    var out = [];
    var seen = {};
    for (var i = list.length - 1; i >= 0; i--) {
        var def = list[i] || {};
        var name = trimText(def.name || def.sname || "");
        if (!name || seen[name] || !enabled[name]) continue;
        seen[name] = true;
        out.push(def);
    }
    out.sort(compareWetvDefinition);
    return out;
}

function compareWetvDefinition(a, b) {
    var avip = Number(a && a.lmt || 0) ? 1 : 0;
    var bvip = Number(b && b.lmt || 0) ? 1 : 0;
    if (avip !== bvip) return avip - bvip;
    return qualityRank(b) - qualityRank(a);
}

function qualityRank(def) {
    var name = trimText(def && (def.name || def.sname) || "");
    var ranks = { ld: 1, sd: 2, hd: 3, shd: 4, fhd: 5, uhd: 6, hdr10: 7, dolby: 8 };
    return ranks[name] || 0;
}

function fallbackDefinitions() {
    var enabled = getEnabledQualityMap();
    var names = ["fhd", "shd", "hd", "sd"];
    var out = [];
    for (var i = 0; i < names.length; i++) if (enabled[names[i]]) out.push({ name: names[i], cname: WETV_QUALITY_LABELS[names[i]] });
    return out;
}

function getEnabledQualityMap() {
    return {
        sd: getConfigBoolean("wetvQuality360p", false),
        hd: getConfigBoolean("wetvQuality480p", false),
        shd: getConfigBoolean("wetvQuality720p", true),
        fhd: getConfigBoolean("wetvQuality1080p", true),
        uhd: getConfigBoolean("wetvQuality4k", false)
    };
}

function qualityDisplayName(def) {
    def = def || {};
    var name = trimText(def.name || def.sname || "");
    var label = trimText(def.cname || def.resolution || WETV_QUALITY_LABELS[name] || name || "HLS");
    var notes = [];
    if (Number(def.lmt || 0)) notes.push("VIP");
    if (Number(def.sl || 0)) notes.push("khuyến nghị");
    return joinParts([label, notes.join(" · ")], " · ");
}

function getGlobalConfigValue(name) {
    try {
        if (typeof globalThis !== "undefined" && globalThis && typeof globalThis[name] !== "undefined") return globalThis[name];
    } catch (e) {}
    try {
        var root = (function () { return this; })();
        if (root && typeof root[name] !== "undefined") return root[name];
    } catch (e2) {}
    try {
        return (0, eval)("typeof " + name + " !== 'undefined' ? " + name + " : null");
    } catch (e3) {}
    return null;
}

function getConfigBoolean(name, defaultValue) {
    var value = getGlobalConfigValue(name);
    if (value == null || value === "") return !!defaultValue;
    if (value === true || value === false) return value;
    if (typeof value === "number") return value !== 0;
    value = trimText(value).toLowerCase();
    if (/^(1|true|yes|on|bật|bat)$/i.test(value)) return true;
    if (/^(0|false|no|off|tắt|tat)$/i.test(value)) return false;
    return !!defaultValue;
}

function buildWetvNativeTrack(input) {
    var payload = parseTrackPayload(input);
    var ids = ensureWetvIds(payload);
    var pageUrl = trimText(payload.pageUrl || buildPlayUrl(ids.cid, ids.vid));
    var info = fetchGetVinfo({ cid: ids.cid, vid: ids.vid, defn: payload.defn || "", pageUrl: pageUrl });
    var vi = info && info.vl && isArray(info.vl.vi) ? info.vl.vi[0] : null;
    if (!vi) throw formatGetvinfoError(info);
    var mediaUrl = selectPlayableMediaUrl(vi, pageUrl);
    if (!mediaUrl) throw new Error("WeTV chưa trả URL phát cho track này");
    var subtitles = buildWetvSubtitleTracks(info.sfl, pageUrl);
    var headers = buildMediaHeaders(mediaUrl, pageUrl);
    var track = {
        data: mediaUrl,
        type: "native",
        mimeType: "application/x-mpegURL",
        host: getUrlOrigin(mediaUrl) || WETV_PLAY_BASE,
        headers: headers,
        timeSkip: []
    };
    if (subtitles.length) {
        track.subtitles = subtitles;
        track.subtitleTracks = subtitles;
        track.subtitle = subtitles[0].url || subtitles[0].data || "";
        track.subtitleType = "vtt";
    }
    return track;
}

function selectPlayableMediaUrl(vi, pageUrl) {
    var first = "";
    if (vi && vi.ul && isArray(vi.ul.ui)) {
        for (var i = 0; i < vi.ul.ui.length; i++) {
            var url = normalizeUrl(vi.ul.ui[i] && vi.ul.ui[i].url || "");
            if (!/^https?:\/\//i.test(url)) continue;
            if (!first) first = url;
            if (probePlayableMediaUrl(url, pageUrl)) return url;
        }
    }
    if (first) throw new Error("WeTV CDN đang trả 403 cho link phát. Hãy mở lại tập hoặc thử chất lượng khác.");
    return "";
}

function probePlayableMediaUrl(mediaUrl, pageUrl) {
    try {
        var result = fetchText(mediaUrl, { headers: buildMediaHeaders(mediaUrl, pageUrl), rawHeaders: true });
        return !!(result && result.ok);
    } catch (e) {
        return false;
    }
}

function buildMediaHeaders(mediaUrl, pageUrl) {
    var cookie = buildMediaCookieHeader(mediaUrl);
    var userAgent = getWetvUserAgent();
    var headers = {
        Accept: "*/*",
        "Accept-Language": "vi,en;q=0.9,en-US;q=0.8,zh-CN;q=0.7,zh;q=0.6",
        DNT: "1",
        Origin: WETV_BASE,
        Referer: pageUrl || (WETV_BASE + WETV_LANG_PATH),
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "cross-site"
    };
    if (userAgent) headers["User-Agent"] = userAgent;
    if (cookie) headers.Cookie = cookie;
    return headers;
}

function fetchGetVinfo(args) {
    args = args || {};
    var cid = trimText(args.cid || "");
    var vid = trimText(args.vid || "");
    if (!vid) throw new Error("Thiếu vid WeTV");
    var guid = getWetvGuid();
    var pageUrl = args.pageUrl || buildPlayUrl(cid, vid);
    var cookie = buildAllWetvCookieHeader(WETV_PLAY_BASE);
    var ckey = buildWetvCkey8({
        vid: vid,
        ts: Math.floor(new Date().getTime() / 1000),
        appVer: WETV_APP_VER,
        guid: guid,
        platform: WETV_PLATFORM,
        h38: getCookieValue(cookie, "_qimei_h38")
    });
    var params = {
        charge: 0,
        otype: "json",
        defnpayver: 0,
        spau: 1,
        spaudio: 1,
        spwm: 1,
        sphls: 1,
        spm3u8tag: 67,
        spmasterm3u8: 3,
        host: "wetv.vip",
        refer: "wetv.vip",
        ehost: pageUrl,
        sphttps: 1,
        encryptVer: "8.5",
        cKey: ckey.cKey,
        clip: 4,
        guid: guid,
        flowid: randomHex(32),
        platform: WETV_PLATFORM,
        sdtfrom: WETV_SDTFROM,
        appVer: WETV_APP_VER,
        unid: "",
        auth_from: "",
        auth_ext: "",
        vid: vid,
        defn: trimText(args.defn || ""),
        fhdswitch: 0,
        dtype: 3,
        spsrt: 3,
        spcaptiontrack: 1,
        tm: ckey.tm,
        lang_code: WETV_LANG_CODE,
        logintoken: buildLoginToken(cookie),
        qimei: "",
        spgzip: 1,
        spcaptiontype: 1,
        cmd: 2,
        appctrl: 0,
        country_code: WETV_COUNTRY_CODE,
        cid: cid,
        drm: 0,
        multidrm: 0,
        callback: "QZOutputJson"
    };
    var url = WETV_PLAY_BASE + "/getvinfo?" + buildQuery(params, true);
    var result = fetchJson(url, {
        headers: {
            Referer: pageUrl,
            Origin: WETV_BASE,
            Cookie: cookie
        }
    });
    if (!result || Number(result.em || 0) !== 0) throw formatGetvinfoError(result);
    return result;
}

function formatGetvinfoError(info) {
    info = info || {};
    var em = Number(info.em || 0);
    var exem = Number(info.exem || 0);
    var msg = trimText(info.msg || info.exemsg || "");
    if (em === 85 || /ckey/i.test(msg)) return new Error("WeTV báo cKey không hợp lệ");
    if (/vip|pay|purchase|subscribe/i.test(msg) || em === 10201 || exem === -403) return new Error("Video WeTV cần đăng nhập/VIP. Hãy đăng nhập trong trình duyệt VBook rồi thử lại.");
    if (/login|cookie|auth/i.test(msg)) return new Error("WeTV yêu cầu cookie đăng nhập. Hãy đăng nhập trong trình duyệt VBook.");
    if (/region|country|area|copyright/i.test(msg) || em === 2 || em === 3) return new Error("Video WeTV bị giới hạn khu vực/bản quyền");
    return new Error("WeTV lỗi phát video" + (em ? " " + em : "") + (exem ? "/" + exem : "") + (msg ? ": " + msg : ""));
}

function buildLoginToken(cookie) {
    cookie = normalizeCookieHeader(cookie);
    if (!getCookieValue(cookie, "main_login")) return "";
    var token = {
        main_login: getCookieValue(cookie, "main_login"),
        access_token: getCookieValue(cookie, "access_token"),
        appid: getCookieValue(cookie, "appid"),
        vusession: getCookieValue(cookie, "vusession"),
        openid: getCookieValue(cookie, "openid"),
        vuserid: getCookieValue(cookie, "vuserid"),
        video_guid: getCookieValue(cookie, "video_guid") || getWetvGuid()
    };
    return JSON.stringify(token);
}

function buildWetvCkey8(input) {
    if (typeof CryptoJS === "undefined" || !CryptoJS || !CryptoJS.AES) throw new Error("Thiếu CryptoJS cho WeTV cKey");
    input = input || {};
    var nonce = randomWetvNonce(11);
    var obj = {
        vid: trimText(input.vid || ""),
        sdkVer: "1.0.1",
        nonce: nonce,
        rand: CryptoJS.MD5(nonce + "1234").toString().substring(0, 8),
        appVer: trimText(input.appVer || WETV_APP_VER),
        guid: trimText(input.guid || getWetvGuid()),
        platform: trimText(input.platform || WETV_PLATFORM),
        ts: String(input.ts || Math.floor(new Date().getTime() / 1000)),
        h38: trimText(input.h38 || ""),
        sj: trimText(input.secJSON || ""),
        bj: trimText(input.busJSON || ""),
        os: JSON.stringify({})
    };
    var key = CryptoJS.enc.Hex.parse("2A5AA60178AA6C8DA662E443773A6C4E");
    var iv = CryptoJS.enc.Hex.parse("CFAC216FAA2D396013575D4055C63350");
    var encrypted = CryptoJS.AES.encrypt(JSON.stringify(obj), key, {
        iv: iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
    });
    return {
        tm: obj.ts,
        cKey: "--01" + encrypted.ciphertext.toString().toUpperCase()
    };
}

function randomWetvNonce(length) {
    var chars = "ABCEFGHIJKLNOPQRSTVWXYZabcefgijklmnpqrsuvwxz0124679";
    var out = "";
    for (var i = 0; i < length; i++) out += chars.charAt(Math.floor(Math.random() * chars.length));
    return out;
}

function buildWetvSubtitleTracks(sfl, pageUrl) {
    var list = sfl && isArray(sfl.fi) ? sfl.fi : [];
    var ordered = orderSubtitleTracks(list);
    var out = [];
    var seen = {};
    for (var i = 0; i < ordered.length && out.length < 4; i++) {
        var item = ordered[i] || {};
        var url = normalizeSubtitleUrl(item);
        if (!url || seen[url]) continue;
        seen[url] = true;
        var headers = buildMediaHeaders(url, pageUrl);
        var dataUrl = fetchVttDataUrl(url, headers);
        var source = dataUrl || url;
        var sub = {
            title: subtitleTitle(item),
            label: subtitleTitle(item),
            language: trimText(item.lang || ""),
            lang: trimText(item.lang || ""),
            url: source,
            data: source,
            sourceUrl: url,
            type: "vtt",
            subtitleType: "vtt",
            selected: !!item.selected
        };
        if (!dataUrl) sub.headers = headers;
        out.push(sub);
    }
    return out;
}

function fetchVttDataUrl(url, headers) {
    try {
        var result = fetchText(url, { headers: headers || {}, rawHeaders: true });
        if (!result || !result.ok || !result.text) return "";
        var text = String(result.text || "").replace(/^\uFEFF/, "");
        if (!/^WEBVTT/i.test(text)) return "";
        var encoded = base64EncodeUtf8(text);
        return encoded ? "data:text/vtt;base64," + encoded : "";
    } catch (e) {
        return "";
    }
}

function base64EncodeUtf8(text) {
    text = String(text == null ? "" : text);
    try {
        if (typeof CryptoJS !== "undefined" && CryptoJS && CryptoJS.enc && CryptoJS.enc.Base64) {
            return CryptoJS.enc.Base64.stringify(CryptoJS.enc.Utf8.parse(text));
        }
    } catch (e) {}
    try {
        if (typeof btoa === "function") return btoa(unescape(encodeURIComponent(text)));
    } catch (e2) {}
    return "";
}

function orderSubtitleTracks(list) {
    var copy = [];
    for (var i = 0; i < list.length; i++) if (list[i]) copy.push(list[i]);
    var out = [];
    appendFirstSubtitlePriority(out, copy, 0);
    appendFirstSubtitlePriority(out, copy, 1);
    appendFirstSubtitlePriority(out, copy, 2);
    appendOriginalSubtitle(out, copy);
    if (!out.length && copy.length) out.push(copy[0]);
    return out;
}

function appendFirstSubtitlePriority(out, list, priority) {
    for (var i = 0; i < list.length; i++) {
        if (subtitlePriority(list[i]) === priority) {
            appendSubtitleUnique(out, list[i]);
            return;
        }
    }
}

function appendOriginalSubtitle(out, list) {
    for (var i = 0; i < list.length; i++) {
        if (isOriginalSubtitle(list[i])) {
            appendSubtitleUnique(out, list[i]);
            return;
        }
    }
}

function isOriginalSubtitle(item) {
    if (!item || subtitlePriority(item) <= 2) return false;
    return !!(item.selected || item.original || item.isOriginal || item.is_original || item.origin || item.is_origin);
}

function appendSubtitleUnique(out, item) {
    var key = normalizeSubtitleUrl(item) || subtitleTitle(item);
    for (var i = 0; i < out.length; i++) if ((normalizeSubtitleUrl(out[i]) || subtitleTitle(out[i])) === key) return;
    out.push(item);
}

function subtitlePriority(item) {
    item = item || {};
    var lang = trimText(item.lang || item.language || item.name || "").toLowerCase().replace("-", "_");
    var name = trimText(item.name || "").toLowerCase();
    if (/^vi(?:_|$)/.test(lang) || /tiếng việt|vietnam|viet/.test(name)) return 0;
    if (/^zh(?:_|$)/.test(lang) || /trung|chinese|中文|简体|繁體/.test(name)) return 1;
    if (/^en(?:_|$)/.test(lang) || /anh|english/.test(name)) return 2;
    if (item.selected) return 3;
    return 10;
}

function subtitleTitle(item) {
    return trimText(item && (item.name || item.lang || item.language) || "Phụ đề");
}

function normalizeSubtitleUrl(item) {
    item = item || {};
    var url = normalizeUrl(item.url || item.data || "");
    if (!url && item.urlList && isArray(item.urlList.ui) && item.urlList.ui.length) url = normalizeUrl(item.urlList.ui[0].url || "");
    if (!/^https?:\/\//i.test(url)) return "";
    url = url.replace(/^http:\/\//i, "https://");
    if (/\.vtt\.m3u8(?:[?#].*)?$/i.test(url)) return url.replace(/\.m3u8(?:[?#].*)?$/i, "");
    return url;
}
