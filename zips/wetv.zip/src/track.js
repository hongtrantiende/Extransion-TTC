load("cryptojs.js");
load("shared.js");

function execute(input) {
    return Response.success(buildWetvNativeTrack(input));
}
