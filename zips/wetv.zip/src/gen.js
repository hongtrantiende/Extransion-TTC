load("shared.js");

function execute(input, page) {
    var result = fetchWetvList(input, page || "1");
    return Response.success(result.items, result.next);
}
