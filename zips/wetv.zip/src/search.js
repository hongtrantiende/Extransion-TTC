load("shared.js");

function execute(key, page) {
    var result = searchWetv(key, page || "1");
    return Response.success(result.items, result.next);
}
