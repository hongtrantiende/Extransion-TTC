let BASE_URL = 'https://aaddbb.com';
let BASE_URL1 = 'https://www.aaddbb.com';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
        BASE_URL1 = CONFIG_URL;
    }
} catch (error) {
}