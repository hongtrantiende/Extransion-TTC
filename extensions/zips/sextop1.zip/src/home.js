function execute() {
    var kinds = [
        {
            title: "Phim Sex Mới",
            name: "Phim Sex Mới",
            input: "https://sextop1.money/page/", script: "genre.js"
        },
        {
            title: "Việt Sub",
            name: "Việt Sub",
            input: "https://sextop1.money/category/phim-sex-viet-sub/page/", script: "genre.js"
        },
        {
            title: "Loạn Luân",
            name: "Loạn Luân",
            input: "https://sextop1.money/category/phim-sex-loan-luan/page/", script: "genre.js"
        },
        {
            title: "Không Che",
            name: "Không Che",
            input: "https://sextop1.money/category/phim-sex-khong-che/page/", script: "genre.js"
        },
        {
            title: "Sex Mỹ – Châu Âu",
            name: "Sex Mỹ – Châu Âu",
            input: "https://sextop1.money/category/phim-sex-chau-au/page/", script: "genre.js"
        },
        {
            title: "Trung Quốc",
            name: "Trung Quốc",
            input: "https://sextop1.money/category/phim-sex-trung-quoc/page/", script: "genre.js"
        }
    ];
    return Response.success(kinds);
}
