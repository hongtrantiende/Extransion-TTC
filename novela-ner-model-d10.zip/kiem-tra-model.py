#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
kiem-tra-model.py — kiểm tra nhanh gói model Quét Tên D10 của Novela MD3.

Kiểm tra đúng các điều kiện mà app bắt buộc (xem HUONG-DAN-SU-DUNG.md mục 4-5):
  1. vocab.txt   : 21.128 dòng, có đủ [UNK]/[CLS]/[SEP]
  2. id-remap.bin: đúng 42.256 byte (21.128 × 2, u16le), remap về miền 0..6143
  3. model.onnx  : session ONNX chạy được, input tên "ids" (int64), output [seq, 7]
  4. Chạy thử một chuỗi id thật và in nhãn + xác suất từng token (softmax 7 nhãn)

Cách chạy:  pip install onnxruntime
            python3 kiem-tra-model.py [thư_mục_chứa_model]
Thư mục mặc định: ./ner  (chứa model.onnx, vocab.txt, id-remap.bin)
"""

import os
import struct
import sys

LABELS = ["O", "B-Nh", "I-Nh", "B-Ns", "I-Ns", "B-Ni", "I-Ni"]
VOCAB_LINES = 21128
REMAP_BYTES = 42256


def fail(msg):
    print(f"[LỖI] {msg}")
    sys.exit(1)


def ok(msg):
    print(f"[OK]   {msg}")


def main():
    folder = sys.argv[1] if len(sys.argv) > 1 else "ner"
    vocab_path = os.path.join(folder, "vocab.txt")
    remap_path = os.path.join(folder, "id-remap.bin")
    model_path = os.path.join(folder, "model.onnx")

    for p in (vocab_path, remap_path, model_path):
        if not os.path.isfile(p):
            fail(f"thiếu file: {p}")

    # ---- 1. vocab.txt --------------------------------------------------
    with open(vocab_path, "r", encoding="utf-8") as f:
        tokens = [line.rstrip("\n").rstrip("\r") for line in f]
    if len(tokens) != VOCAB_LINES:
        fail(f"vocab.txt có {len(tokens)} dòng, cần đúng {VOCAB_LINES}")
    for special in ("[UNK]", "[CLS]", "[SEP]"):
        if special not in tokens:
            fail(f"vocab.txt thiếu token bắt buộc {special}")
    ok(f"vocab.txt: {len(tokens)} dòng, đủ [UNK]/[CLS]/[SEP]")

    # ---- 2. id-remap.bin ----------------------------------------------
    with open(remap_path, "rb") as f:
        raw = f.read()
    if len(raw) != REMAP_BYTES:
        fail(f"id-remap.bin có {len(raw)} byte, cần đúng {REMAP_BYTES} (21.128 × 2)")
    remap = list(struct.unpack(f"<{VOCAB_LINES}H", raw))
    hi = max(remap)
    if hi >= 6144:
        fail(f"remap có id {hi} >= 6144 (ngoài miền id nén)")
    ok(f"id-remap.bin: {len(raw)} byte, id nén lớn nhất {hi} (< 6144)")

    # ---- 3 + 4. model.onnx --------------------------------------------
    try:
        import numpy as np
        import onnxruntime as ort
    except ImportError:
        print("[BỎ QUA] chưa cài onnxruntime/numpy — chỉ kiểm tra file xong.")
        print("Cài thêm: pip install onnxruntime numpy")
        return

    session = ort.InferenceSession(model_path, providers=["CPUExecutionProvider"])
    inputs = {i.name: i for i in session.get_inputs()}
    outputs = session.get_outputs()
    if "ids" not in inputs:
        fail(f"model.onnx không có input tên 'ids' (có: {list(inputs)})")
    if inputs["ids"].type != "tensor(int64)":
        fail(f"input 'ids' sai kiểu: {inputs['ids'].type} (cần tensor(int64))")
    out0 = outputs[0]
    ok(f"model.onnx: session chạy được, input 'ids' {inputs['ids'].shape}, output '{out0.name}'")

    # Chạy thử 10 token id thật (qua remap như app làm): [CLS] 5 ký tự CJK [SEP]
    cls_id = tokens.index("[CLS]")
    sep_id = tokens.index("[SEP]")
    sample_ids = [cls_id] + [21008, 21009, 21010, 21011, 21012] + [sep_id]
    remapped = np.array([[remap[i] for i in sample_ids]], dtype=np.int64).reshape(-1)
    logits = session.run([out0.name], {"ids": remapped})[0]
    if logits.ndim != 2 or logits.shape[1] != 7:
        fail(f"output shape {logits.shape} khác mong đợi [seq, 7]")
    print(f"[OK]   chạy thử {len(sample_ids)} token → logits shape {logits.shape}")
    print()
    print("Nhãn + xác suất từng token (softmax 7 nhãn):")
    for idx, row in enumerate(logits):
        e = np.exp(row - row.max())
        prob = e / e.sum()
        best = int(prob.argmax())
        token_txt = tokens[sample_ids[idx]]
        print(f"  token {idx:2d} ({token_txt!r:12s}) → {LABELS[best]:5s}  p={prob[best]:.3f}")
    print()
    print("HOÀN TẤT: gói model đạt yêu cầu, có thể chép vào app/src/main/assets/ner/.")


if __name__ == "__main__":
    main()
