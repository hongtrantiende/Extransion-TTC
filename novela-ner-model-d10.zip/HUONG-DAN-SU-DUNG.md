# Model Quét Tên D10 — Novela MD3

Bộ model máy quét tên riêng (nhân vật / địa danh / tổ chức) dùng trong app Novela MD3.
Model chạy **hoàn toàn trên máy** (offline, không cần mạng), port 1:1 từ engine WebGPU
của moxhi.vietphrase.app — độ chuẩn như bản web, nhanh gấp hàng chục lần nhờ ONNX Runtime.

---

## 1. Nội dung file zip

| File | Dung lượng | Vai trò |
|---|---|---|
| `ner/model.onnx` | 7,5 MB (7.487.567 B) | Trọng số model, ONNX f32. Input tên `ids` (int64, shape `[seq]`), output logits `[seq, 7]` |
| `ner/vocab.txt` | 110 KB (109.540 B) | Từ điển WordPiece **21.128 token** (bert-base-chinese), bắt buộc có `[UNK]` `[CLS]` `[SEP]` |
| `ner/id-remap.bin` | 42.256 byte | Bảng remap u16le: 21.128 id gốc → 6.144 id nén (42.256 = 21.128 × 2) |
| `kiem-tra-model.py` | — | Script kiểm tra nhanh 3 file trước khi đóng gói (chạy bằng Python + onnxruntime) |
| `HUONG-DAN-SU-DUNG.md` | — | Chính là file này |

---

## 2. Dùng trong app Novela MD3

Model đã được **đóng gói sẵn trong APK** (đường dẫn `assets/ner/` trong app) nên bạn
không cần cài gì thêm — file zip này dùng để lưu trữ, chia sẻ hoặc thay model khi có
bản mới. Có 2 cách dùng trong app:

### a. Quét tên thủ công (màn "Quét Tên")

1. Mở truyện → vào màn **Quét Tên** (Quản lý từ điển).
2. Chọn **Quét từ đầu** hoặc **Quét tiếp** từ mốc đã quét. Chỉ chương **đã tải nội dung** mới được quét.
3. Model quét tuần tự từng chương, danh sách tên hiện live (tối đa 300 tên), xếp theo số lần xuất hiện.
4. Mỗi tên có: loại (**Người / Địa danh / Tổ chức**), nghĩa Hán Việt tự động (viết hoa từng âm tiết, vd 楚南 → "Chu Nam"), số lần xuất hiện.
5. Bấm lưu → tên vào **từ điển riêng của truyện** (3 tab: Người / Địa danh / Tổ chức).
6. Sửa / xóa nghĩa thoải mái — sửa xong **bản dịch đã lưu tự vá theo ngay**, không phải dịch lại.

### b. Công tắc "Quét tên khi dịch" (bảng Dịch ở trang đọc) — từ bản 3.26.28 (19386)

1. Mở **bảng Dịch** (bảng nổi sát đáy màn hình đọc).
2. Tìm công tắc **"Quét tên khi dịch"**:
   - Khi **chưa bật** "Dịch nâng cao": nằm trong phần dịch đọc phía trên.
   - Khi **bật** "Dịch nâng cao": công tắc phía trên ẩn đi, hiện trong khối nâng cao, ngay cạnh nút **Dịch**.
3. Bật lên thì **mỗi chương đi dịch đều được quét tên TRƯỚC**:
   - Cả khi dịch đọc từng chương (công tắc dịch giữa bảng)…
   - …lẫn khi bấm nút **Dịch** trong khối Dịch nâng cao (dịch tất cả hoặc theo khoảng chương).
4. Tên quét được lưu vào từ điển riêng, **chương sau dùng lại tên chương trước** → bản dịch gọi tên nhất quán từ đầu tới cuối truyện.
5. **Mặc định TẮT.** Không muốn quét → tắt, dịch như bình thường. Cần thì bật lại.
6. Nút **Dịch vẫn là nút dịch duy nhất** — công tắc chỉ quyết định "có quét tên trước hay không", không phải nút dịch thứ hai.
7. **App AI / OpenAI bỏ qua** công tắc này (AI tự chú giải tên riêng trong prompt rồi).
8. Chương đã dịch rồi sẽ **không được quét lại** (bỏ qua để không tốn thời gian) — muốn quét lại toàn bộ thì dùng màn Quét Tên ở mục a.

### c. Lưu ý khi dùng

- Quét tên tốn **vài giây mỗi chương** (model chạy trên CPU, nhiều cửa sổ quét song song). Bật công tắc khi dịch cả loạt sẽ thấy job chậm hơn thường — đó là đang quét tên, không phải app treo.
- Tên mà model không suy được nghĩa Hán Việt sẽ **không được lưu** (nghĩa rỗng không giúp được bản dịch nào).
- Biến thể rác do model cắt nhầm (vd 方远 dính ký tự kế thành 方远顺) được **lọc tự động** theo số lần xuất hiện.
- Từ điển riêng đi theo **bản sao lưu** (Novela Backup / Drive / WebDAV) — khôi phục bản lưu là có lại nguyên bộ tên.
- Muốn "Riêng > Chung" hay "Chung > Riêng": chỉnh ở Cài đặt Quick Translate ("Ưu tiên từ điển riêng - chung").

---

## 3. Model hoạt động thế nào?

Độ chuẩn của toàn pipeline sau đây khớp 1:1 với bản web (moxhi.vietphrase.app):

1. **Làm sạch văn bản**: lowercase, chuẩn hóa NFD (bỏ dấu thanh Latin), ký tự điều khiển bỏ hẳn, khoảng trắng thành ranh giới từ.
2. **Tách từ**: chữ CJK đứng riêng từng ký tự, dấu câu đứng riêng, chữ Latin gom thành từ rồi WordPiece (tiền tố `##` cho piece sau).
3. **Cắt cửa sổ**: tối đa **192 token** (kể cả `[CLS]`/`[SEP]`), chồng lấn **16 ký tự**, ưu tiên cắt ở ranh giới câu (。！？… và dấu đóng ngoặc) trong khoảng lùi tối đa 96 ký tự; span chạm mép cắt nhân tạo bị bỏ khi giải mã.
4. **Remap id**: mỗi id token gốc (0..21127) qua bảng `id-remap.bin` (u16le) thành id nén (0..6143) rồi mới đưa vào ONNX.
5. **Suy luận**: softmax 7 nhãn — `O, B-Nh, I-Nh, B-Ns, I-Ns, B-Ni, I-Ni`
   (**Nh = Người, Ns = Địa danh, Ni = Tổ chức**).
6. **Giải mã BIO**: span gồm B-… và I- liên tiếp cùng loại; **confidence = xác suất nhỏ nhất** trong span; chỉ giữ span **≥ 2 ký tự** có confidence ≥ **0,85**; bỏ span 1 ký tự, span chạm mép cắt nhân tạo, span nằm trọn trong vùng chồng lấn bên trái.
7. **Gộp & đếm**: gộp tên trùng (loại theo loại xuất hiện nhiều nhất), đếm số lần xuất hiện trên toàn truyện bằng tìm chuỗi con theo ký tự đầu (nhanh, không quét O(n×dung lượng)).
8. **Hán Việt**: tra qua QuickTranslateEngine (chế độ hanviet), viết hoa từng âm tiết.
9. **Tốc độ**: mỗi lần run ONNX dùng 1 luồng MLAS; cửa sổ chia nhau chạy song song (số luồng = số nhân CPU − 1, tối đa 5) — đo thực tế ~**44 ms/chương hội thoại** trên máy 4 nhân.

---

## 4. Thay / nâng cấp model trong APK (cho lập trình viên)

1. Chép 3 file **đè lên** `app/src/main/assets/ner/` trong mã nguồn Novela MD3, **giữ nguyên tên**: `model.onnx`, `vocab.txt`, `id-remap.bin`.
2. Điều kiện bắt buộc — app sẽ **từ chối nạp** model không đạt (crash-safe):
   - `vocab.txt`: đúng 21.128 dòng (bert-base-chinese) và có đủ `[UNK]`, `[CLS]`, `[SEP]`.
   - `id-remap.bin`: đúng **42.256 byte** (21.128 × 2, little-endian).
   - `model.onnx`: input tên **`ids`** (int64, shape `[seq]`), output logits `[seq, 7]` theo đúng thứ tự nhãn ở mục 3.5.
3. Build lại: `./gradlew :app:assembleAppCoreRelease` (flavor appCore, arm64-v8a).
4. Kiểm tra nhanh trước khi đóng gói: `python3 kiem-tra-model.py` (xem mục 5).

---

## 5. Kiểm tra model bằng script (`kiem-tra-model.py`)

Yêu cầu: Python 3, `pip install onnxruntime`.

```bash
python3 kiem-tra-model.py ner/
```

Script kiểm tra:
- `vocab.txt` có đủ `[UNK]`/`[CLS]`/`[SEP]` và đúng 21.128 dòng;
- `id-remap.bin` đúng 42.256 byte;
- `model.onnx` tạo được session ONNX, đúng input `ids` và output shape `[seq, 7]`;
- chạy thử 1 cửa sổ 10 token, in nhãn + xác suất mỗi token để đối chiếu.

---

## 6. Thông tin kỹ thuật rút gọn

- Kiến trúc: BERT chưng cất **6 layer dùng chung trọng số linear** (chỉ LayerNorm riêng từng layer), dModel 256, 8 head × 32, FFN 1024, GELU (erf); embedding 128 → proj 256 + vị trí (tối đa 192); adapter 256→768 → head 7 nhãn; Post-LN.
- Vocab: bert-base-chinese 21.128 nén còn **6.144** qua bảng remap.
- Ngưỡng tin cậy: **0,85** (confidence = min xác suất các token của span).
- Chạy máy: ONNX Runtime Android, intra-op 1 luồng/cửa sổ, nhiều cửa sổ song song.
